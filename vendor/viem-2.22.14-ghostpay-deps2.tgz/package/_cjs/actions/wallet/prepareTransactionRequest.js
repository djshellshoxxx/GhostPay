"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.defaultParameters = void 0;
exports.prepareTransactionRequest = prepareTransactionRequest;
const parseAccount_js_1 = require("../../accounts/utils/parseAccount.js");
const estimateFeesPerGas_js_1 = require("../../actions/public/estimateFeesPerGas.js");
const estimateGas_js_1 = require("../../actions/public/estimateGas.js");
const getBlock_js_1 = require("../../actions/public/getBlock.js");
const getTransactionCount_js_1 = require("../../actions/public/getTransactionCount.js");
const fee_js_1 = require("../../errors/fee.js");
const blobsToCommitments_js_1 = require("../../utils/blob/blobsToCommitments.js");
const blobsToProofs_js_1 = require("../../utils/blob/blobsToProofs.js");
const commitmentsToVersionedHashes_js_1 = require("../../utils/blob/commitmentsToVersionedHashes.js");
const toBlobSidecars_js_1 = require("../../utils/blob/toBlobSidecars.js");
const getAction_js_1 = require("../../utils/getAction.js");
const assertRequest_js_1 = require("../../utils/transaction/assertRequest.js");
const getTransactionType_js_1 = require("../../utils/transaction/getTransactionType.js");
const getChainId_js_1 = require("../public/getChainId.js");
exports.defaultParameters = [
    'blobVersionedHashes',
    'chainId',
    'fees',
    'gas',
    'nonce',
    'type',
];
async function prepareTransactionRequest(client, args) {
    const { account: account_ = client.account, blobs, chain, gas, kzg, nonce, nonceManager, parameters = exports.defaultParameters, type, } = args;
    const account = account_ ? (0, parseAccount_js_1.parseAccount)(account_) : account_;
    const request = { ...args, ...(account ? { from: account?.address } : {}) };
    let block;
    async function getBlock() {
        if (block)
            return block;
        block = await (0, getAction_js_1.getAction)(client, getBlock_js_1.getBlock, 'getBlock')({ blockTag: 'latest' });
        return block;
    }
    let chainId;
    async function getChainId() {
        if (chainId)
            return chainId;
        if (chain)
            return chain.id;
        if (typeof args.chainId !== 'undefined')
            return args.chainId;
        const chainId_ = await (0, getAction_js_1.getAction)(client, getChainId_js_1.getChainId, 'getChainId')({});
        chainId = chainId_;
        return chainId;
    }
    if ((parameters.includes('blobVersionedHashes') ||
        parameters.includes('sidecars')) &&
        blobs &&
        kzg) {
        const commitments = (0, blobsToCommitments_js_1.blobsToCommitments)({ blobs, kzg });
        if (parameters.includes('blobVersionedHashes')) {
            const versionedHashes = (0, commitmentsToVersionedHashes_js_1.commitmentsToVersionedHashes)({
                commitments,
                to: 'hex',
            });
            request.blobVersionedHashes = versionedHashes;
        }
        if (parameters.includes('sidecars')) {
            const proofs = (0, blobsToProofs_js_1.blobsToProofs)({ blobs, commitments, kzg });
            const sidecars = (0, toBlobSidecars_js_1.toBlobSidecars)({
                blobs,
                commitments,
                proofs,
                to: 'hex',
            });
            request.sidecars = sidecars;
        }
    }
    if (parameters.includes('chainId'))
        request.chainId = await getChainId();
    if ((parameters.includes('fees') || parameters.includes('type')) &&
        typeof type === 'undefined') {
        try {
            request.type = (0, getTransactionType_js_1.getTransactionType)(request);
        }
        catch {
            const block = await getBlock();
            request.type =
                typeof block?.baseFeePerGas === 'bigint' ? 'eip1559' : 'legacy';
        }
    }
    if (parameters.includes('fees')) {
        if (request.type !== 'legacy' && request.type !== 'eip2930') {
            if (typeof request.maxFeePerGas === 'undefined' ||
                typeof request.maxPriorityFeePerGas === 'undefined') {
                const block = await getBlock();
                const { maxFeePerGas, maxPriorityFeePerGas } = await (0, estimateFeesPerGas_js_1.internal_estimateFeesPerGas)(client, {
                    block: block,
                    chain,
                    request: request,
                });
                if (typeof args.maxPriorityFeePerGas === 'undefined' &&
                    args.maxFeePerGas &&
                    args.maxFeePerGas < maxPriorityFeePerGas)
                    throw new fee_js_1.MaxFeePerGasTooLowError({
                        maxPriorityFeePerGas,
                    });
                request.maxPriorityFeePerGas = maxPriorityFeePerGas;
                request.maxFeePerGas = maxFeePerGas;
            }
        }
        else {
            if (typeof args.maxFeePerGas !== 'undefined' ||
                typeof args.maxPriorityFeePerGas !== 'undefined')
                throw new fee_js_1.Eip1559FeesNotSupportedError();
            const block = await getBlock();
            const { gasPrice: gasPrice_ } = await (0, estimateFeesPerGas_js_1.internal_estimateFeesPerGas)(client, {
                block: block,
                chain,
                request: request,
                type: 'legacy',
            });
            request.gasPrice = gasPrice_;
        }
    }
    if (parameters.includes('gas') && typeof gas === 'undefined')
        request.gas = await (0, getAction_js_1.getAction)(client, estimateGas_js_1.estimateGas, 'estimateGas')({
            ...request,
            account: account
                ? { address: account.address, type: 'json-rpc' }
                : account,
        });
    if (parameters.includes('nonce') && typeof nonce === 'undefined' && account) {
        if (nonceManager) {
            const chainId = await getChainId();
            request.nonce = await nonceManager.consume({
                address: account.address,
                chainId,
                client,
            });
        }
        else {
            request.nonce = await (0, getAction_js_1.getAction)(client, getTransactionCount_js_1.getTransactionCount, 'getTransactionCount')({
                address: account.address,
                blockTag: 'pending',
            });
        }
    }
    (0, assertRequest_js_1.assertRequest)(request);
    delete request.parameters;
    return request;
}
//# sourceMappingURL=prepareTransactionRequest.js.map
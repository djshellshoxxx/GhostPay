"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.polygonMumbai = void 0;
const defineChain_js_1 = require("../../utils/chain/defineChain.js");
exports.polygonMumbai = (0, defineChain_js_1.defineChain)({
    id: 80_001,
    name: 'Polygon Mumbai',
    nativeCurrency: { name: 'MATIC', symbol: 'MATIC', decimals: 18 },
    rpcUrls: {
        default: {
            http: ['https://rpc.ankr.com/polygon_mumbai'],
        },
    },
    blockExplorers: {
        default: {
            name: 'PolygonScan',
            url: 'https://mumbai.polygonscan.com',
            apiUrl: 'https://api-testnet.polygonscan.com/api',
        },
    },
    contracts: {
        multicall3: {
            address: '0xca11bde05977b3631167028862be2a173976ca11',
            blockCreated: 25770160,
        },
    },
    testnet: true,
});
//# sourceMappingURL=polygonMumbai.js.map
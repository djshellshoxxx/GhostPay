"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.immutableZkEvmTestnet = void 0;
const defineChain_js_1 = require("../../utils/chain/defineChain.js");
exports.immutableZkEvmTestnet = (0, defineChain_js_1.defineChain)({
    id: 13473,
    name: 'Immutable zkEVM Testnet',
    nativeCurrency: {
        decimals: 18,
        name: 'Immutable Coin',
        symbol: 'IMX',
    },
    rpcUrls: {
        default: {
            http: ['https://rpc.testnet.immutable.com'],
        },
    },
    blockExplorers: {
        default: {
            name: 'Immutable Testnet Explorer',
            url: 'https://explorer.testnet.immutable.com/',
        },
    },
    contracts: {
        multicall3: {
            address: '0x2CC787Ed364600B0222361C4188308Fa8E68bA60',
            blockCreated: 5977391,
        },
    },
    testnet: true,
});
//# sourceMappingURL=immutableZkEvmTestnet.js.map
import sys,subprocess,json,datetime,time,hashlib,os
from pathlib import Path
root=Path('/workspace/scratch/5ceb6203640a/GhostPay-cookie-dependency')
evidence=Path(__file__).parent
name=sys.argv[1]
args=sys.argv[2:]
def pin():
 return {k:subprocess.check_output(['git','rev-parse',v],cwd=root,text=True).strip() for k,v in [('sha','HEAD'),('tree','HEAD^{tree}')]}
before=pin();started=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
with (evidence/(name+'.log')).open('wb') as log:
 result=subprocess.run(args,cwd=root,stdout=log,stderr=subprocess.STDOUT)
raw=(evidence/(name+'.log')).read_bytes()
receipt={'name':name,'command':args,'cwd':str(root),'started_at':started,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':round(time.monotonic()-t,3),'exit_code':result.returncode,'source_before':before,'source_after':pin(),'log_bytes':len(raw),'log_sha256':hashlib.sha256(raw).hexdigest()}
(evidence/(name+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
sys.exit(result.returncode)

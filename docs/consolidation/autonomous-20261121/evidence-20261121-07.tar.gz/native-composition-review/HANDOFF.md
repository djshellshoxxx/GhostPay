# Independent native repair composition review

## Outcome and exact source

**No blocking source finding identified in the bounded review.** The composition is suitable for publishing to its exclusively owned source branch and executing the remaining gates. This conclusion is not merge qualification, a GitHub approval, an external security audit, or a passing native-browser result.

- Reviewer: `/root/native_composition_review`.
- Reviewed head: `a9bd507e130283df2270683faa3128af89dc44d6`.
- Reviewed tree: `51054a204b1a1f02b1cc4385e943cdfa2bc5ed15`.
- Public base: `22569e2a83e3f8bc3c86982f69bbb1d90ca8356c`.
- Frozen parents: harness `5ed15080db47aeccffc1ed9dbd4aeac4bfc1dff6`; UI/docs `c773eff0c3e4568efc7a980712aa0e0003685ded`.
- Worktree: `/workspace/scratch/5ceb6203640a/GhostPay-native-candidate`.
- Tracked worktree remained clean. No source edits, installs, builds, remote mutations, shared lease changes, deployments, releases or funds actions occurred.

Repository `AGENTS.md`, `docs/ai/WORKFLOW.md`, the handoff template, all current appended claims and both author handoffs were read. The review owns only this evidence directory. The candidate's ignored `node_modules` link points to the harness author's installed dependencies and was used only for reads and focused test execution. The retention worker retained the heavy execution slot.

## Independent preservation checks

All 14 changed paths were read. Every one of the 13 non-registry changed files is exactly equal to its respective frozen parent's Git blob. The complete base `ACTIVE_WORK.md` prefix and each parent's complete appended claim remain byte-for-byte present, followed by the composition claim. Of 5,767 base tree entries, 5,758 are unchanged; there are five added paths and no deletions.

The existing `ContextHelp.test.tsx`, `Pay.tsx`, ordinary and native Playwright configurations, Vite configuration, accessibility audit, full stealth-export browser spec, dependency manifests and lockfile are unchanged. `source-preservation.json` records the blob comparisons and registry suffix hashes independently of the coordinator's comparison file.

`verify-assertions.mjs` parses both revisions with the installed TypeScript compiler and compares tokenized call expressions as multisets. It verified that all **258 original nested expect-call expressions** and **19 original literal test titles** in the four harness files remain. These are structural counts, not independent assertions or executed parameterized cases. The contextual-help browser spec changes one geometry assertion from viewport Y to document Y; its two nested AST call nodes account for the entire difference in its expect expressions. The greater-than comparison, exact one-click expectation and collapsed aria-expanded expectation remain. Every other original expect expression in that file is unchanged.

## Source assessment

| Paths reviewed | Assessment |
|---|---|
| `apps/web/src/components/ContextHelp.tsx`; `apps/web/src/styles/app.css` | The original tooltip hides immediately on hover leave. A separate string-only, aria-hidden span reserves the same CSS flow dimensions until an activation/cancellation, keyboard input, reentry/focus or an idle resize clears it. It has no ID, role, focus target, interactive children, pointer handling or selectable text. There are no inline styles, DOM measurements, external assets or CSP changes. Outside dismissal remains at click; the queued release task preserves the click interval. Effect cleanup cancels its owned timer and removes its listeners. Existing keyboard, focus, touch, description and click contracts passed unchanged. Actual layout/engine event-order behavior still requires the browser run. |
| `apps/web/e2e/contextual-help.spec.ts` | Adding `scrollY` makes the assertion compare in-flow document placement across the scroll that focus/hover can cause. This preserves the test's intended displacement and successful control activation contracts. |
| `apps/web/e2e/httpRedirectFixture.mjs`; `.d.mts` | Test-only HTTP proxy binds explicitly to `127.0.0.1`. It accepts only loopback HTTP upstream origins with no credentials/path/query/fragment, fixes forwarding hostname and port to that origin, permits GET/HEAD only and never follows upstream redirects. The private marker is stripped before normal forwarding. Normal response status/headers/bytes pass through. Only explicitly marked requests receive the authored 302/307. Teardown destroys pending forwarding requests and closes incoming connections. The declaration matches the implemented return shape. |
| `apps/web/e2e/network-isolation.spec.ts` | The actual browser request receives the server's real redirect, avoiding WebKit's unsupported synthetic 3xx fulfillment. The initial local app load, real reloads, forbidden-destination checks, same-origin destination check and stored privacy-preference comparison remain. New server-response counts ensure the test exercised the intended redirects. The foreign-destination case retains abort-and-record routing. No product networking or CSP behavior changes. |
| `scripts/tests/native-http-redirect-fixture.test.mjs` | Exercises the actual helper using loopback servers. Verifies unchanged binary bytes/headers, absent upstream marker, actual 302/307 response headers/status, exact emitted-response ledger, method rejection and rejected non-origin upstream input. No external destination is contacted. |
| `apps/web/e2e/idle-session.spec.ts` | The away entry is an inert, locally routed HTTP page, permitting the installed clock controller. It still performs real back navigation and retains both expired-key absence assertions. This does not prove BFCache selection or physical sleep. |
| `apps/web/e2e/stealthExportFixtures.ts`; `scripts/tests/native-crypto-probe.test.mjs` | Installed noble 2.4.0 uses the inspected zero-delay timer fallback when scheduler.yield is absent. The added Proxy forwards receiver, callback, arguments and return handle without a new scheduler or KDF adjustment. Existing AES wrapper and explicit hold/release semantics remain. The contract suite executes the actual serialized callback in a VM against stub scheduler/crypto functions; it is not native cryptographic or browser qualification. The fallback counter observes all explicit zero-delay schedules and cannot independently establish KDF progress/completion. The browser test's separate actual AES and idle/key assertions are retained. |
| `apps/web/e2e/network-authorization.spec.ts` | Continue remains disabled until a current verified payment context exists. Waiting for enabled state establishes the loaded-payment condition named by the affected tests before taking their request baselines. All no-new-request/provider/raw-transaction expectations remain. The separate unchanged in-flight replacement browser case remains, and its existing production-path unit regressions passed on the composition. This does not resolve a potential native-only cancellation defect without the actual browser run. Added diagnostics report method/origin/failure, not request bodies or keys. |
| `.github/workflows/native-browser-qualification.yml` | Fixture contracts run before the native suite. DEBUG adds process stderr; retain-on-failure adds traces. Bash `set -euo pipefail` preserves a failing Playwright status through tee. The process log is outside `test-results/native`, which is the actual output directory cleaned by Playwright. Success identity remains guarded by successful prior execution, exact checked-out SHA, clean tracked source and validated nonzero expected/zero unexpected report counts. No disabled axe rule, retry, timeout, permission, deployment or version-substitution change is included. |
| `docs/ai/ACTIVE_WORK.md`; `docs/handoffs/CONTEXT_HELP_NATIVE_20261121.md` | Ownership/provenance preserved. The UI handoff attributes its successful typecheck to the isolated UI source and preserves earlier failed attempts. It does not assert corrected native execution. The composition claim acknowledges pending final gates and the unreconciled shared lease. |

## Executed reviewer checks

Each test/lint/syntax command has a raw log and receipt containing cwd, exact head, start time, elapsed time and exit code.

| Command / scope | Actual result | Elapsed |
|---|---|---:|
| `node --test scripts/tests/native-crypto-probe.test.mjs scripts/tests/native-http-redirect-fixture.test.mjs` | **8 passed, 0 failed, 0 skipped, 0 cancelled** | 0.731 s |
| `../../node_modules/.bin/vitest run src/components/ContextHelp.test.tsx --coverage=false --maxWorkers=1` from `apps/web` | **1 file, 8 tests passed; 0 failures/skips** | 3.441 s |
| `../../node_modules/.bin/vitest run src/views/Pay.preflightCompletion.test.tsx src/views/Pay.network.test.tsx --coverage=false --maxWorkers=1` from `apps/web` | **2 files, 2 tests passed; 0 failures/skips** | 7.122 s |
| Scoped ESLint for the six changed TS/TSX source/spec files | Exit 0 | 6.538 s |
| Three separate `node --check` commands for the new MJS files | All exit 0 | 0.057 / 0.057 / 0.050 s |
| `git diff --check 22569e2a83e3f8bc3c86982f69bbb1d90ca8356c HEAD` | Exit 0 | 0.010 s |
| Independent token/AST assertion comparison | Passed, exact frozen source | Static verification |
| Independent Git tree/blob/claim comparison | Passed, exact frozen source; tracked tree clean | Static verification |

The Node and Vitest selections total **18 passing tests**, with no observed failed or skipped selected cases. The MJS files are excluded by the repository's ESLint configuration; syntax and executed contract checks do not turn them into lint-qualified files. No full web typecheck or aggregate build was run by this reviewer. The coordinator's isolated UI typecheck is separate evidence and is not promoted to a composition typecheck.

Environment: Node 24.22.3, npm 11.19.1, TypeScript 5.9.3, Vitest 5.1.0, ESLint 10.15.0, Playwright 1.65.1, React 19.3.1 and noble hashes 2.4.0. `ENVIRONMENT.json` records these and the final source identity. A first metadata-collection helper had a Python syntax error before execution; its corrected read-only rerun succeeded. No test result depends on that helper.

## Remaining gates and handoff

1. Build and typecheck the combined source in a coordinated, independently writable dependency environment. Do not install/build through the borrowed dependency symlink.
2. Run the exact corrected source under the pinned native engines and original Chromium jobs, including applicable mobile viewports. A diagnostic on an older cached engine must be labeled as a diagnostic; it cannot satisfy Playwright 1.65.1's pinned Firefox/WebKit gates.
3. Verify the real layout/click sequence, loopback redirects, clocked history, fallback crypto probe and request-baseline behavior. Inspect actual stderr/traces for Firefox page crashes before changing application or audit behavior. The crashes remain unexplained.
4. Keep all original hosted failures and skips explicit until superseded by successful exact-source execution. Native run 44882398831 on base22569 remains: WebKit lean126/5/5; full139/5/2; Firefox lean109/12/5; full124/10/2 (pass/fail/skip). These are attributed author/base receipts, not executions by this reviewer.
5. Complete remaining aggregate, privacy, release-artifact and source-specific CI requirements. The held generation11 shared integration lease is not reconciled, so this review authorizes no shared-target integration.

No corrected-source browser execution, native/mobile/Tor qualification, full application suite, release readiness or final integration is claimed by this packet. The coordinator owns the next build/publication/CI steps and must recheck source heads before using this review.

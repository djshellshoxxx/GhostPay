import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import { createRequire } from 'node:module';

const root = '/workspace/scratch/5ceb6203640a/GhostPay-native-candidate';
const require = createRequire(`${root}/package.json`);
const ts = require('typescript');
const base = '22569e2a83e3f8bc3c86982f69bbb1d90ca8356c';
const head = 'a9bd507e130283df2270683faa3128af89dc44d6';
const git = (...args) => execFileSync('git', args, { cwd: root, encoding: 'utf8' });
assert.equal(git('rev-parse', 'HEAD').trim(), head);

function tokens(text) {
  const scanner = ts.createScanner(ts.ScriptTarget.Latest, true, ts.LanguageVariant.Standard, text);
  const result = [];
  for (let kind = scanner.scan(); kind !== ts.SyntaxKind.EndOfFileToken; kind = scanner.scan()) {
    result.push([kind, scanner.getTokenText()]);
  }
  return JSON.stringify(result);
}

function rootName(node) {
  if (ts.isIdentifier(node)) return node.text;
  if (ts.isPropertyAccessExpression(node) || ts.isElementAccessExpression(node) || ts.isCallExpression(node)) {
    return rootName(node.expression);
  }
  return undefined;
}

function inspect(path, ref) {
  const source = git('show', `${ref}:${path}`);
  const parsed = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true);
  const expectCalls = [], titles = [];
  function visit(node) {
    if (ts.isCallExpression(node)) {
      const name = rootName(node.expression);
      if (name === 'expect') expectCalls.push(tokens(node.getText(parsed)));
      if ((name === 'test' || name === 'redirectTest') && node.arguments[0] && ts.isStringLiteral(node.arguments[0])) {
        titles.push(node.arguments[0].text);
      }
    }
    ts.forEachChild(node, visit);
  }
  visit(parsed);
  return { expectCalls, titles };
}

function difference(before, after) {
  const remaining = [...after];
  return before.filter((value) => {
    const index = remaining.indexOf(value);
    if (index < 0) return true;
    remaining.splice(index, 1);
    return false;
  });
}

const paths = ['apps/web/e2e/idle-session.spec.ts', 'apps/web/e2e/network-authorization.spec.ts',
  'apps/web/e2e/network-isolation.spec.ts', 'apps/web/e2e/stealthExportFixtures.ts'];
const inspected = paths.map((path) => {
  const before = inspect(path, base), after = inspect(path, head);
  const lostExpectCalls = difference(before.expectCalls, after.expectCalls);
  const lostTitles = difference(before.titles, after.titles);
  assert.deepEqual(lostExpectCalls, [], `Original expect expressions changed in ${path}`);
  assert.deepEqual(lostTitles, [], `Original literal titles changed in ${path}`);
  return { path, originalNestedExpectCalls: before.expectCalls.length, finalNestedExpectCalls: after.expectCalls.length,
    originalLiteralTitles: before.titles, finalLiteralTitles: after.titles, lostExpectCalls, lostTitles };
});

const uiBefore = inspect('apps/web/e2e/contextual-help.spec.ts', base);
const uiAfter = inspect('apps/web/e2e/contextual-help.spec.ts', head);
assert.deepEqual(uiBefore.titles, uiAfter.titles);
const uiRemoved = difference(uiBefore.expectCalls, uiAfter.expectCalls);
const uiAdded = difference(uiAfter.expectCalls, uiBefore.expectCalls);
assert.equal(uiRemoved.length, 2, 'Only the one geometry chain and its nested expect may change');
assert.equal(uiAdded.length, 2);
assert.ok(uiRemoved.every((value) => value.includes('boundingBox')));
assert.ok(uiAdded.every((value) => value.includes('getBoundingClientRect') && value.includes('scrollY')));

const result = { reviewer: '/root/native_composition_review', base, head, inspected,
  originalNestedExpectCallsPreserved: inspected.reduce((sum, row) => sum + row.originalNestedExpectCalls, 0),
  originalLiteralTitlesPreserved: inspected.reduce((sum, row) => sum + row.originalLiteralTitles.length, 0),
  ui: { originalNestedExpectCalls: uiBefore.expectCalls.length, finalNestedExpectCalls: uiAfter.expectCalls.length,
    literalTitles: uiAfter.titles, removedTokenSequences: uiRemoved, addedTokenSequences: uiAdded,
    interpretation: 'One existing greater-than geometry assertion changes coordinates from viewport to document space; every other original expect expression is unchanged.' },
  caveat: 'Nested AST calls are structural counts, not independent assertions or parameterized executed test cases.' };
writeFileSync(new URL('./assertion-preservation.json', import.meta.url), JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify({ head, originalNestedExpectCallsPreserved: result.originalNestedExpectCallsPreserved,
  originalLiteralTitlesPreserved: result.originalLiteralTitlesPreserved, uiCoordinateAssertionChanged: 1,
  allOtherUiExpectExpressionsPreserved: true }, null, 2));

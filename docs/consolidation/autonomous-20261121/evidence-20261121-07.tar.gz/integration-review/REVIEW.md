# Independent integration source review

Reviewer: `/root/integration_review`. Recorded 2026-11-21 06:21:20 UTC.

## Decisions

No blocking source finding in the complete TRON selected-genesis delta and current-main conflict resolution, vault rekey-lock correction, BTC preview network validation, duplicate-router notification correction, or malformed UTF-16 encoder guard.

| PR | Exact reviewed source | Disposition | New reviewer execution |
| --- | --- | --- | --- |
| #340 | `e6043d44cc9bf78763557974eff7a7fbffb01a5e` / application merge `ae7498b43065e0030e47ba23d473073f5d862b3d` | Source approved for publication and hosted qualification | All five web TRON files: 66 passed, zero failed/skipped |
| #328 | `81598d93dd82cc440526c866d42b55be0657895b`, composed at `6cbc91fba56465b2c18de719de1a0303c9be5cb0` | Source approved | No duplicate execution; coordinator owns package coverage |
| #338 | `692cac58b1c345137264936e60bee7b1e2eed8b2` | Source approved | Four preview regression cases passed |
| #350 | `89b3572f7e60cb6f5e5a0d7830632d1bb5f04dd8` | Source approved | Complete scanMatches file: four passed |
| #360 | `2844ec6c22fe179987585679a934e10033ff3384` | Source approved | Four UTF-16/query regression cases passed |

All reviewer commands exited zero and retained the original Vitest/Vite configuration. These are focused noncoverage selections, not full-package, full-browser or release qualification. Exact commands, source/tree fingerprints, log digests and boundaries are recorded in `integration-source-review.json` and `focused-tests.json`.

## TRON resolution

Reviewed the whole runtime change, not only child #342's test repair. The selected network reaches `checkNetwork` in the shared connect operation used by scan, review, sign and broadcast. Existing operation ownership and AbortSignals remain. Known Nile/Shasta identities must match their selected chain; mainnet and unknown identifiers fail closed, and explicit local selection cannot silently mean a known public testnet.

The integration preserves main's strict omitted-genesis `INVALID_RESPONSE` assertion with the new `'local'` argument, all three incomplete-page regressions and selected Nile/Shasta caller tuples. The entire `packages/` tree matches the main input, retaining adapter cancellation and completeness behavior. No workflow, dependency, contract, flag or network-policy change is present. The two runtime files remain identical to the original reviewed parent stack. An untrusted node can still fabricate responses; this check is not cryptographic chain attestation.

## Vault resolution

The captured context is an identity token for the original live session. `lock()` clears both context and book synchronously. A completed rekey installs the fresh context only if the original token remains; a later `unlock` creates a different session and cannot reopen the old one. Global write serialization preserves normal rekey and mutation ordering. The regression proves the encrypted write can finish, new-password unlock works, and the original session continues refusing book and backup access.

## Other bounded fixes

- BTC preview validates silent-payment checksums, version, curve points and expected network through the same decoder used by signing, before returning fees/size. Valid fee and dust behavior is preserved.
- Router warning detection compares distinct announcement IDs per normalized address. Any differing ID sets the warning permanently; same-ID status refreshes and public non-router entries do not create false warnings.
- The Unicode-mode surrogate check rejects isolated UTF-16 units before TextEncoder can substitute U+FFFD. Valid pairs and UTF-8 percent encoding remain unchanged; the existing typed error propagates through query construction.

Live checks for #338/#350/#360 were all completed: respectively 37/36/36 successful checks and three skipped Pages publishing checks. These observations have their own timestamps in `live-pr-checks.json`; they are not a new CI execution by this reviewer.

## Integration limits

This is independent AI-assisted source review, not a formal GitHub approval or professional external audit. Root must recheck heads, lock ownership, current-main compositions and applicable gates. #340 still needs new hosted qualification after publishing its resolved head. No application source or remote state was changed by this reviewer.

# Independent invoice registration-time retention review

**Reviewed source:** `8cf505bae569fb2e8e3400a1489630991b71fa54`  
**Tree:** `7cd2ccd97abb3808db44ac253da7a6e0e45f2ec2`  
**Base:** `783231a46840cd869e39bd704751d4ab4c349c45`  
**Product implementation:** `16204479269401403e869fda79ecfe405321ea7e`  
**Reviewer:** `/root/invoice_retention_independent_review`

No functional source blocker was identified within this bounded cleanup slice. Independent corrected-source verification passed **158 cases across 12 files**, with zero failed or skipped cases. **The whitespace gate is currently failed**, and full author qualification plus native browser execution remain separate open requirements. This is source-review evidence, not formal GitHub approval, an external audit, release approval or authority to bypass the integration lease.

## Standards

The diff is limited to the registered timestamp representation, a portable preview/confirmation API, its actual ledger control, dedicated tests, critical localization classification and documentation. Existing repository ownership was respected. No dependencies, workflow gates, thresholds, cryptographic primitives or unrelated store operations changed. No material design-smell correction is warranted by this bounded change.

One tooling finding requires correction: **RET-REVIEW-01 (low)**. `git diff --check 783231a4...8cf505ba` exited **2** because `docs/ai/ACTIVE_WORK.md:3950` adds a blank line at EOF. The author acknowledged the finding and will remove only that extra newline after the ongoing clean-source coverage stage. The failed receipt remains in this packet. The correction must preserve every product and test blob and receive a fresh baseline diff check.

Standards references: `AGENTS.md`, `docs/ai/WORKFLOW.md`, `docs/ai/HANDOFF.md` and the appended ownership claim in `docs/ai/ACTIVE_WORK.md`.

## Spec

No missing or incorrectly implemented requirement was identified in the accepted **registeredAt-only** slice. The review does not mark broader retention complete. Automatic expiry of persistent data, other persistent metadata fields, terminal-record cleanup and full M3 qualification remain outside this slice.

The implementation retains complete registrations while making removed local save time explicit: registration v2 requires `registeredAt: null`, inside document v4. Legacy documents remain readable and do not upgrade during a read or preview. UI copy discloses that older applications cannot open the updated document. Existing invoice creation/expiry times, amount calculations, identity fields, receipts, payment observations and reorg/security records remain protected.

Preview returns only a frozen category and count. Its opaque identity is held with ciphertext and the current session revision in the vault handle. Confirmation consumes it before asynchronous work, compares the exact encrypted snapshot, and makes one guarded storage CAS attempt. It cannot extend an old approval onto a concurrent registration. Lock, same-key replacement, another handle, cancel, session/caller revocation and changed storage are rejected. Empty eligible sets do not create or rewrite a vault.

Existing local redaction survives duplicate registration, older-backup import and reload. Newly imported registrations retain their metadata until separately approved. Explicit removal of the entire registration remains a distinct existing operation; this change adds no new sensitive deletion-history store.

The mounted unlocked ledger has separate consent that starts off. Existing presentation-cleanup preferences never authorize persistent writes. Scope/session/quick-hide changes revoke its pending authority. New messages stay in the existing security-sensitive translation policy; reviewed non-English copy is not claimed.

## Independent execution

| Check | Actual result | Duration |
| --- | --- | ---: |
| Retention API and original amount reconciliation suites | 34 passed, 2 files, 0 failed/0 skipped | 1.694 s |
| Ledger retention/invoices/privacy, vault/invoices/IDB, matching, payment summary, invoice registration and critical i18n suites | 124 passed, 10 files, 0 failed/0 skipped | 19.197 s |
| New browser test collection | 2 desktop cases collected in 1 file; **0 executed** | 1.101 s |
| AST preservation checks | Passed | 0.394 s |
| Baseline diff whitespace check | **Failed**, exit 2, registry EOF blank line | 0.027 s |

Every command, working directory, source/tree before and after, clean tracked status, UTC timestamp, exit code and log hash is in its receipt. Focused reruns deliberately do not claim aggregate coverage. The author is running the unchanged original full coverage gates separately.

The browser cases use the actual static-app key import, invoice registration, encrypted backup and reload flows. The second adds two same-seller tabs and a concurrent registration between preview and confirmation, checking exact ciphertext and record preservation. They block foreign requests. Their source and successful collection are reviewed; a native-engine result still must come from actual execution.

## Preservation evidence

`SOURCE_PRESERVATION.json` maps every changed path and blob. Of 5,762 baseline entries, **5,749 remain identical**, with 4 additions and no deletions. **996 prior test-related tracked paths remain identical**, including archived test source and evidence copies. This is source preservation, not an executed-suite count. The sole modified prior test appends ten required security message names; its **62 original expect call nodes and 11 test titles remain unchanged**. All prior assertions in the original browser case remain present after its helper extraction and second-case addition.

`STRUCTURAL_REVIEW.json` records exact unchanged text for **35 existing functions/methods**, covering registration construction, matching, encryption, session key handling, record saves, imports, receipts and reorg operations. The separate amount implementation is unchanged. All recorded manifests, lockfiles, workflow/configuration gates and preexisting catalog values remain identical. The follow-up from implementation commit to reviewed tip changes only the new E2E file.

## Limits and next action

The author owns source; this reviewer made no repository edits, installations, ref changes, lock operations or remote writes. Historical versions were compared as source only; no vulnerable-history execution or exploit reconstruction occurred. Full typecheck/lint/build/security/coverage and browser claims must use their own exact-source receipts. No external audit, native translation review, deployment or funds action is implied.

Complete the running full-web stage, then fix the registry newline with a docs-only commit. Verify that delta and rerun `git diff --check`. Preserve this review against the unchanged product tree, publish only through the coordinator, and execute the two new browser journeys plus applicable hosted/native gates. Parent #372 dependencies and the unreconciled shared integration lease remain in force.

**Standards:** zero substantive source findings, one low tooling finding. **Spec:** zero bounded implementation findings; broader retention and qualification remain explicitly partial.

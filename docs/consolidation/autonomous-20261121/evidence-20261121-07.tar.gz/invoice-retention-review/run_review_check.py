import sys, subprocess, json, hashlib, datetime, time, os
from pathlib import Path
ROOT=Path('/workspace/scratch/5ceb6203640a/GhostPay-invoice-retention')
OUT=Path('/workspace/scratch/5ceb6203640a/invoice-timestamp-retention-independent-review')
name, relative, *cmd = sys.argv[1:]
def git(*args): return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()
meta={'name': name, 'cwd': str(ROOT/relative), 'command_argv': cmd, 'source_sha_before': git('rev-parse','HEAD'), 'tree_sha_before':git('rev-parse','HEAD^{tree}'), 'tracked_status_before':git('status','--short','--untracked-files=no'), 'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'qualification':'independent focused check only; no aggregate coverage, native browser, or release gate is inferred'}
log=OUT/(name+'.log')
env=os.environ.copy(); env['CI']='1'; env['NODE_OPTIONS']='--max-old-space-size=1024'
start=time.monotonic()
with log.open('wb') as fh:
 result=subprocess.run(cmd,cwd=ROOT/relative,stdout=fh,stderr=subprocess.STDOUT,env=env)
meta.update(exit_code=result.returncode, duration_seconds=round(time.monotonic()-start,3), ended_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_sha_after=git('rev-parse','HEAD'),tree_sha_after=git('rev-parse','HEAD^{tree}'),tracked_status_after=git('status','--short','--untracked-files=no'),log_file=log.name,log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
OUT.joinpath(name+'.receipt.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(meta,indent=2));print(log.read_text(errors='replace')[-5500:])
sys.exit(result.returncode)

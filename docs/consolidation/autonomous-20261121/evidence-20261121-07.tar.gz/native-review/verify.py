from pathlib import Path
import hashlib, json, os, subprocess, time
import yaml

repo=Path('/workspace/scratch/5ceb6203640a/GhostPay-native-browsers')
out=Path('/workspace/scratch/5ceb6203640a/native-browser-review-evidence')
source='2eeae61efd83d28554003e6a4a618c39949b9d50'
def git(*args):
    return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def execute(name,args,cwd,extra=None):
    before=git('rev-parse','HEAD')
    if before!=source: raise RuntimeError('Source moved before '+name)
    env=os.environ.copy();env.update(extra or {})
    start=time.monotonic()
    p=subprocess.run(args,cwd=cwd,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    elapsed=time.monotonic()-start
    after=git('rev-parse','HEAD')
    log=out/(name+'.log');log.write_text(p.stdout)
    receipt={'name':name,'command':args,'cwd':str(cwd),'environment':extra or {},'source_before':before,
        'source_after':after,'exit_code':p.returncode,'seconds':round(elapsed,3),'log':log.name,
        'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    if after!=source: raise RuntimeError('Source moved during '+name)
    return receipt

runs=[]
reporter=str(out/'resolved-project-reporter.cjs')
cli=str(repo/'node_modules/@playwright/test/cli.js')
for profile in ['full','lean']:
    runs.append(execute('discovery-'+profile,['node',cli,'test','--config=playwright.native.config.ts','--list','--reporter='+reporter],
        repo/'apps/web',{'GHOSTPAY_LOCAL_BUILD_PROFILE':profile,'GHOSTPAY_CHROMIUM':'/usr/bin/chromium',
            'NATIVE_REVIEW_REPORT':str(out/('resolved-'+profile+'.json'))}))
runs.append(execute('discovery-original-full',['node',cli,'test','--config=playwright.config.ts','--list','--reporter='+reporter],
    repo/'apps/web',{'GHOSTPAY_LOCAL_BUILD_PROFILE':'full','GHOSTPAY_CHROMIUM':'/usr/bin/chromium',
        'NATIVE_REVIEW_REPORT':str(out/'resolved-original-full.json')}))
runs.append(execute('typecheck',['npm','run','typecheck','--workspace','@ghostpay/web'],repo,{'NODE_OPTIONS':'--max-old-space-size=1536'}))
runs.append(execute('lint',['npm','exec','--','eslint','--config','eslint.config.js','apps/web/playwright.native.config.ts'],repo))
runs.append(execute('action-pins',['bash','scripts/check-actions-pinned.sh'],repo))
(out/'commands.json').write_text(json.dumps(runs,indent=2)+'\n')
for r in runs:
    print(json.dumps({k:r[k] for k in ['name','exit_code','seconds','source_before','source_after']}),flush=True)
if any(r['exit_code']!=0 for r in runs): raise SystemExit('An actual validation command failed; inspect logs.')

orig=json.load(open(out/'resolved-original-full.json'))
original={(t['file'],t['title']) for t in orig['tests'] if t['project']=='desktop'}
excluded_files={'e2e/qr-camera.spec.ts','e2e/qr-camera-multipart.spec.ts','e2e/clipboard-privacy.spec.ts'}
cdp='wiping the keys while the master backup KDF runs discards the result: no download'
expected=original-{t for t in original if t[0] in excluded_files or t[1]==cdp}
discovery=[]
for profile,counts in [('full',[136,136,5,5]),('lean',[126,126,5,5])]:
    r=json.load(open(out/('resolved-'+profile+'.json')))
    assert [p['tests'] for p in r['projects']]==counts
    assert len(r['projects'])==4
    for p in r['projects']:
        assert p['browserName']==('firefox' if p['name']=='firefox' else 'webkit')
        assert p['launchOptions']=={},p
        assert p['serviceWorkers']=='block'
        assert p['baseURL']=='http://localhost:4173'
        if p['name'].startswith('webkit-'): assert p['isMobile'] is True
    for engine in ['firefox','webkit']:
        tests=[t for t in r['tests'] if t['project']==engine]
        stealth=[t for t in tests if t['file']=='e2e/stealth-export.spec.ts']
        assert len(stealth)==9
        assert all(t['title']!=cdp and t['file'] not in excluded_files for t in tests)
        if profile=='full': assert {(t['file'],t['title']) for t in tests}==expected
    discovery.append({'profile':profile,'discovered':len(r['tests']),'projects':r['projects'],'executed':0})
(out/'discovery-validation.json').write_text(json.dumps({'source':source,'original_desktop':len(original),
    'intentionally_unselected_native_cases':len(original-expected),'native_desktop_set_equals_original_minus_documented_cases':True,
    'profiles':discovery},indent=2)+'\n')
print(json.dumps({'discovery_validated':True,'full':282,'lean':262,'application_browser_tests_executed':0}),flush=True)

wf=yaml.safe_load((repo/'.github/workflows/native-browser-qualification.yml').read_text())
assert wf['permissions']=={'contents':'read'}
assert wf['jobs']['native']['strategy']['matrix']=={'engine':['firefox','webkit'],'profile':['full','lean']}
assert wf['jobs']['native']['strategy']['fail-fast'] is False
assert 'continue-on-error' not in wf['jobs']['native']
steps=wf['jobs']['native']['steps']
step=next(s for s in steps if s.get('name')=='Record successful source identity')
assert 'if' not in step and not step.get('continue-on-error',False)
cases=[
 ('all-pass',{'stats':{'expected':3,'unexpected':0,'flaky':0,'skipped':0}},0,None),
 ('pass-and-skips',{'stats':{'expected':2,'unexpected':0,'flaky':0,'skipped':4}},0,None),
 ('pass-and-flaky',{'stats':{'expected':1,'unexpected':0,'flaky':1,'skipped':2}},0,None),
 ('empty',{'stats':{'expected':0,'unexpected':0,'flaky':0,'skipped':0}},1,None),
 ('all-skipped',{'stats':{'expected':0,'unexpected':0,'flaky':0,'skipped':8}},1,None),
 ('mixed-failure',{'stats':{'expected':2,'unexpected':1,'flaky':0,'skipped':0}},1,None),
 ('missing-file',None,1,None),
 ('invalid-json','{',1,None),
 ('missing-stats',{},1,None),
 ('missing-count',{'stats':{'expected':2,'unexpected':0,'skipped':0}},1,None),
 ('negative-count',{'stats':{'expected':2,'unexpected':0,'flaky':0,'skipped':-1}},1,None),
 ('fractional-count',{'stats':{'expected':2.5,'unexpected':0,'flaky':0,'skipped':0}},1,None),
 ('string-count',{'stats':{'expected':'2','unexpected':0,'flaky':0,'skipped':0}},1,None),
 ('wrong-source',{'stats':{'expected':2,'unexpected':0,'flaky':0,'skipped':0}},1,'0'*40),
]
guard=[]
for name,report,reject,head in cases:
    case=out/'stats-cases'/name
    target=case/'apps/web/test-results';target.mkdir(parents=True,exist_ok=True)
    if report is not None:
        (target/'native-results.json').write_text(report if isinstance(report,str) else json.dumps(report))
    env={'GIT_DIR':git('rev-parse','--absolute-git-dir'),'GIT_WORK_TREE':str(repo),
        'GITHUB_SHA':head or source,'PR_HEAD':source,'NATIVE_ENGINE':'webkit','BUILD_PROFILE':'full'}
    receipt=execute('stats-'+name,['bash','--noprofile','--norc','-e','-o','pipefail','-c',step['run']],case,env)
    assert (receipt['exit_code']!=0)==bool(reject),(name,receipt['exit_code'])
    artifact=target/'native-source.json'
    if reject: assert not artifact.exists(),name
    else:
        data=json.loads(artifact.read_text())
        assert data['source']==source and data['tree']==git('rev-parse','HEAD^{tree}')
        assert data['counts']=={'passed':report['stats']['expected'],'failed':report['stats']['unexpected'],
            'flaky':report['stats']['flaky'],'skipped':report['stats']['skipped']}
    guard.append({**receipt,'expected':'reject' if reject else 'accept','verdict':'passed'})
(out/'stats-guard-results.json').write_text(json.dumps({'source':source,'cases':guard,
    'passed':len(guard),'failed':0,'note':'Synthetic report guard checks; no browser or application tests executed.'},indent=2)+'\n')
print(json.dumps({'inline_guard_cases_passed':len(guard),'failed':0,'source':git('rev-parse','HEAD')}),flush=True)

const fs = require('node:fs');
const path = require('node:path');
module.exports = class {
  onBegin(config, suite) {
    const tests = suite.allTests();
    fs.writeFileSync(process.env.NATIVE_REVIEW_REPORT, JSON.stringify({
      projects: config.projects.map(p => ({name:p.name, browserName:p.use.browserName,
        launchOptions:p.use.launchOptions, viewport:p.use.viewport, isMobile:p.use.isMobile,
        baseURL:p.use.baseURL, serviceWorkers:p.use.serviceWorkers,
        tests:tests.filter(t => t.parent.project()?.name === p.name).length})),
      tests: tests.map(t => ({project:t.parent.project()?.name, file:path.relative(process.cwd(), t.location.file),
        title:t.title, expectedStatus:t.expectedStatus})),
      execution:'discovery only; no browser launched',
    }, null, 2) + '\n');
  }
};

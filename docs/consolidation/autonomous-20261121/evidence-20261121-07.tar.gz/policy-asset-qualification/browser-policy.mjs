import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { chromium, firefox, webkit } from '/workspace/scratch/5ceb6203640a/GhostPay-policy-asset/node_modules/playwright/index.mjs';

const root = '/workspace/scratch/5ceb6203640a/GhostPay-policy-asset';
const evidence = '/workspace/scratch/5ceb6203640a/policy-asset-recovery-evidence';
const origin = 'http://127.0.0.1:43175';
const records = JSON.parse(readFileSync(`${root}/packages/policy-scheme/vectors/client-v1.json`, 'utf8')).records.valid;
const canonical = (id) => records.find((record) => record.id === id).canonical;
const limited = JSON.parse(canonical('acct-001'));
const server = spawn('python3', ['-m', 'http.server', '43175', '--bind', '127.0.0.1', '--directory', `${root}/apps/web/dist`], { stdio: 'ignore' });
let started = false;
for (let attempt = 0; attempt < 40; attempt += 1) {
  try { const response = await fetch(origin); if (response.ok) { started = true; break; } } catch {}
  await new Promise((resolve) => setTimeout(resolve, 100));
}
assert.equal(started, true, 'the isolated local static server started');
const results = [];
const projects = [
  { name: 'chromium-desktop', engine: chromium, launch: { executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] }, viewport: { width: 1280, height: 900 } },
  { name: 'firefox-desktop', engine: firefox, launch: {}, viewport: { width: 1280, height: 900 } },
  { name: 'webkit-desktop', engine: webkit, launch: {}, viewport: { width: 1280, height: 900 } },
  { name: 'chromium-mobile', engine: chromium, launch: { executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] }, viewport: { width: 375, height: 812 }, isMobile: true, hasTouch: true },
];
try {
  for (const project of projects) {
    let browser;
    try {
      browser = await project.engine.launch({ headless: true, ...project.launch });
      const context = await browser.newContext({ viewport: project.viewport, isMobile: project.isMobile ?? false, hasTouch: project.hasTouch ?? false, serviceWorkers: 'block' });
      const blocked = [];
      await context.route('**/*', async (route) => {
        const url = route.request().url();
        if (new URL(url).origin !== origin) { blocked.push(url); await route.abort(); } else { await route.continue(); }
      });
      const page = await context.newPage();
      page.on('websocket', (socket) => blocked.push(socket.url()));
      const pageErrors = [];
      page.on('pageerror', (error) => pageErrors.push(error.message));
      await page.goto(origin);
      await page.getByRole('navigation', { name: 'Main' }).getByRole('button', { name: 'Policy accounts (experimental)' }).click();
      await page.getByLabel('Paste a policy record (JSON)').fill(canonical('acct-001'));
      await page.getByRole('button', { name: 'Import record', exact: true }).click();
      await page.getByText(/This policy can withdraw only: native, 0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48\./).waitFor();
      assert.match(await page.locator('main').innerText(), /A payment in any other token or coin stays locked in the account forever/);
      await page.getByLabel('Paste a policy record (JSON)').fill(canonical('acct-002'));
      await page.getByRole('button', { name: 'Import record', exact: true }).click();
      await page.getByText(/This policy has no limits: it can withdraw any token and the native coin\./).waitFor();
      const layout = await page.evaluate(() => ({ viewport: document.documentElement.clientWidth, scroll: document.documentElement.scrollWidth }));
      assert.ok(layout.scroll <= layout.viewport, 'asset disclosure has no horizontal overflow');
      assert.equal(await page.getByRole('button', { name: 'Send payment', exact: true }).count(), 0, 'no unverified deployment exposes a send action');
      assert.deepEqual(blocked, [], 'record inspection sends no external request');
      assert.deepEqual(pageErrors, [], 'no uncaught browser errors');
      await page.screenshot({ path: `${evidence}/${project.name}.png`, fullPage: true });
      await page.reload();
      await page.getByRole('navigation', { name: 'Main' }).getByRole('button', { name: 'Policy accounts (experimental)' }).click();
      assert.equal(await page.getByText(limited.metaAddress, { exact: true }).count(), 0, 'public record preview does not survive a reload');
      results.push({ name: project.name, outcome: 'passed', browserVersion: browser.version(), viewport: project.viewport, layout, externalRequests: blocked.length, scenarios: ['limited and unrestricted asset disclosures', 'unverified deployment cannot send', 'same-origin requests only', 'reload clears imported record preview'] });
      await context.close();
    } catch (error) {
      results.push({ name: project.name, outcome: 'failed', error: error.stack ?? String(error) });
    } finally { await browser?.close(); }
  }
} finally {
  server.kill('SIGTERM');
}
writeFileSync(`${evidence}/browser-policy.json`, `${JSON.stringify(results, null, 2)}\n`);
console.log(JSON.stringify(results, null, 2));
if (results.some((result) => result.outcome !== 'passed')) process.exitCode = 1;

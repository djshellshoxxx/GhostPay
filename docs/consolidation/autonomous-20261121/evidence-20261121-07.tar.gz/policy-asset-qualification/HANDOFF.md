# Policy asset coverage recovery — final handoff

Component evidence for the root coordinator's authoritative GhostPay ledger. This packet is not a separate repository-wide completion ledger.

## Outcome and exact source

Implemented the missing client-side withdrawal-asset coverage guard and its seller/payer presentation. Source is frozen at **`e1ab03ca7b07c225ae42d0c16fb79b97f0a1f95c`**, tree **`fbb88d447ca4a60275bcd28d3256b03a77c47a3e`**, on `recover/ghostpay-policy-asset-coverage-20261121-5ceb` in `GhostPay-policy-asset`.

A fresh independent reviewer (`/root/policy_asset_final_review`) found **no blocking issue in this bounded corrected patch**. This is independent engineering review, not a formal GitHub approval or an external audit. Full web coverage completed on the exact clean source, with the original thresholds unchanged. Required native/hosted gates remain open, and the integration lock remains held by `994a0d214fb9-root-r3`, generation 11.

The worker made no remote mutation or parent/main merge. Root owns publication as an isolated child of #368. Preserve the real public histories:

| Input | Exact commit |
| --- | --- |
| #368 policy recovery and security classification chain | `18d0442a156106abe2309f8a6e82358aab37961a` |
| Current main snapshot | `eb59d93cffed7848c4aac37d0e9650b87239c6da` |
| #345 pending review revocation, including #359 | `ccc8c3521511e2a2b9b66ef11f12723d87ce5f44` |
| Selective original source, #211 | `a92658b1ef6b95ff0145b2e1933d0047d51289d5` |
| Local composition before authored source/tests | `1d38928896cac2d5342363fc6eff13c6fbfdf28c` |

`input-ancestry.json` proves that #357, #362, #368, #345 and the main snapshot are all ancestors. `source-provenance.json` records the full local parent history, each changed blob and file hash, unchanged authority boundaries, dependency lock hash and installed browser versions. The verified 23,117-byte Git bundle preserves every local red/green commit and requires only the three public inputs above; its SHA-256 is `26b54adf715c74493ad1df19dbe1cc71c1f8cabc769baee882eca708640e7753`.

## What changed and why

The contract fixes its limits root at initialization. A nonzero root permits withdrawal only for assets with a valid leaf; the payment router can still receive other assets. The recovered helper rebuilds the public limits tree and verifies the selected token leaf, treats native coin consistently, and fails closed for missing, mismatched, appended, duplicated or malformed trees.

Payment preparation refuses known unsupported native or ERC-20 assets before deriving a payment. The same guard is composed with the existing session, deployment and synchronous form-review authority checks at every wallet request. The records reference updates at React commit, so an import during an asynchronous wallet-account check is observed before the transaction request. An import after a mined approval still stops the payment and preserves the existing approval-hash/remaining-allowance warning.

The first implementation matched both seller keys for all results. Independent review confirmed a useful distinction: a validated **policy hash proves the same immutable asset terms even for different seller keys**, but it does not prove seller identity. The corrected guard therefore uses any valid same-hash terms to refuse an unsupported asset, while positive “checked payee record” confirmation and all recovery selection still require both exact seller keys. A separate security-sensitive refusal message avoids attributing the other seller's record to the payee.

Seller records show permitted assets or an unrestricted policy. Payer reviews keep absent/unverified coverage explicit. Seven new catalog messages are classified as security-sensitive, including the same-commitment refusal. Existing locale metadata and fallback/native-review rules are preserved. The original four SEC-11 UI tests and five package cases remain intact; extra tests cover native-only exclusion, both different-key variants, late imports, wallet-boundary races and a mined approval.

Authored scope is 14 files: package `record.ts`, `index.ts`, `record.coverage.test.ts`; web policy `pay.ts`, `PolicyPay.tsx`, `PolicyCreate.tsx`, `PolicyAssetCoverage.test.tsx`, `pay.assetCoverage.test.ts`; two security-key files; and four locale files. The exact file manifest is in JSON. The record-identity helper, sender, pending-edit regression, record-download regression and contract source match the composition exactly.

## Reproduced failures and corrective review

| Source and run | Actual result |
| --- | --- |
| `cc6ac284...`, original asset UI cases plus direct preparation refusals | 0 passed, 6 failed, 0 skipped |
| `7b3da7f7...`, paused-wallet late-record regression | 1 failed, 4 filtered skips; one mock wallet transaction request observed |
| `d101c5db...`, same-hash negative cases plus all asset cases | 11 passed, 3 failed, 0 skipped; both differing-key cases and other-seller wallet race failed |
| `e1ab03ca...`, corrected focused composition | 33 passed, 0 failed, 0 skipped |

All transaction requests in reproductions used local mock wallets; no blockchain transaction or real funds were used. The initial independent review is retained with its `correction_required` disposition. The fresh final reviewer independently reproduced the same-hash red baseline, then passed 33 focused tests, 57 authority tests and 94 package tests with 7 native skips, plus web typechecking and scoped lint.

## Executed qualification

The corrected-source command receipts include start/end UTC, exact before/after SHA/tree and clean status, exit code, duration and log SHA-256. Full commands and raw Vitest results are in `HANDOFF.json` and the named files; separate rows overlap and must not be summed into an invented unique-test total.

| Check | Result on corrected `e1ab03ca` |
| --- | --- |
| Complete web coverage pass | **2,837 passed, 0 failed, 13 native skips**, 208 files; 396.714 seconds |
| Web coverage | statements 93.30%, branches 89.54%, functions 94.82%, lines 97.03%; existing gates passed |
| Separate no-coverage web pass | **3 passed, 0 failed, 0 skipped** |
| Focused asset/revocation/identity/download/security cases | **33 passed, 0 failed, 0 skipped** |
| Complete policy package with coverage | **94 passed, 0 failed, 7 native skips** |
| Policy coverage | statements 97.22%, branches 94.93%, functions 100%, lines 99.75%; existing gates passed |
| TypeScript, policy package and web | Passed |
| ESLint, policy package and complete web source/e2e scope | Passed |
| Catalog completeness and security-key classification | Passed |
| Committed secret scan | Passed |
| Full and lean static builds, including bundle scanners | Passed; 19 full / 17 lean files hashed |

Initial setup used its own `npm ci --ignore-scripts --no-audit --no-fund` (722 packages) and all 65 library builds. No shared installation/build writes occurred. The baseline build crossed test-only commits; all package input trees were proven identical. Package dependencies and contract source are unchanged.

The unchanged dependency audit ran before the last correction: exit 0 at the high-severity threshold, **0 high/critical/moderate, 17 low** findings. Its exact report and lock hash are retained; this is not a zero-findings claim.

One environment-smoke invocation on **the earlier `7196b29e` source** actually passed its bounded Firefox 157.0 desktop scenario: limited/unrestricted record notices, no send without a verified deployment, zero external requests, no page overflow, and cleared record preview after reload. This composition's actual Playwright 1.64.1 manifest pins Firefox revision 1555; no cached-version substitution or install occurred. System Chromium desktop/mobile launches failed with socket `EPERM`; WebKit could not launch because host libraries were missing. No final-source native-browser qualification is claimed, and no further launches were attempted.

Artifact/release-tooling fixtures on the earlier source produced **54 passed, 1 failed, 0 skipped**: the PGP tag fixture could not start `gpg-agent`. Those tooling sources are unchanged. No release was generated or published. The first full web run on `7196b29e` was explicitly terminated with exit 130 for the correction and is not counted as passed.

## Remaining gates and handoff

1. Execute the seven package real-contract and thirteen web native cases in the required hosted environment. `corrected-web-skipped.json` records each web skip; the package JSON records all seven cases. The web skips comprise one live Bitcoin regtest, four policy Anvil cases and eight registry Anvil cases.
2. Obtain required native Chromium/Firefox/WebKit and mobile qualification on the final published source, using its lockfile-pinned versions. Keep policy deployment admission intact; no production deployment bypass is authorized. The available native smoke exercised record disclosure only; payer authority races use the actual mock-wallet UI tests.
3. Complete the PGP tag fixture on a host where its required agent can start. Observe all required GitHub checks and approvals on the actual published head.
4. Resolve the existing integration owner before parent or main merges. Do not replace the held lease based on expiry.
5. The fresh hardening worker owns the separate N09/N10/N11 child from `e1ab03ca`; keep the asset, identity and review-revocation boundaries intact. This recovery does **not** claim all of #211 is incorporated. The separate SEC-12 rollup-delay hint and other broad donor changes are also outside scope.

No contract, dependency, fee, custody, fund-control, deployment, release or real-transaction behavior was added. Policy remains experimental and off by default, with no pinned deployment. This UI supports native/plain ERC-20 funding; the unchanged sender rejects nonzero ERC-20 native-buffer value and the regression pins that boundary. Unknown coverage is a limitation, not a recovery guarantee or an automatic refund claim.

Root requested the exact source tree remain frozen, so this final evidence packet is external to the worktree and ready for inclusion in the authoritative repository ledger without a documentation-only requeue. No further source changes are planned in this worker.

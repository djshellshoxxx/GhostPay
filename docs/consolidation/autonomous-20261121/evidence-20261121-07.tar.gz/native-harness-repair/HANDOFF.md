# Native-browser harness repair handoff

## Frozen source and scope

- Worker: `/root/native_harness_repair`; coordinator: `/root`.
- Branch: `repair/ghostpay-native-harness-20261121-5ceb`.
- Base public source: `22569e2a83e3f8bc3c86982f69bbb1d90ca8356c`.
- Frozen source: **`5ed15080db47aeccffc1ed9dbd4aeac4bfc1dff6`**.
- Tree: **`703d11bf70413432ed821b3020552d4c3b0e5e96`**.
- Worktree: `/workspace/scratch/5ceb6203640a/GhostPay-native-harness`.

The worktree is clean and all author processes are stopped. This author has not
modified remote refs, the existing source PR, parent targets, main, the held
integration lease, deployments, releases or real-funds state. Application source,
packages, dependency manifests and the original/native Playwright configurations
remain byte-for-byte equal to the base. Root separately owns the ContextHelp
source and geometry correction.

## Source-supported changes

1. **Real redirect responses.** Pinned Playwright's WebKit route implementation
   throws for every fulfilled status from 300 through 399. The new test-only
   loopback HTTP proxy forwards the unchanged built site and emits actual 302/307
   responses only for an explicitly marked startup hash request. The browser runs
   on the proxy's own origin, so no cross-origin rewrite or CSP exception is
   needed. Original no-follow, no-destination-request, reload and privacy-settings
   assertions remain; new assertions verify that the server actually emitted the
   expected responses. The fixture binds only loopback and refuses non-loopback
   upstreams. It is not imported by the product.
2. **Clock-instrumented history entry.** The failing WebKit `about:blank` page lacks
   Playwright's installed clock controller. The history test now visits an inert
   local HTTP document, advances the same installed clock, and uses real back
   navigation. Both key-absence assertions remain. This does not claim the browser
   selected BFCache or model physical sleep.
3. **Observe the existing host-yield fallback.** Pinned noble hashes 2.4.0 uses
   `setTimeout(resolve, 0)` where `scheduler.yield` is absent. The probe now observes
   that existing path through a forwarding Proxy; it does not introduce a scheduler
   shim, replace callbacks/results, change timing or reduce KDF cost. Ordinary
   contract tests verify receiver/arguments/return-handle preservation, original
   scheduler promises and rejections, AES result identities and explicit hold/release.
   The documentation accurately calls the counter scheduling evidence, not an
   independent proof of KDF completion. Existing browser tests still require the
   real AES operation and unchanged idle/retained-key assertions.
4. **Establish loaded-payment readiness before measuring revocation.** Two tests
   navigate by invoice fragment and then rely on `networkidle`, which may already
   be satisfied from the prior document state while asynchronous preflight is
   completing. The observed baselines contained only 5 or 6 of the eventual 7
   requests. Both tests now wait for the existing Continue-enabled condition before
   measuring the loaded state described by their titles. Every zero-new-request,
   new-provider, raw-transaction and unexpected-method assertion remains unchanged.
   Method/origin/failure diagnostics are attached before the comparison. Final
   hosted execution is still required; no production cancellation defect is declared
   resolved on static reasoning alone.
5. **Preserve Firefox crash diagnostics.** The page crashes, mostly during
   `axe.run`, remain unexplained. No axe rule or audit was disabled. The workflow
   now records browser process stderr, source identity and failure traces, preserving
   shell `pipefail` and the original success-report guard. The eight fixture tests
   run before each native matrix job. No browser preference or production policy
   changes are included.

## Actual execution

| Check | Result |
|---|---|
| Independent local dependency installation | `npm ci --ignore-scripts`, exit 0; 721 packages in 12 seconds |
| Library build | `npm run build:packages`, exit 0 |
| HTTP fixture contract selection | 2 passed, 0 failed/skipped |
| First crypto probe test attempt | 5 passed, 1 failed; retained as failure |
| Corrected combined fixture selection | **8 passed, 0 failed, 0 skipped** |
| Scoped ESLint | Exit 0 for four changed TypeScript files; three MJS files were ignored by the repository configuration |
| Node syntax checks | All three new MJS files passed; these files were also executed by the fixture tests |
| Full web TypeScript | **Exit 137**, killed after 28.099 seconds with a 1,536 MiB heap; no compiler diagnostics; **not passed** |
| Source/assertion preservation verifier | Passed at exact frozen source |
| Diff whitespace | Passed |

The corrected fixture tests wait for an actual AES-hold marker. The first test
attempt incorrectly assumed a single microtask would settle a cross-realm await;
the initial failure is retained and no assertion was removed.

The TypeScript exit occurred while other workers also had heavy checks active.
Resource contention is a working explanation, not a proven compiler result. Root
is coordinating one isolated check after those processes stop. This author did
not retry it or claim a pass.

`source-preservation.json` records all **258 original nested expect-expression
AST calls** and **19 literal test titles** retained across the four inspected
files. These are structural counts, not 258 independent assertions or 19 total
parameterized cases. Every existing original expression remains with the same
arguments after whitespace normalization. Of 5,767 base tree entries, **5,761
remain identical**; six original paths change and four new support/test paths
are added. No application, package, dependency or Playwright configuration path
changes.

## Hosted failures remain failures

The copied logs below concern the **uncorrected public base** and are preserved
for exact comparison. This author has not run the corrected native matrix.

| Job | Profile/engine | Passed | Failed | Skipped |
|---|---|---:|---:|---:|
| 136780385669 | lean WebKit, including viewport projects | 126 | 5 | 5 |
| 136780385891 | lean Firefox | 109 | 12 | 5 |
| 136780385899 | full WebKit, including viewport projects | 139 | 5 | 2 |
| 136780385946 | full Firefox | 124 | 10 | 2 |

The locally cached Firefox 1555 and WebKit 2370 differ from the required Firefox
1572 and WebKit 2388 pinned by Playwright 1.65.1. No older engine was substituted
and no native browser, mobile or Tor qualification is claimed. Full application
suites, release checks, source review, final action-pin and secret scans, and
hosted reruns remain separate gates.

## Next actions

1. Compose these nonoverlapping paths with root's separately reviewed ContextHelp
   candidate `59fb5f0d2a8f28b8572fe19a9e7f7ca5039705db` in an owned isolated branch.
2. Obtain fresh independent source review of the whole composition, including the
   loopback fixture and preserved test semantics. Run one coordinated full web
   TypeScript check with other heavy processes idle.
3. Publish through root to an owned source ref and execute exact-head native and
   original Chromium gates. Inspect native stderr/traces before changing Firefox
   behavior. Do not turn unexecuted, failed or skipped checks into passes.
4. Retain the original generation-11 shared integration hold until its prior owner
   has been reconciled. No shared-target merge is included in this handoff.

The packet includes source/provenance, complete command outputs and individual
TypeScript/lint receipts, copied failed hosted logs, a source diff, a recovery
bundle and a content manifest. `EXECUTION_SUMMARY.json` distinguishes executable
evidence from syntax/static checks and unexecuted gates.

## Primary references inspected

- Installed `playwright-core/lib/coreBundle.js`: WebKit `fulfill` rejects 3xx;
  Clock calls the installed controller in all frames.
- Installed `@noble/hashes/utils.js`: `nextTick` preserves scheduler yield when
  available and otherwise returns a zero-delay timeout promise.
- [Playwright Route API](https://playwright.dev/docs/api/class-route).
- [Playwright Clock guide](https://playwright.dev/docs/clock).
- [Playwright debugging guide](https://playwright.dev/docs/debug).

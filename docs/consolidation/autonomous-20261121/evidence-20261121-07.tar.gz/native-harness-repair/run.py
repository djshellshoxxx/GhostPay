import datetime,json,pathlib,subprocess,sys,time,os
root=pathlib.Path('/workspace/scratch/5ceb6203640a/GhostPay-native-harness')
out=pathlib.Path('/workspace/scratch/5ceb6203640a/native-harness-evidence')
label=sys.argv[1];cmd=sys.argv[2:]
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
def source():return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'tracked_status':git('status','--porcelain','--untracked-files=no')}
record={'label':label,'command':cmd,'cwd':str(root),'env_overrides':{'NODE_OPTIONS':'--max-old-space-size=1536'},'source_before':source(),'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
start=time.monotonic();env=dict(os.environ,NODE_OPTIONS='--max-old-space-size=1536')
with (out/(label+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record.update(exit_code=p.returncode,duration_seconds=round(time.monotonic()-start,3),finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_after=source(),log=label+'.log')
(out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
sys.exit(p.returncode)

import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { writeFileSync } from 'node:fs';
import ts from '/workspace/scratch/5ceb6203640a/GhostPay-native-harness/node_modules/typescript/lib/typescript.js';
const cwd='/workspace/scratch/5ceb6203640a/GhostPay-native-harness';
const base='22569e2a83e3f8bc3c86982f69bbb1d90ca8356c';
const git=(...args)=>execFileSync('git',args,{cwd,encoding:'utf8'}).trim();
const head=git('rev-parse','HEAD');
const paths=['apps/web/e2e/network-isolation.spec.ts','apps/web/e2e/idle-session.spec.ts','apps/web/e2e/network-authorization.spec.ts','apps/web/e2e/stealthExportFixtures.ts'];
function calls(text){const file=ts.createSourceFile('fixture.ts',text,ts.ScriptTarget.Latest,true);const assertions=[],titles=[];function visit(n){if(ts.isCallExpression(n)){const raw=n.getText(file);if(/^expect(?:\.|\()/.test(raw))assertions.push(raw.replace(/\s+/g,' '));if(n.arguments[0]&&ts.isStringLiteral(n.arguments[0])&&['test','redirectTest'].includes(n.expression.getText(file)))titles.push(n.arguments[0].text);}ts.forEachChild(n,visit);}visit(file);return{assertions,titles};}
const checks=[];
for(const path of paths){const before=calls(git('show',`${base}:${path}`)),after=calls(git('show',`${head}:${path}`));const remaining=[...after.assertions];for(const assertion of before.assertions){const index=remaining.indexOf(assertion);assert.notEqual(index,-1,`${path}: missing original assertion ${assertion}`);remaining.splice(index,1);}assert.deepEqual(after.titles,before.titles);checks.push({path,original_assertion_calls:before.assertions.length,current_assertion_calls:after.assertions.length,original_test_titles:before.titles.length,all_original_assertions_and_titles_preserved:true});}
function tree(ref){return new Map(git('ls-tree','-r',ref).split('\n').filter(Boolean).map(line=>{const [meta,path]=line.split('\t');return[path,meta];}));}
const before=tree(base),after=tree(head),changed=[...new Set([...before.keys(),...after.keys()])].filter(path=>before.get(path)!==after.get(path));
const protectedPaths=['apps/web/src/','packages/','package.json','package-lock.json','apps/web/playwright.config.ts','apps/web/playwright.native.config.ts','apps/web/vite.config.ts','apps/web/tsconfig.json'];
for(const path of changed)assert.ok(!protectedPaths.some(protectedPath=>protectedPath.endsWith('/')?path.startsWith(protectedPath):path===protectedPath),`Protected source changed: ${path}`);
const result={base,head,tree:git('rev-parse','HEAD^{tree}'),checks,original_entries:before.size,unchanged_original_entries:[...before].filter(([path,meta])=>after.get(path)===meta).length,changed_paths:changed,protected_paths_unchanged:protectedPaths,tracked_status:git('status','--porcelain','--untracked-files=no')};
assert.equal(result.tracked_status,'');
writeFileSync('/workspace/scratch/5ceb6203640a/native-harness-evidence/source-preservation.json',JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result));

import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/scratch/5ceb6203640a/GhostPay-policy-asset')
OUT = pathlib.Path(__file__).resolve().parent
EXPECTED = '7196b29e66e3699b5d4764b8f7c16a66ae673a75'


def snapshot():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--short')}


label, *command = sys.argv[1:]
before = snapshot()
if before['head'] != EXPECTED or before['status']:
    raise RuntimeError(f'Source is not the clean frozen review input: {before}')
began = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
log = OUT / (label + '.log')
with log.open('wb') as stream:
    result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
record = {'command': command, 'cwd': str(ROOT), 'start_utc': began,
          'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'duration_seconds': round(time.monotonic() - start, 3),
          'returncode': result.returncode, 'before': before, 'after': snapshot(),
          'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
(OUT / (label + '.run.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
raise SystemExit(result.returncode)

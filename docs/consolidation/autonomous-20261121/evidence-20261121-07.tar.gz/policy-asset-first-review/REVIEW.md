# Independent policy asset-coverage review

**Disposition: correction requested before this source is qualified.** One in-scope semantic finding was independently reproduced. The original missing-coverage and late-wallet defects were also reproduced, and all existing tests selected on the candidate passed. Green existing tests do not close the new finding.

| Input | Exact commit |
| --- | --- |
| Reviewed candidate | `7196b29e66e3699b5d4764b8f7c16a66ae673a75` |
| Reviewed tree | `f57ade23b1bde1abfb66757f0c0eec4a0c55fb6e` |
| Composition before asset recovery | `1d38928896cac2d5342363fc6eff13c6fbfdf28c` |
| Historical donor #211 | `a92658b1ef6b95ff0145b2e1933d0047d51289d5` |
| Policy identity/translation parent #368 | `18d0442a156106abe2309f8a6e82358aab37961a` |
| Pending-review authority parent #345 | `ccc8c3521511e2a2b9b66ef11f12723d87ce5f44` |

Reviewer: independent worker `/root/policy_asset_independent`. Author: `/root/policy_asset_recovery`. Review started from repository `AGENTS.md`, `docs/ai/WORKFLOW.md`, `docs/ai/HANDOFF.md`, the current task ownership claim, the residual #211 recovery packet, and current source. Live #211 metadata confirmed the donor head above; its historical test claims were not counted as this review's executions.

All fourteen changed paths were reviewed. Context included the seller-record selector, record parsing and freezing, policy hash construction, limits/proof construction, transaction building, sender's last authority checks, record import/recovery paths, critical-translation classification and the relevant `PolicyAccount` withdrawal checks. The diff command was `git diff 1d38928896cac2d5342363fc6eff13c6fbfdf28c...7196b29e66e3699b5d4764b8f7c16a66ae673a75`.

## Standards

No documented coding-standard violation was identified in the scoped diff. The new helper is a local computation, the component reuses the existing send guard, and production changes are limited to the claimed client/package/catalog paths. No new dependency, workflow, contract, server, CLI, network endpoint or deployment change appears in the scoped diff. Source hashes and seven exact donor/parent preservation checks are in `source-preservation.json`.

The standards and spec axes were performed by this one independent reviewer; they are not claimed as two separately staffed reviews. The four team slots were already occupied. This worker did not modify the authored source or dependency installation.

## Spec

### Correction required: keep negative evidence from matching policy terms

`assertPayeeTokenCoverage` currently requires exact seller keys before checking any limits. A valid record with the same policy hash but different seller keys therefore returns `unknown` even when the committed limits exclude the proposed asset. The policy hash commits the destination, delay and immutable limits root; the other seller's validated record still proves those same asset restrictions. Discarding that negative evidence weakens the recovered guard.

The author raised this identity-versus-terms distinction during review. The reviewer confirmed it against `computePolicyHash`, `PolicyAccount.initialize` and `requestWithdraw`, and independently reproduced both differing-key cases with a one-line test-only expectation change. See `FINDING_SAME_POLICY_TERMS.md`, `same-hash-negative-regression.patch` and the corresponding RED output.

**Requested correction:** refuse unsupported assets when any validated same-policy-hash record proves the asset absent. Continue requiring exact seller identity for the positive `covered` label and all recovery-record association. Keep the current-record recheck at every wallet boundary. Update refusal copy so it describes matching policy terms without claiming an unrelated seller's record is the payee's own record.

### Boundaries otherwise verified

- The recovered `record.ts` is byte-identical to donor #211. It rebuilds the limits tree, validates the root and proves the requested token leaf; it does not trust an appended leaf or stored leaf hash alone. Existing parsing binds the policy preimage and meta-address commitment, and freezes validated records and their trees.
- Preparation checks known coverage before deriving an ephemeral payment. Unknown records remain an explicit warning. Native-coin and ERC-20 checks use the existing zero-address convention. This browser path prepares `payNative` or `payERC20`; ERC-20 value remains zero. The patch does not add the package's separate native-buffer payment mode.
- The new guard reads records through a layout-effect-updated ref and retains the existing synchronous review revision, session version and deployment checks. Existing mock-wallet tests confirm that a record imported during an awaited wallet account check prevents a new send.
- Refusal after an already mined approval retains the approval hash and allowance warning. The sender's existing single-use and duplicate-attempt handling remains unchanged.
- Seller selection, record-download identity and the #345 pending-edit regression remain exact parent blobs. Six new critical message keys are classified as security text. All prior messages in each of four catalogs remain unchanged; new draft-locale values retain source English.

## Executed verification

Commands, timestamps, source/tree snapshots, exit codes and raw-output hashes are in the respective `*.run.json` files; JSON reports preserve individual test names and results.

| Run | Actual result | Source and interpretation |
| --- | --- | --- |
| Six focused web files | **32 passed, 0 failed, 0 skipped**, 7.110 s | Exact candidate 7196; coverage, late wallet import, pending edit, seller identity, download identity, security keys |
| Full policy package without coverage collection | **94 passed, 0 failed, 7 skipped**, 2.812 s | Exact candidate 7196; seven Anvil cases skipped by the existing prerequisites; includes four property tests |
| Original two-file baseline selection | **0 passed, 6 failed, 0 skipped**, 6.215 s | Application source `cc6ac284a654ba4219381f3ab98661ee9e2a65c2`: missing UI assertions plus direct unsupported ERC-20/native preparation failures |
| Original wallet-pause baseline | **0 passed, 1 failed, 4 excluded by name filter**, 4.311 s | Application source `7b3da7f7aa3bd4aaa8138b890c0cc1ea7dc8d6d7`: one mock `eth_sendTransaction` occurred where zero was required |
| New same-policy-hash negative-evidence regression | **0 passed, 2 failed, 6 excluded by name filter**, 1.780 s | Candidate 7196 plus isolated test-only patch; both different-spending-key and different-viewing-key cases returned normally instead of refusing |
| Source preservation | **7/7 exact blob checks**, four catalogs retain all prior message values | `source-preservation.json` |
| Scope and whitespace | **Passed** | No package manifest, lockfile, workflow, contract, relayer or CLI delta in this patch; `git diff --check` exit 0 |

Runtime: Node 24.22.3, npm 11.19.1. Candidate test runs used the author's already prepared dependency installation without installing, building, editing or cleaning it. They left source HEAD/tree/status unchanged. Tests used local deterministic fixtures and mock wallet/RPC services, not live transactions.

The isolated baseline reproductions reused the candidate dependency installation read-only. Workspace package exports therefore resolved to candidate builds. The policy package addition is an unused coverage export on those baseline application paths; preexisting package behavior is unchanged. These runs establish baseline application failures, **not a clean baseline build qualification**. This caveat is also embedded in each baseline receipt. The isolated test-only patch was saved, restored to HEAD and its temporary dependency symlink removed after execution.

This reviewer did not rerun coverage thresholds, full web tests, typecheck, lint, builds, dependency audit, secret scan, native browser tests, mobile emulation or Tor routing. Author results for those checks are separate evidence. No native-chain, external-audit or formal GitHub approval is claimed here.

## Additional inherited recovery work identified

Reading #211's source-pinned security closure exposed other concrete donor implementations absent from candidate 7196: canonical router calldata/R/metadata validation; typed-data shape and digest-snapshot validation; recomputing withdrawal and restored-tree leaf fields; validating before copying the viewing secret; and binding the derived ephemeral key/metadata at the browser send boundary.

Their original commits and paths are preserved in `inherited-policy-followup.json`; the relevant donor diff is `inherited-policy-followup.diff`. This is an explicit follow-up for a separate bounded recovery assignment. No executable failure or completed disposition for those inherited findings is claimed by this asset-focused review. Do not treat recovery of the asset guard as recovery of all unique #211 code, and do not apply the entire historical branch wholesale.

## Handoff and remaining gates

1. Author implements the same-policy-hash negative-evidence correction and regression, retaining exact seller identity for positive status and recovery.
2. A fresh independent reviewer verifies the final corrected head, its truthful copy, relevant RED-to-GREEN behavior and source preservation.
3. Coordinator separately qualifies the final published source with required hosted gates and resolves the integration ownership hold. The existing held lease remains unchanged; this review grants no authority to acquire it or merge.
4. Assign the recorded inherited policy-hardening recovery as a separate task.

All authored repository files, refs, integration metadata and remote PRs were left untouched by this reviewer. Review evidence is ready for the coordinator's authoritative ledger. No merge, deployment, release or real-funds operation occurred.

Standards: **0 findings**. Spec: **1 correction required**, negative evidence from matching policy terms; unresolved on reviewed source 7196.

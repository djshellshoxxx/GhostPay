import datetime
import hashlib
import json
import pathlib
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/scratch/5ceb6203640a/GhostPay-policy-independent-baseline')
OUT = pathlib.Path(__file__).resolve().parent
label, expected, *command = sys.argv[1:]


def snapshot():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--short'), 'tracked_diff': git('diff', '--name-only'),
            'staged_diff': git('diff', '--cached', '--name-only')}


before = snapshot()
assert before['head'] == expected and not before['tracked_diff'] and not before['staged_diff']
assert before['status'] == '?? node_modules'
assert (ROOT / 'node_modules').resolve() == pathlib.Path('/workspace/scratch/5ceb6203640a/GhostPay-policy-asset/node_modules')
start_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
log = OUT / (label + '.log')
with log.open('wb') as stream:
    result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT)
record = {'command': command, 'cwd': str(ROOT), 'start_utc': start_utc,
          'end_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'duration_seconds': round(time.monotonic() - start, 3), 'returncode': result.returncode,
          'before': before, 'after': snapshot(),
          'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest(),
          'dependency_reuse': 'Read-only reuse of candidate dependency installation. Workspace package exports resolve to candidate builds; package policy changes only add the unused coverage export. This run reproduces baseline application behavior and is not a clean baseline build qualification.'}
(OUT / (label + '.run.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
raise SystemExit(result.returncode)

# Review finding: retain negative evidence from equal policy commitments

Status: correction requested. Initial reviewed source `7196b29e66e3699b5d4764b8f7c16a66ae673a75`, tree `f57ade23b1bde1abfb66757f0c0eec4a0c55fb6e`.

## Spec finding

The candidate's `assertPayeeTokenCoverage` searches for both seller keys and the policy hash before inspecting withdrawal coverage. Consequently, a validated record with equal policy terms and different seller keys is classified as entirely unknown, even when its committed limits exclude the payment asset. This unnecessarily drops available negative evidence that the recovered SEC-11 guard should enforce.

`computePolicyHash` commits `destination`, `delaySeconds` and `limitsRoot`. `PolicyAccount.initialize` computes the identical hash. `requestWithdraw` requires a token leaf against the immutable `limitsRoot`. A validated, equal-hash policy record therefore proves the same withdrawal restrictions irrespective of the seller keys used in its meta-address. This does not establish that the record belongs to the payee or grants any recovery/signing authority.

The author raised the identity/terms distinction during review. The independent reviewer confirmed it against the hash and contract implementation, then executed a bounded regression in an isolated checkout. Only one assertion in the two-case differing-key test was changed: unsupported DAI should throw instead of returning `unknown`. Both cases failed because the function returned normally. The positive coverage assertion remains `unknown` for the other seller.

## Executed evidence

- Source: `7196b29e66e3699b5d4764b8f7c16a66ae673a75` plus the isolated test-only `same-hash-negative-regression.patch`.
- Command, source snapshots and output hashes: `same-hash-negative-red.run.json`.
- Actual result: **2 failed, 0 passed, 6 excluded by the test-name filter**; duration 1.780 seconds.
- Complete output: `same-hash-negative-red.vitest.json`; concise errors: `same-hash-negative-red-summary.json`.
- Authored source and shared dependencies were not edited. No network provider or wallet transaction was used; this was a local mock regression.

## Bounded correction requested

Refuse an unsupported asset when any validated record with the same policy commitment proves it has no withdrawal leaf. Continue requiring exact seller identity for the positive `covered` label and every recovery-record association. Preserve the current-record recheck at each wallet boundary. Ensure the refusal message describes matching policy terms without claiming that an unrelated seller's record is the payee's own record.

Recheck differing spending-key and viewing-key records, allowed assets retaining `unknown`, unrelated policy hashes retaining `unknown`, both ordinary and late-import wallet checks, and post-approval evidence retention. No contract, sender, recovery identity, dependency, gate or network changes are needed.

from pathlib import Path
import subprocess,json,hashlib,datetime,time,os,sys
ROOT=Path('/workspace/scratch/5ceb6203640a')
CWD=ROOT/'GhostPay-policy-asset'
OUT=ROOT/'policy-asset-final-review-evidence'
HEAD='e1ab03ca7b07c225ae42d0c16fb79b97f0a1f95c'
def snapshot(cwd):
 def git(*args): return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
 return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain')}
def run(name,cmd,cwd=CWD):
 before=snapshot(cwd);assert before['head']==HEAD,before
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();t=time.monotonic()
 with (OUT/(name+'.log')).open('w') as log: proc=subprocess.run(cmd,cwd=cwd,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'CI':'true'})
 after=snapshot(cwd)
 receipt={'command':cmd,'cwd':str(cwd),'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'duration_seconds':round(time.monotonic()-t,3),'returncode':proc.returncode,'before':before,'after':after,'source_unchanged':before==after,'log_sha256':hashlib.sha256((OUT/(name+'.log')).read_bytes()).hexdigest()}
 (OUT/(name+'.run.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'run':name,'returncode':proc.returncode,'source_unchanged':before==after}),flush=True)
 assert before==after,receipt
 return proc.returncode
if __name__=='__main__':
 name=sys.argv[1]
 if name=='focused-web':
  files=['src/features/policy/PolicyAssetCoverage.test.tsx','src/features/policy/pay.assetCoverage.test.ts','src/features/policy/PolicyPay.pendingEdit.test.tsx','src/features/policy/PolicyView.recordIdentity.test.tsx','src/features/policy/PolicyCreate.recordDownloads.test.tsx','src/i18n/securityKeys.test.ts']
  cmd=['npm','exec','-w','@ghostpay/web','--','vitest','run',*files,'--maxWorkers=2','--reporter=json','--outputFile='+str(OUT/(name+'.vitest.json'))]
 elif name=='policy-package': cmd=['npm','exec','-w','@ghostpay/policy-scheme','--','vitest','run','--maxWorkers=2','--reporter=json','--outputFile='+str(OUT/(name+'.vitest.json'))]
 elif name=='send-authority': cmd=['npm','exec','-w','@ghostpay/web','--','vitest','run','src/features/policy/send.test.ts','src/features/policy/PolicyView.guard.test.tsx','src/features/policy/PolicyView.scope.test.tsx','--maxWorkers=2','--reporter=json','--outputFile='+str(OUT/(name+'.vitest.json'))]
 elif name=='web-typecheck': cmd=['npm','run','typecheck','--workspace','@ghostpay/web']
 elif name=='changed-eslint': cmd=['npm','exec','--','eslint','--config','eslint.config.js','apps/web/src/features/policy/pay.ts','apps/web/src/features/policy/PolicyPay.tsx','apps/web/src/features/policy/pay.assetCoverage.test.ts','apps/web/src/features/policy/PolicyAssetCoverage.test.tsx','apps/web/src/i18n/securityKeys.ts','apps/web/src/i18n/securityKeys.test.ts']
 else: raise SystemExit('Unknown run')
 raise SystemExit(run(name,cmd))


# Fresh final policy asset-coverage review

**No blocking finding in the bounded corrected patch. The prior same-policy-terms finding is resolved on this exact source.**

- Reviewed source: `e1ab03ca7b07c225ae42d0c16fb79b97f0a1f95c`.
- Reviewed tree: `fbb88d447ca4a60275bcd28d3256b03a77c47a3e`.
- Composition baseline: `1d38928896cac2d5342363fc6eff13c6fbfdf28c`.
- Previous review source: `7196b29e66e3699b5d4764b8f7c16a66ae673a75`.
- Test-first correction baseline: `d101c5db3ec07889893343a2a3838c3bff3d1047`.

Reviewer: fresh worker `/root/policy_asset_final_review`, independent of author and preceding reviewer. AGENTS/WORKFLOW/HANDOFF and the active ownership claim were read. This is scoped source review, not a formal GitHub approval or permission to merge.

## Source conclusion

All **14 changed paths** against the composition baseline and **10 correction paths** against the previous review were inspected. Context covered parsing/freezing, seller selection, actual policy-hash and withdrawal contract semantics, final send authority, duplicate-attempt handling, import/recovery, and critical messages.

A validated matching policy commitment proves the same immutable limits root even when seller keys differ. Unsupported assets are now refused at preparation and the current-record wallet guard. Positive `covered` status and recovery associations still require both exact seller keys; other-seller supported terms remain `unknown`. The separate refusal text describes matching terms without misidentifying the record's seller.

The layout-effect-updated record ref and existing synchronous review/session/deployment guards survive the wallet await. Both ordinary and other-seller late imports block the mock send. A post-approval refusal preserves its known hash and allowance warning. Existing single-use and duplicate-attempt guards are unchanged; no journal deletion or retry authorization was introduced. ERC-20 payments still require native value zero; this patch adds no native-buffer payment mode.

## Independent executable results

| Check | Actual result |
|---|---|
| Six focused web files at e1ab03ca | **33 passed, 0 failed, 0 skipped**, 8.479 seconds |
| Three existing send/deployment/session authority files at e1ab03ca | **57 passed, 0 failed, 0 skipped**, 9.758 seconds |
| Complete policy package, without coverage collection, at e1ab03ca | **94 passed, 0 failed, 7 skipped**, 3.304 seconds |
| Two complete correction-baseline files at d101c5db | **11 passed, 3 failed, 0 skipped**, expected exit 1, 11.509 seconds |
| Full web TypeScript | **Exit 0**, 16.321 seconds |
| Changed TypeScript/TSX ESLint | **Exit 0**, 7.734 seconds |
| Donor/parent preservation | **7/7 exact blob comparisons passed** |
| Catalog preservation | All **2,254 previous messages** unchanged in each of four catalogs; seven added keys |
| Scope/whitespace | Passed; no manifest, lockfile, workflow, contract, relayer or CLI delta |

The independently reproduced baseline failures were both different-seller-key negative cases and the other-seller record arriving during the wallet account recheck. The latter observed one mock transaction send where zero was required. Those same cases pass in the corrected focused run.

Commands, timestamps, before/after source snapshots, exits and raw log hashes are in `*.run.json`; individual outcomes are in `*.vitest.json` and `test-summary.json`. Corrected source HEAD/tree/status remained unchanged in every execution.

The detached baseline reused candidate dependencies and package builds read-only. Manifests, lockfile and all policy-scheme source were verified identical across the two heads. This proves the application regression, not a clean baseline install/build. The temporary dependency symlink was removed after execution.

## Remaining gates

Seven existing Anvil cross-checks were skipped, not passed. This reviewer did not execute browser, mobile, Tor, full coverage, build, dependency audit or secret scanning. Author/coordinator receipts remain separate. Non-English additions are English fallbacks, not native-language approval.

The separate #211 N09/N10/N11 decoder, typed-data, proof, secret-copy and ephemeral-payment-binding restorations remain a distinct recovery task. This asset review does not close those inherited obligations.

No authored source, dependency installation/build, remote ref, PR, lease, deployment, release or real-funds operation was changed. The coordinator can retain this exact-source review with the original failed review and publish the exclusively owned candidate under existing authorization. Shared integration still requires ownership reconciliation, approvals and exact-source gates.


"""Compare complete non-document source deltas with current main and pinned open PRs."""
import collections
import functools
import gzip
import json
from pathlib import Path
import subprocess

ROOT=Path('/workspace/scratch/5ceb6203640a')
OUT=ROOT/'census-followup-evidence'
REPO=ROOT/'GhostPay'
data=json.loads((OUT/'branch-census-final.json').read_text())
raw=json.loads(gzip.decompress((OUT/'branch-comparisons.json.gz').read_bytes()))
comparisons={b['name']:b for b in raw['branches']}
prs=json.loads((OUT/'open-prs.json').read_text())['prs']
prior=json.loads((OUT/'pr343-residual-dispositions.json').read_text())['records']
prior_by={r['branch']:r for r in prior}
MAIN=data['baseline_main']
PRIOR_MAIN='aec179910c39081d820396409ff3139ff2264132'
CANDIDATE='5a745d4b5fba69b66a9779f88aefc63c253a4f27'

def git(*args):
    return subprocess.check_output(['git',*args],cwd=REPO).decode().rstrip('\n')

@functools.lru_cache(None)
def tree(ref):
    out={}
    for line in git('ls-tree','-rz',ref).split('\0'):
        if line:
            meta,path=line.split('\t',1)
            out[path]=tuple(meta.split()[::2])  # mode + blob, retain mode changes
    return out

def non_document(path):
    return not path.startswith(('docs/','evidence/')) and not path.endswith(('.md','.txt'))

records=[]
targets={p['number']:tree(p['head']) for p in prs}
main_tree=tree(MAIN)
for b in data['branches']:
    if b['classification'] is not None:
        continue
    comp=comparisons[b['name']]
    paths=[f['path'] for f in comp['files'] if non_document(f['path'])]
    donor=tree(b['sha'])
    matches=[p['number'] for p in prs if p['head']!=b['sha'] and paths and all(donor.get(path)==targets[p['number']].get(path) for path in paths)]
    main_matches=[path for path in paths if donor.get(path)==main_tree.get(path)]
    record={'branch':b['name'],'head':b['sha'],'main':MAIN,'non_document_delta_path_count':len(paths),'exact_main_delta_path_count':len(main_matches),'all_non_document_deltas_equal_main':len(main_matches)==len(paths),'exact_changed_source_prs':matches,'application_or_test_source_absent_from_main':[path for path in paths if path not in main_tree and path in donor],'review_status':'pending-semantic-review','qualification_claimed':False,'tests_executed':[]}
    old=prior_by.get(b['name'])
    if old:
        focus=set(old.get('focus_paths',[]))
        for witness in old.get('supersession_evidence',[]):
            if witness.get('path'):focus.add(witness['path'])
        witness_rows=[]
        for path in sorted(focus):
            witness_rows.append({'path':path,'donor':donor.get(path),'prior_main':tree(PRIOR_MAIN).get(path),'current_main':main_tree.get(path),'candidate_307':tree(CANDIDATE).get(path),'prior_evidence_source':tree(old['head_sha']).get(path),'main_unchanged_since_prior_review':tree(PRIOR_MAIN).get(path)==main_tree.get(path),'source_unchanged_since_prior_review':tree(old['head_sha']).get(path)==donor.get(path)})
        record['prior_343']={'head':'5564d8d2dcd22ce8d0b0c2516628f42671b8ffd5','path':'docs/coordination/claims-20261120/residual-dispositions.json','classification':old['classification'],'source_head':old['head_sha'],'claim':old.get('claim'),'disposition':old.get('disposition',old.get('summary')),'next_action':old.get('next_action'),'whole_source_head_unchanged':old['head_sha']==b['sha'],'focus_witnesses':witness_rows}
    if not paths:
        record.update(proposed_classification='Documentation or evidence only',review_status='complete-non-document-delta-empty',reason='The complete merge-base delta has no non-document files; previous code-path heuristic counted documentation under apps/packages/scripts.')
    elif len(main_matches)==len(paths):
        record.update(proposed_classification='Semantically redundant',review_status='complete-changed-source-tree-equivalence',reason='All non-document changed path modes/blobs equal current main; differing documentation is preserved.')
    elif matches:
        record.update(proposed_classification='Blocked by dependencies',review_status='complete-changed-source-retention-in-open-candidate',reason='Every non-document changed path mode/blob is retained in at least one pinned open candidate. That candidate and its dependency/qualification chain must be resolved; no main adoption or behavioral qualification is inferred.')
    records.append(record)

out={'schema':'ghostpay-pending-source-dispositions/1','main':MAIN,'captured_at':data['captured_at'],'pending_at_start':len(records),'prior_343_source_pin':'5564d8d2dcd22ce8d0b0c2516628f42671b8ffd5','records':records,'limits':['Exact changed path retention is stronger than ancestry but is not test execution or semantic approval of the receiving candidate.','Branch purposes without source evidence remain explicitly pending rather than being forced into a completed category.','No historical refs are removed; no owner claims or locks are changed.']}
(OUT/'source-dispositions.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(collections.Counter(r.get('proposed_classification','Pending semantic review') for r in records)),indent=2))
for r in records:
    if r.get('proposed_classification'):
        print(r['proposed_classification'],r['branch'],r['non_document_delta_path_count'],r['exact_changed_source_prs'][:4])

# GhostPay census and historical-source follow-up

Worker: `/root/census_followup`. This packet is subordinate evidence for the existing authoritative repository ledger. It is not a competing completion ledger.

## Pinned snapshot

- Main: `eb59d93cffed7848c4aac37d0e9650b87239c6da`.
- Main tree: `d8aa628cbc531c6969bdf0af621795ceacfc00c3`.
- Source collection completed: `2026-11-21T06:33:38.109Z`.
- Branch pages: **100 / 100 / 100 / 100 / 38 / 0**; **438 unique live branches**, every head pinned.
- Open PR pages: **100 / 31 / 0**; **131 unique open PRs**, every head matches its branch inventory pin.
- Read-only `git ls-remote --tags origin` returned zero tag refs and exit 0. The connector's `/tags` collection was unsupported; no tag count was inferred from that rejection.
- The prior **437 branches / 135 open PRs**, main `aec179910c39081d820396409ff3139ff2264132`, remain in `../recovery-evidence/`. This packet retains its own pre-follow-up snapshot under `snapshots/20261121T063338Z/`.

## Complete comparison counts

All 438 sources were compared locally without GitHub's file cap. Each full comparison retains exact source tree, every best merge base, selected base, ahead/behind counts, complete numstat paths, unmatched source paths, and all ahead commit SHAs.

- **191** exact heads are ancestors of current main.
- **246** branches have ahead commits.
- **1** unrelated `gh-pages` publication history remains excluded from source integration.
- Original path heuristic: **175 code-path candidates / 65 docs-directory-only / 6 other noncode**.
- **53** comparisons contain at least 300 paths; no comparison is truncated.
- **48** comparisons have more than one best merge base. This increased after the camera/main history integration; every valid base is retained rather than guessed.
- **1,553** distinct ahead commit SHAs.

The full deterministic gzip has SHA-256 `f264dbda958c422bc6ead01cf42db68d011dd5178e625b9fec32a829844757a5`. Decompressed SHA-256 is `a997b63a7363aa77865f71fad67ae4496282877872c9a56526a2c3628a1e04b4`.

## Engineering dispositions and review limits

| Engineering disposition | Branches |
| --- | ---: |
| Already incorporated | 191 |
| Semantically redundant | 18 |
| Superseded | 5 |
| Documentation or evidence only | 69 |
| Experimental or deferred | 9 |
| Blocked by dependencies | 87 |
| **Still unclassified: semantic review pending** | **59** |
| Total | 438 |

The initial 154 undecided records received **95 evidence-supported engineering dispositions**: 48 complete non-document changed mode/blob sets retained by pinned open candidates; 35 explicit active parent-PR dependencies verified against local Git; four bounded main-retention/supersession decisions; four future/API-funded scope deferrals; three scoped candidate-retention decisions; and one documentation-only correction to the code-directory heuristic.

**142 branches still have a semantic-review obligation.** An exact retained delta or a verified PR parent is useful integration evidence, but does not qualify the receiving runtime or erase inherited source review. The 59 above are the subset with no supported final engineering disposition. They were not blanket-labeled blocked because the integration lock is held. `unresolved-source-questions.json` and `UNRESOLVED_BRANCHES.md` list all 59 exact heads, focus paths, unresolved behavior questions, and applicable #343 source records.

## Four resolved historical-source questions

1. `7dc7eccc34af289050aa1606784a88dfe8a5633a`: **superseded**. The three CreateInvoice source/test files are exact current-main blobs. Complete differences in the remaining four paths only remove newer blocked-download handling, verified-backup wording, ENS tests, actual process-restart coverage, imported-observation distrust and same-nonce cancellation coverage. Preserve the stronger current source.
2. `2527d6b9367887508d7d8f678a18564132652a03`: **semantically redundant** for its eight-commit lean milestone. Current source retains the payment expiry, manifest/deployment, secret scanning, CI and workflow protections. Current deadline handling additionally respects the last payable second and rechecks clocks at signing/submission boundaries. Original reachability exceptions remain explicitly marked pending owner review; this is no new acceptance of those dependencies.
3. `1d28f24d86f40c7af5d4187f5d0b3b0d0bf79c78`: **semantically redundant**. Current D3 deadline rechecks, B2R plain-revert-only operator fee handling, and AR2 served-range reset preserve the claims. AR2 has a matching main patch. The donor head also changed an old `txGuard` halt regex; this corrects the overly broad docs-only shorthand in #343. The relevant plain-revert logic now lives in the chain adapter and retains the halt exclusions.
4. `63994db6cff8b3b3ca698427eee9e95904230546`: **semantically redundant**. The preceding safeguards plus descriptor-bound secret loading are retained; the latter has a matching main patch and was moved to `packages/relayer-guard`. Current-main focus blobs remain identical to #343's review snapshot.

No new application port was justified by these four sources. Original branches and source history remain intact.

## Existing candidates and deferrals

The base64url primitive guard is already represented by #307; its regression differs only in an unused fixture argument. The historical real-calendar date and finite retry guards from `d6f6617e595bbba7e83a1fcdec585bedb9adaf0f` and #271 are likewise retained in #307 but absent current main. Those existing qualification chains own the work.

Three dormant future modules (merchant dashboard, Ghostproof and private recurring) remain unactivated and incomplete outside accepted beta scope. The API-funded four-lane workflow is deferred. No server, contract, custodial or paid-automation capability was activated.

## Current PR dependency evidence

`pr-dependency-dispositions.json` contains all 131 current PRs, exact source/base heads, direct parent PR, full open-parent chain, orphan base branches, disposition and review limitations. The longest current chain is **#361 → #355 → #354 → #352 → #348 → #336 → #327 → #326**. Policy remains **#368 → #362 → #357**. #369 explicitly targets #340.

Seven PR bases have no currently open parent PR: #326, #333, #300, #153, #140, #139 and #160. The index preserves their actual branch names; absence of an open parent does not mean their source or ownership is absent.

Root independently collected complete comments, inline comments and review submissions for the 131 PRs. This packet references those records and distinguishes formal review states from the workers' independent AI source review. No formal approval is inferred from advisory bots, skipped reviews, old model-only checks or queued Actions.

The five recent merge events were re-read from live GitHub and are in `recent-merged-prs.json`: #342 (`b86a3e6affe8b71c6f13d16783accad446271ba4`), #351 (`08d2111a5fd3b71a148fc8648481200e680faf53`), #359 (`ccc8c3521511e2a2b9b66ef11f12723d87ce5f44`), #366 (`da6b05da5bb2e4293f38572da361980960d91911`) and #258 (`eb59d93cffed7848c4aac37d0e9650b87239c6da`). This worker performed none of those merges.

## Ownership and execution boundaries

Shared-target integration remains paused. Old lock owner `994a0d214fb9-root-r3`, generation 11, was restored by root at `6edfcd4dfb85c29e11aa0dee9fa0dabcc5b0ac79`; no evidence of that owner's stop/release has been established. Expiry alone does not permit takeover. This worker changed no lock, main, parent source branch, remote PR, workflow state or review.

Executed commands were read-only Git fetch/ref enumeration, `merge-base --all`, `rev-list`, complete `diff --numstat`, `ls-tree`, source/commit inspection, the four supplied Python census scripts, and deterministic compression/digest checks. `validation.json` confirms row/head uniqueness, exact branch/PR pins, totals and gzip reproducibility.

**Application tests executed by this worker: zero.** Existing source/test reports are identified as prior evidence. No build, browser, dependency, contract or security gate is claimed as newly run. No deployment, release or real-funds action occurred.

## Fresh reviewer continuation

Start from `unresolved-source-questions.json` on the same frozen main. Tackle bounded small-file branches first, using existing independent-review evidence where available (#328/#338/#360) without borrowing qualification from a different composition. Then reconcile inherited idle/backup, recovery, privacy, scan, hygiene and October checkpoint families. Keep main adoption, source retention and executable acceptance separate.

Before any eventual integration, refresh all source/target heads, resolve the genuine ownership hold, preserve current-main safeguards, execute applicable gates and obtain required review. After root publishes its isolated recovery and ledger refs, refresh the live census once more, preserving this snapshot and its source evidence.

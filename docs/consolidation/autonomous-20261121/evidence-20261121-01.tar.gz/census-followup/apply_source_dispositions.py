"""Apply supported engineering dispositions without claiming semantic/test completion."""
import collections,gzip,json,pathlib,subprocess
ROOT=pathlib.Path('/workspace/scratch/5ceb6203640a'); OUT=ROOT/'census-followup-evidence'; REPO=ROOT/'GhostPay'
data=json.loads((OUT/'branch-census-final.json').read_text()); src=json.loads((OUT/'source-dispositions.json').read_text()); prs=json.loads((OUT/'pr-dependency-dispositions.json').read_text())
sources={r['branch']:r for r in src['records']}; pr_by={p['number']:p for p in prs['prs']}
raw=json.loads(gzip.decompress((OUT/'branch-comparisons.json.gz').read_bytes())); comparisons={r['name']:r for r in raw['branches']}; MAIN=data['baseline_main']
frozen=OUT/'snapshots'/'20261121T063338Z'; frozen.mkdir(parents=True,exist_ok=True)
for n in ['branch-census-final.json','live-branches.json','open-prs.json','pr-dependency-dispositions.json']:
 p=frozen/(n+'.gz')
 if not p.exists():p.write_bytes(gzip.compress((OUT/n).read_bytes(),mtime=0))
for n in ['branch-comparisons.json.gz','branch-comparisons-manifest.json']:
 p=frozen/n
 if not p.exists():p.write_bytes((OUT/n).read_bytes())
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO).decode().rstrip('\n')
def blob(ref,path):
 p=subprocess.run(['git','rev-parse','--verify',ref+':'+path],cwd=REPO,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 return p.stdout.decode().strip() if p.returncode==0 else None
manual={
 'chatgpt/ghostpay-historical-consolidation-20261115':('Superseded','scoped-source-review-complete','All seven source paths compared: three CreateInvoice source/tests are exact main blobs. The other four donor-to-main diffs retain donor behavior and add blocked-download failure handling, verified-backup wording, ENS tests, actual browser-process restart, distrust of imported observations and same-nonce cancellation coverage. Replaying this donor removes newer safeguards.'),
 'claude/ghostpay-lean-core-milestone-t5lwox':('Semantically redundant','scoped-source-review-complete','Eight ahead milestone commits reviewed by claim with #343 patch evidence. Main retains fail-closed deployment/manifest tests, scripts/tests CI inclusion, secret rules, disabled invalid workflow, same-repository/exact-head/human-approved automation and explicit lean dependency lists. Invoice/quote guards use a stricter last-payable-second deadline plus fresh signing/submission clocks. Preserve current pay/workflow source.'),
 'claude/gifted-planck-115x2k':('Semantically redundant','scoped-source-review-complete','D3 queue/RPC deadline rechecks and B2R positively identified plain-revert fallback remain in main; AR2 served-range reset matches main patch 79ae3ea2aa349f4635b9da6bd2c23be6a7109808. Donor head also changed old txGuard HALT_TEXT (not merely docs as #343 shorthand says); current plain-revert classification moved to chain-adapters/rpc.ts and rejects invalid-instruction/EVM-error halts. No replay needed.'),
 'codex/ghostpay-security-audit-20261030':('Semantically redundant','scoped-source-review-complete','D3/B2R/AR2 retained as for gifted-planck. Descriptor-bound secret validation/read matches main patch 80371be9313cc9024eff542a77ffec9eb90c0562 and now lives in packages/relayer-guard/src/secrets.ts; old relayer module forwards to it. Current source uses one descriptor, fstat, no-follow/non-blocking flags and a bounded read. Focus blobs unchanged from #343 review main.'),
 'automation/ghostpay-parallel-four-agents-20261103':('Experimental or deferred','scope-deferral-source-verified','Absent-main workflow adds API-funded scheduled automation and a privileged publisher, outside accepted static Pages beta consolidation. Preserve without enabling paid runs, schedules or credentials.'),
 'automation/20261119T2243Z/bug/base64url-runtime-input':('Blocked by dependencies','scoped-source-retention-confirmed','Primitive-string runtime guard is exact #307 blob 5466ee0b99925dedd23e753636ae7ab3f6f48234 and absent main. Regression diff removes only an unused fixture argument; input cases/assertions remain. Qualify existing #307/current recovery composition, not a duplicate decoder port.'),
 'claude/lucid-meitner-apalzc':('Blocked by dependencies','scoped-main-and-candidate-retention-confirmed','#343 focus evidence revalidated against unchanged main blobs. Main retains source scanner, tx.origin gate, bounded quote decimals, pool input/queue bounds and TRON range completeness. Real-calendar manifest and finite retry guards remain in #307 but absent main. Existing #271/#307 qualification owns remaining adapter work; preserve non-Pages pool/contracts history without expanding scope.'),
 'integration/ghostpay-adapter-qualification-20261119':('Blocked by dependencies','scoped-main-and-candidate-retention-confirmed','Main retains TRON completeness and quote-decimal guards. #307 retains missing real-calendar manifest-day and finite retry guards; its other rpc.ts changes add no-cookie/no-referrer/no-cache request options. Reconcile #271 tests and qualify the existing exact composition.')
}
for n,module in [('future/f04-merchant-dashboard','merchant-dashboard'),('future/f05-ghostproof','ghostproof'),('future/f10-private-recurring','private-recurring')]:
 manual[n]=('Experimental or deferred','scope-deferral-source-verified',f'Dormant future/{module} source/tests are unique and absent main/#307. Source-pinned milestone leaves UI/persistence/provider/activation work incomplete. Preserve this future proposal outside accepted static Pages beta consolidation; do not activate via bulk merge.')
decisions=[]
for b in data['branches']:
 s=sources.get(b['name'])
 if not s:continue
 m=manual.get(b['name'])
 if m:
  s.update(proposed_classification=m[0],review_status=m[1],reason=m[2])
  # Re-pin original scope and every non-document delta to the current main.
  s['source_blob_witnesses']=[{'path':f['path'],'donor_blob':blob(b['sha'],f['path']),'main_blob':blob(MAIN,f['path'])} for f in comparisons[b['name']]['files'] if not f['path'].startswith(('docs/','evidence/')) and not f['path'].endswith(('.md','.txt'))]
 elif not s.get('proposed_classification'):
  pr=pr_by.get(b.get('open_pr'))
  if pr and pr['parent_pr'] is not None:
   parent=pr_by[pr['parent_pr']]
   bases=git('merge-base','--all',pr['head'],pr['base_sha']).splitlines()
   s['verified_pr_dependency']={'child_pr':pr['number'],'child_head':pr['head'],'base_branch':pr['base'],'observed_base_head':pr['base_sha'],'parent_pr':parent['number'],'parent_head':parent['head'],'common_ancestor_shas':bases,'parent_head_in_child_history':subprocess.run(['git','merge-base','--is-ancestor',parent['head'],pr['head']],cwd=REPO).returncode==0}
   s.update(proposed_classification='Blocked by dependencies',review_status='integration-dependency-verified-semantic-review-pending',reason=f'PR #{pr["number"]} explicitly targets active source of #{parent["number"]}. Parent qualification/integration and owner release are required before child reaches main; inherited/child semantics remain unreviewed unless separately evidenced.')
 if s.get('proposed_classification'):
  b.update(classification=s['proposed_classification'],classification_reason=s['reason'],review_status=s['review_status']);decisions.append({'branch':b['name'],'head':b['sha'],'classification':b['classification'],'review_status':b['review_status']})
 b['source_disposition_record']='source-dispositions.json#'+b['name']
 b['semantic_review_pending']=s['review_status'] in ['pending-semantic-review','complete-changed-source-retention-in-open-candidate','integration-dependency-verified-semantic-review-pending']
data['classification_counts']=dict(collections.Counter(b['classification'] or 'Pending semantic review' for b in data['branches']))
data['semantic_review_pending_count']=sum(b.get('semantic_review_pending',b.get('review_status')=='semantic-review-pending') for b in data['branches'])
data['source_review_followup']={'input_pending':src['pending_at_start'],'evidence_supported_engineering_dispositions':len(decisions),'unclassified_pending':sum(b['classification'] is None for b in data['branches']),'qualification_limit':'A verified parent/candidate dependency is an integration disposition. It does not erase semantic or executable review; see semantic_review_pending_count.'}
src['decision_counts']=dict(collections.Counter(r.get('proposed_classification','Pending semantic review') for r in src['records']));src['decisions_applied']=decisions
by_name={b['name']:b for b in data['branches']}
discussions={}
discussion_dir=ROOT/'GhostPay-ledger/docs/consolidation/autonomous-20261121/pr-discussions'
for path in discussion_dir.glob('*.json'):
 for r in json.loads(path.read_text())['records']:
  if not r.get('error'):discussions[r['number']]=(r,path.name)
for p in prs['prs']:
 b=by_name[p['branch']];p.update(source_classification=b['classification'],semantic_review_status=b['review_status'],disposition=b['classification'] or 'Pending semantic review',next_action=b.get('classification_reason'),dependency_limit='Current source only; integration requires owner release, independent review and applicable exact-head tests.')
 if p['number'] in discussions:
  d,path=discussions[p['number']];comments=d.get('comments',[])
  p['discussion_evidence']={'path':'pr-discussions/'+path,'observed_head':d.get('head'),'comment_count':len(comments),'formal_review_states':dict(collections.Counter(x.get('review') for x in comments if x.get('review'))),'approved_review_urls':[x['url'] for x in comments if x.get('review')=='APPROVED'],'limitation':'Discussion/review presence is not independent current-head approval. Bot advisory passes, skipped reviews and historical model-only evidence are not executable qualification.'}
for b in data['branches']:
 b['unmatched_code_path_count']=len(comparisons[b['name']].get('unmatched_code_paths',[]));b.pop('unmatched_code_paths',None)
 if b['classification']=='Already incorporated':b.pop('active_descendant_prs',None)
data['evidence_paths']={'uncapped_comparisons':'branch-comparisons.json.gz','comparison_hashes':'branch-comparisons-manifest.json','source_reviews':'source-dispositions.json','open_prs':'pr-dependency-dispositions.json','frozen_before_followup':'snapshots/20261121T063338Z/branch-census-final.json.gz'}
for n,d in [('branch-census-final.json',data),('source-dispositions.json',src),('pr-dependency-dispositions.json',prs)]: (OUT/n).write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps({k:data[k] for k in ['classification_counts','source_review_followup','semantic_review_pending_count']},indent=2))

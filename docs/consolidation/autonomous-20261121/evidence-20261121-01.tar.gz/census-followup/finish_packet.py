"""Create compact continuation questions and a digest-verified delivery packet."""
import collections,datetime,gzip,hashlib,json,pathlib,subprocess
ROOT=pathlib.Path('/workspace/scratch/5ceb6203640a'); OUT=ROOT/'census-followup-evidence'; REPO=ROOT/'GhostPay'
index=json.loads((OUT/'branch-census-final.json').read_text()); source=json.loads((OUT/'source-dispositions.json').read_text())
records={r['branch']:r for r in source['records']}; prs=json.loads((OUT/'pr-dependency-dispositions.json').read_text()); pr_by={p['number']:p for p in prs['prs']}
comparisons=json.loads(gzip.decompress((OUT/'branch-comparisons.json.gz').read_bytes())); comp_by={b['name']:b for b in comparisons['branches']}
manual={
 'audit/ghostpay-complete-claim-reconciliation-20261120':'Review the read-only reconciliation generator and its synthetic cases against the now-merged #366 census; determine useful distinct evidence/tooling without treating it as application completion.',
 'automation/ghostpay-20261120-embed-popup-noopener-r1':'Child #351 is now merged. Qualify the composed popup behavior against current main and retain the test correction; do not reuse old parent-only CI.',
 'automation/20261119T083600Z/bug/json-canonical-array':'Compare canonical-array validation and all invalid-key/sparse-array regressions with #307/current recovery source; determine whether only test formatting differs.',
 'automation/20261121T0440Z/bug/payment-uri-utf16-failclosed':'Use existing independent source review and four executed UTF-16 regressions; compare the exact current-main composition and required CI before deciding integration readiness.',
 'chatgpt/ghostpay-idle-lifecycle-qualified-20261119':'Compare sleep/rollback session expiry and unverified-backup locking with #256/#333/#365/#367; retain separate invoice and session clocks.',
 'chatgpt/ghostpay-pages-artifact-integrity-20261119':'Compare the original artifact verifier/build script to #277/#292 and current recovery build gates; preserve publication-directory and race regressions.',
 'claude/ghostpay-consolidation-9xhtxg-feeguard':'Compare the complete six-path fee/quote delta with current native and OP Stack fees, router review and #218; distinguish useful old regression cases from weaker source.',
 'claude/ghostpay-consolidation-9xhtxg-security':'Separate the narrow security/tooling delta from #225/#255 analyzer work and #220; preserve fail-closed checks without adding contract or deployment scope.',
 'claude/ghostpay-consolidation-9xhtxg-spec18':'Compare recovery/restore/custody semantics with #239/#240/#260 and the new recovery composition; no wholesale old runtime replay.',
 'claude/vibrant-cori-scu18b':'Review the 25 differing source paths by claimed fee, sweep and session behavior; compare narrower current proposals before selecting retained regression cases.',
 'feat/ghostpay-privacy-quick-hide-20261120':'Review quick-hide event ownership, navigation and preview clearing against #326/#361/current recovery; parent snapshot has no own open PR.',
 'feat/ghostpay-tor-completion-20261119':'Application/script blobs match existing integrations but workflow/configuration differs. Reconcile the full Tor/static artifact contract with #320/#363 without enabling deployment.',
 'feature/ghostpay-retention-completion-20261120':'Verify retention, reload and cross-tab cancellation through #327/#336/#348/#352/#354/#355/#361; keep the parent candidate and privacy runtime dependency explicit.',
 'fix/ghostpay-backup-preflight-20261120-r2':'Compare original ownership and renamed regression files with #365/#367/new recovery composition; preserve backup-preflight custody and durable-write revocation across current-main changes.',
 'fix/ghostpay-hygiene-transfer-evidence-20261120':'Compare full transfer evidence validation plus #347 fixture correction and #341 seven-testnet reuse ledger; select one composed successor without releasing existing owners.',
 'fix/ghostpay-policy-record-seller-identity-20261121':'Consume independent review of the complete #368->#362->#357 stack, then reconcile child fixes in order and qualify the eventual parent head; current #357 alone is not that reviewed composition.',
 'fix/ghostpay-tron-genesis-guard-gpbug15-20261120':'#342 is merged; #369 carries the reviewed current-main composition. Verify that child and its hosted checks before parent qualification; source/runtime selected-network guard must remain intact.',
 'integration/ghostpay-idle-session-20261120-r2':'Verify propagation of the late #331 merge through #333 and #365/#367/new recovery. The old #325 merge does not prove adoption in #307.',
 'integration/ghostpay-idle-session-completion-20261119':'Compare the 17-path idle/backup proposal with sleep-aware #331/#333 and current recovery; preserve every distinct clock/session regression.',
 'integration/ghostpay-tor-qualified-20261121':'Review the Tor/browser qualification changes against #308/#320 and new current-main/recovery artifact; obtain exact artifact execution without equating queued checks with passes.',
 'repair/ghostpay-analyzer-recovered-20261119':'Review the latest analyzer-repair commit separately from its inherited 464-path stack; compare #225/#255/current analyzer owners and avoid importing deferred contract/deployment behavior.',
 'repair/ghostpay-final-lint-20261119':'Identify exact lint-only fixes in the latest commits and compare surviving source in the selected successor; do not qualify the inherited 467-path stack from lint evidence.',
 'repair/ghostpay-native-fee-recovered-20261119':'Isolate native-fee correction and tests from the inherited recovery stack; compare current OP Stack/operator fees and #217/#218 before any port.',
 'repair/ghostpay-pr-231-20261118':'Compare repaired sweep balance-consent/review-authority behavior with #231/#272/current sweep composition; require no request before consent and cancellation after scope changes.',
 'repair/ghostpay-qr-surrogates-20261119':'Isolate surrogate-input guard and fixture repair from broad inherited source; compare current QR decoder and #360 payment-URI guard because they protect different boundaries.',
 'review/ghostpay-sweep-quote-lifecycle-20261119':'Compare quote invalidation, stale signing authority and unknown-broadcast preservation against current Sweep and selected recovery/journal composition.',
 'snapshot/ghostpay-privacy-8be15289-20261120':'Use as the parent provenance for #300, then compare sensitive-view lifecycle and persistence paths against #326/#361/new recovery; inherited scope remains unresolved.',
 'work/ghostpay-required-v1-candidate-20261120':'Split the 527 differing code paths into recovery, invoice, Sweep, scanning and deferred server/contract families; compare the selected current recovery composition before claiming accepted v1 completion.',
 'work/ghostpay-required-v11-candidate-20261120':'Split 566 differing code paths into mandatory privacy surfaces and deferred runtime; compare #300/#326/#361/current recovery, including cross-tab/session/endpoint revocation.',
}
unresolved=[]
for b in index['branches']:
 if b['classification'] is not None:continue
 s=records[b['name']]; prior=s.get('prior_343');comp=comp_by[b['name']]
 focus=[x['path'] for x in prior['focus_witnesses']] if prior else []
 if not focus:focus=comp.get('unmatched_code_paths',[])[:6]
 question=manual.get(b['name']) or (prior.get('next_action') if prior else None) or 'Compare the complete source delta with current main and existing feature owners; establish retained behavior and tests before classifying.'
 unresolved.append({'branch':b['name'],'head':b['sha'],'open_pr':b['open_pr'],'main':index['baseline_main'],'unmatched_code_path_count':b['unmatched_code_path_count'],'focus_paths':focus,'unresolved_question':question,'supporting_343_record':None if not prior else {'head':prior['head'],'path':prior['path'],'source_head':prior['source_head'],'classification':prior['classification'],'claim':prior.get('claim'),'current_main_focus_blobs_unchanged':all(x['main_unchanged_since_prior_review'] for x in prior['focus_witnesses']),'source_pin_unchanged':prior['whole_source_head_unchanged']},'next_evidence':'source-dispositions.json.gz and complete branch-comparisons.json.gz','qualification_limit':'No merge readiness, formal GitHub approval or executable test pass is inferred by this question.'})
assert len(unresolved)==59
packet={'schema':'ghostpay-unresolved-source-questions/1','main':index['baseline_main'],'captured_at':index['captured_at'],'count':len(unresolved),'records':unresolved,'worker_handoff':'Fresh branch recovery reviewer should start with bounded small-file candidates, then family-level inherited stacks; record every source/target SHA and preserve donor refs.'}
(OUT/'unresolved-source-questions.json').write_text(json.dumps(packet,indent=2)+'\n')
text=['# Unresolved source questions','',f'Main: `{index["baseline_main"]}`. Frozen capture: `{index["captured_at"]}`. These 59 branches remain unclassified; none is relabeled blocked solely because the integration lock is held.','', 'The index separately records 142 continuing semantic-review obligations, including known dependencies. This list is the smaller set lacking an evidence-supported engineering disposition.','']
for i,r in enumerate(unresolved,1):
 text += [f'## {i}. {r["branch"]}','',f'- Head: `{r["head"]}`',f'- Open PR: #{r["open_pr"]}' if r['open_pr'] else '- Open PR: none in snapshot',f'- Differing code paths: {r["unmatched_code_path_count"]}',f'- Question: {r["unresolved_question"]}',f'- Focus: '+', '.join('`'+p+'`' for p in r['focus_paths'])]
 if r['supporting_343_record']:text += [f'- Prior evidence: #343 `residual-dispositions.json` branch record; {r["supporting_343_record"]["classification"]}; original donor `{r["supporting_343_record"]["source_head"]}`.']
 text+=['']
(OUT/'UNRESOLVED_BRANCHES.md').write_text('\n'.join(text))
# Compact heavyweight optional source records; preserve full JSON only in scratch, not delivery.
for name in ['source-dispositions.json','open-prs.json']:(OUT/(name+'.gz')).write_bytes(gzip.compress((OUT/name).read_bytes(),mtime=0))
tags={'source':'git ls-remote --tags origin','exit_code':0,'rows':(OUT/'remote-tags.tsv').read_text().splitlines(),'tag_count':0,'note':'GitHub connector rejects /tags collection; successful read-only Git transport returned an empty tag list.'}
(OUT/'tags.json').write_text(json.dumps(tags,indent=2)+'\n')
# Integrity/coverage checks are census validation, not application tests.
live=json.loads((OUT/'live-branches.json').read_text());manifest=json.loads((OUT/'branch-comparisons-manifest.json').read_text());packed=(OUT/'branch-comparisons.json.gz').read_bytes();plain=gzip.decompress(packed)
assert len(index['branches'])==len(live['branches'])==len(comparisons['branches'])==438
assert len({b['name'] for b in index['branches']})==438
assert {b['name']:b['sha'] for b in index['branches']}=={b['name']:b['sha'] for b in live['branches']}
assert sum(index['classification_counts'].values())==438
assert len(prs['prs'])==len({p['number'] for p in prs['prs']})==131
assert all(p['source_inventory_exact_head'] for p in prs['prs'])
assert hashlib.sha256(packed).hexdigest()==manifest['compressed_sha256']
assert hashlib.sha256(plain).hexdigest()==manifest['uncompressed_sha256']
assert gzip.compress(plain,mtime=0)==packed
assert live['source_pages']==[100,100,100,100,38,0]
verify={'schema':'ghostpay-census-validation/1','main':index['baseline_main'],'branches':438,'unique_branches':438,'open_prs':131,'unique_open_prs':131,'all_live_head_pins_match':True,'all_pr_heads_match_branch_inventory':True,'classification_sum':438,'unresolved_questions':59,'semantic_review_pending':142,'compressed_sha256':manifest['compressed_sha256'],'uncompressed_sha256':manifest['uncompressed_sha256'],'deterministic_gzip_reproduced':True,'application_tests_run':0,'remote_mutations':0}
(OUT/'validation.json').write_text(json.dumps(verify,indent=2)+'\n')
print(json.dumps(verify,indent=2))

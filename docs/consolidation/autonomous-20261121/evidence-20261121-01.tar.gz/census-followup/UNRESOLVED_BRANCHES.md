# Unresolved source questions

Main: `eb59d93cffed7848c4aac37d0e9650b87239c6da`. Frozen capture: `2026-11-21T06:33:38.109Z`. These 59 branches remain unclassified; none is relabeled blocked solely because the integration lock is held.

The index separately records 142 continuing semantic-review obligations, including known dependencies. This list is the smaller set lacking an evidence-supported engineering disposition.

## 1. audit/ghostpay-complete-claim-reconciliation-20261120

- Head: `c9e53c2c5908cbb64c104d096ce84773cf804ccc`
- Open PR: #358
- Differing code paths: 3
- Question: Review the read-only reconciliation generator and its synthetic cases against the now-merged #366 census; determine useful distinct evidence/tooling without treating it as application completion.
- Focus: `scripts/coordination/reconcile-claims.mjs`, `scripts/coordination/reconcile-claims.test.mjs`, `scripts/tests/reconcile-claims.test.mjs`

## 2. automation/ghostpay-20261120-embed-popup-noopener-r1

- Head: `08d2111a5fd3b71a148fc8648481200e680faf53`
- Open PR: #337
- Differing code paths: 3
- Question: Child #351 is now merged. Qualify the composed popup behavior against current main and retain the test correction; do not reuse old parent-only CI.
- Focus: `apps/web/public/ghostpay-embed-v2.js`, `apps/web/src/embedV2.test.ts`, `apps/web/src/lib/embedPopup.noopener.test.ts`

## 3. automation/20261119T083600Z/bug/json-canonical-array

- Head: `c591b54078febcf24cba01b29bc173b2fac1f9cb`
- Open PR: #265
- Differing code paths: 2
- Question: Compare canonical-array validation and all invalid-key/sparse-array regressions with #307/current recovery source; determine whether only test formatting differs.
- Focus: `packages/invoice-schema/src/json.test.ts`, `packages/invoice-schema/src/json.ts`

## 4. automation/20261120T0835Z/bug/sellerkeys-operation-supersession

- Head: `e6ed3ee64a786c33b1af06b5fc7a51d742eb6544`
- Open PR: #314
- Differing code paths: 3
- Question: Reconcile and qualify the #333 ownership successor with the integration coordinator; preserve both original operation and renamed ownership tests. Do not replay #314 and #333 as independent runtime fixes.
- Focus: `apps/web/e2e/backup-ownership.spec.ts`, `apps/web/src/views/SellerKeys.operation.test.tsx`, `apps/web/src/views/SellerKeys.tsx`
- Prior evidence: #343 `residual-dispositions.json` branch record; claim-represented-open-candidate; original donor `e6ed3ee64a786c33b1af06b5fc7a51d742eb6544`.

## 5. automation/20261120T1840Z/bug/receipt-archive-identity

- Head: `71632fa389ae93824b2f42d265278a9bd0f6de59`
- Open PR: #332
- Differing code paths: 2
- Question: Compare #332 with the receipt-archive-r2 base of #344, retain receipt identity and write serialization regressions, and let the existing receipt/integration owners select one successor.
- Focus: `apps/web/src/components/ReceiptPanel.archive.regeneration.test.tsx`, `apps/web/src/components/ReceiptPanel.tsx`
- Prior evidence: #343 `residual-dispositions.json` branch record; focused-fix-review-pending; original donor `71632fa389ae93824b2f42d265278a9bd0f6de59`.

## 6. automation/20261120T2036Z/bug/btc-preview-network

- Head: `692cac58b1c345137264936e60bee7b1e2eed8b2`
- Open PR: #338
- Differing code paths: 2
- Question: Review/qualify #338 as the bounded preview-network fix and preserve its network regression; reconcile any overlapping spend.ts changes with the existing Bitcoin owner.
- Focus: `packages/btc-silent-payments/src/spend.preview.network.test.ts`, `packages/btc-silent-payments/src/spend.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; focused-fix-review-pending; original donor `692cac58b1c345137264936e60bee7b1e2eed8b2`.

## 7. automation/20261120/bug/policy-review-revocation-r1

- Head: `ccc8c3521511e2a2b9b66ef11f12723d87ce5f44`
- Open PR: #345
- Differing code paths: 2
- Question: Keep #345 as the narrow PolicyPay owner; review its revision guard and pending-edit test with the current policy send path, then run the applicable exact-head gates.
- Focus: `apps/web/src/features/policy/PolicyPay.pendingEdit.test.tsx`, `apps/web/src/features/policy/PolicyPay.tsx`
- Prior evidence: #343 `residual-dispositions.json` branch record; focused-fix-review-pending; original donor `9a10d335d048b197e90d257a5322ff5d5260572d`.

## 8. automation/20261121T0440Z/bug/payment-uri-utf16-failclosed

- Head: `2844ec6c22fe179987585679a934e10033ff3384`
- Open PR: #360
- Differing code paths: 2
- Question: Use existing independent source review and four executed UTF-16 regressions; compare the exact current-main composition and required CI before deciding integration readiness.
- Focus: `packages/payment-uri/src/query-surrogate.test.ts`, `packages/payment-uri/src/query.ts`

## 9. chatgpt/btc-spent-private-scan-20261118

- Head: `981cc2f4395d2d76c499a5cd46387daaaa3a6b1f`
- Open PR: #244
- Differing code paths: 39
- Question: Compare #244 and #254 at the worker-message, persisted spentness, revocation and retained-sweep boundaries; select one owner-approved composition and preserve unique browser regressions. Do not mark Bitcoin spentness complete from either title.
- Focus: `apps/web/e2e/btc-spent-consent.spec.ts`, `packages/btc-silent-payments/src/scan/scanner.ts`, `packages/btc-silent-payments/src/scan/state.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; parallel-implementation-content-review-pending; original donor `981cc2f4395d2d76c499a5cd46387daaaa3a6b1f`.

## 10. chatgpt/btc-spentness-private-scan-20261118

- Head: `2b4b1e912350cb18c630a68b5c1990426e29dbc0`
- Open PR: #254
- Differing code paths: 38
- Question: Reconcile #254 with #244 using spentness evidence, light-scan authorization, revocation and persistence semantics. Preserve #254-specific bounded-output and current-spentness checks until that comparison is complete.
- Focus: `apps/web/e2e/btc-spentness.spec.ts`, `packages/btc-silent-payments/src/scan/scanner.ts`, `packages/btc-silent-payments/src/scan/state.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; parallel-implementation-content-review-pending; original donor `2b4b1e912350cb18c630a68b5c1990426e29dbc0`.

## 11. chatgpt/ghostpay-idle-lifecycle-20261119

- Head: `7e6089e2e40a2a7daf93961eddef17d3fe8501fd`
- Open PR: none in snapshot
- Differing code paths: 272
- Question: Reconcile its AppShell/session clock behavior with the #256 -> #331 -> #333 chain, retaining separate invoice-expiry and session-idle clocks. Do not interpret descendant history as retained final behavior.
- Focus: `apps/web/src/AppShell.idleClock.test.tsx`, `apps/web/src/AppShell.tsx`
- Prior evidence: #343 `residual-dispositions.json` branch record; shared-stack-content-review-pending; original donor `7e6089e2e40a2a7daf93961eddef17d3fe8501fd`.

## 12. chatgpt/ghostpay-idle-lifecycle-qualified-20261119

- Head: `d5fe06e7a7b383da1726c4d38165c824e996b9db`
- Open PR: none in snapshot
- Differing code paths: 15
- Question: Compare sleep/rollback session expiry and unverified-backup locking with #256/#333/#365/#367; retain separate invoice and session clocks.
- Focus: `apps/web/DEVIATIONS.md`, `apps/web/e2e/idle-session.spec.ts`, `apps/web/locales/ar.json`, `apps/web/locales/en.json`, `apps/web/locales/es.json`, `apps/web/locales/ja.json`

## 13. chatgpt/ghostpay-pages-artifact-integrity-20261119

- Head: `f39a9dd36c09f8b02d937c5f3d19676d334976d6`
- Open PR: #276
- Differing code paths: 2
- Question: Compare the original artifact verifier/build script to #277/#292 and current recovery build gates; preserve publication-directory and race regressions.
- Focus: `scripts/pages/verify-pages-artifact.mjs`, `scripts/pages/verify-pages-artifact.test.mjs`

## 14. chatgpt/ghostpay-private-scan-completion-20261119

- Head: `18b367457103fb1731a5b4ef5c51faa37a010e47`
- Open PR: #248
- Differing code paths: 23
- Question: Review its durable discovery and cancellation model against #269 and the current private-scan owner, preserving encrypted restart and checkpoint browser checks. Keep main adoption and feature qualification open.
- Focus: `apps/web/e2e/private-scan-checkpoints.spec.ts`, `apps/web/src/lib/privateScanLifecycle.ts`, `apps/web/src/lib/privateScanStore.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; focused-feature-content-review-pending; original donor `18b367457103fb1731a5b4ef5c51faa37a010e47`.

## 15. claude/exciting-brown-7v69cr

- Head: `b1327d4d0e263fdfc7d4fb0b5546b18de2d7434e`
- Open PR: #218
- Differing code paths: 44
- Question: Review each claimed repair against current main and narrower #307/relayer candidates, starting with the recent invoice error codes, client_queue_full classification and fee-recipient devnet change. Preserve unreviewed claims and their owners.
- Focus: `apps/relayer/src/service.ts`, `apps/web/src/lib/relayerClient.ts`, `packages/invoice-schema/src/errors.ts`, `scripts/devnet/e2e.mjs`
- Prior evidence: #343 `residual-dispositions.json` branch record; multi-area-content-review-pending; original donor `b1327d4d0e263fdfc7d4fb0b5546b18de2d7434e`.

## 16. claude/ghostpay-completion-audit-ot5jjm

- Head: `b5e2ea3e5030b56c79063eb1f91c8a634ee5d740`
- Open PR: #209
- Differing code paths: 32
- Question: Compare the source scanner and build/release checks with current main, and review self-host/nightly changes against #264. Preserve configured fail-closed gates and no deployment/activation status.
- Focus: `.github/workflows/nightly.yml`, `apps/web/scripts/scan-bundle.mjs`, `deploy/docker-compose.yml`, `scripts/pages/verify-pages-site.mjs`
- Prior evidence: #343 `residual-dispositions.json` branch record; multi-area-content-review-pending; original donor `b5e2ea3e5030b56c79063eb1f91c8a634ee5d740`.

## 17. claude/ghostpay-consolidation-9xhtxg-feeguard

- Head: `9e5cc3789b7b8a3c550ed2680304ab6245ec6676`
- Open PR: #217
- Differing code paths: 6
- Question: Compare the complete six-path fee/quote delta with current native and OP Stack fees, router review and #218; distinguish useful old regression cases from weaker source.
- Focus: `packages/contracts/.gas-snapshot`, `packages/contracts/README.md`, `packages/contracts/script/DeployPolicy.s.sol`, `packages/contracts/scripts/pre-deploy-check.sh`, `packages/contracts/test/DeployChecksum.t.sol`, `packages/contracts/test/DeployPolicy.t.sol`

## 18. claude/ghostpay-consolidation-9xhtxg-security

- Head: `4894d0d8d94333dffa8ae3937a4d8314f27c686f`
- Open PR: #212
- Differing code paths: 5
- Question: Separate the narrow security/tooling delta from #225/#255 analyzer work and #220; preserve fail-closed checks without adding contract or deployment scope.
- Focus: `apps/web/deployments/README.md`, `apps/web/package.json`, `apps/web/src/validateDeploymentsScript.test.ts`, `scripts/contract-analysis/mythril-disposition-check.mjs`, `scripts/tests/mythril-disposition-check.test.mjs`

## 19. claude/ghostpay-consolidation-9xhtxg-spec18

- Head: `ebf7c92c3be1c7aebd37fc58b5567e114fb932fc`
- Open PR: #213
- Differing code paths: 33
- Question: Compare recovery/restore/custody semantics with #239/#240/#260 and the new recovery composition; no wholesale old runtime replay.
- Focus: `apps/web/e2e/stealth-export.spec.ts`, `apps/web/e2e/stealthExportFixtures.ts`, `apps/web/locales/ar.json`, `apps/web/locales/en.json`, `apps/web/locales/es.json`, `apps/web/locales/ja.json`

## 20. claude/vibrant-cori-scu18b

- Head: `9617e8572f9bc414410bd937b0e7718d0c5bd55c`
- Open PR: #219
- Differing code paths: 25
- Question: Review the 25 differing source paths by claimed fee, sweep and session behavior; compare narrower current proposals before selecting retained regression cases.
- Focus: `apps/web/DEVIATIONS.md`, `apps/web/locales/ar.json`, `apps/web/locales/en.json`, `apps/web/locales/es.json`, `apps/web/locales/ja.json`, `apps/web/src/features/btc/BtcView.secrets.test.tsx`

## 21. codex/ghostpay-export-authorization-20261119

- Head: `b0abb726c138ad1df2f03b7b102c9bd9de318887`
- Open PR: none in snapshot
- Differing code paths: 444
- Question: Review the paymentExportRpc/networkAuthorization/Scan export changes in #269 and #346, preserving explicit export authority after cancelled/expired scans; reconcile current recovery and backup owners instead of merging this no-PR stack.
- Focus: `apps/web/src/lib/networkAuthorization.ts`, `apps/web/src/lib/paymentExportRpc.ts`, `apps/web/src/views/Scan.stealthExport.authorization.test.tsx`
- Prior evidence: #343 `residual-dispositions.json` branch record; shared-stack-content-review-pending; original donor `b0abb726c138ad1df2f03b7b102c9bd9de318887`.

## 22. codex/ghostpay-feature-consolidation-20261119

- Head: `40b64e8f3a0f34f7b19235ba4655ef918687f22e`
- Open PR: #262
- Differing code paths: 445
- Question: Extract the focused invoice-schema clock/array fixes and review the recovery/private-scan components against #269/#346. Reconcile broad custody, egress, relayer and contract changes by existing owner rather than promoting the whole stack.
- Focus: `apps/web/src/lib/paymentKeyExport.ts`, `packages/invoice-schema/src/schema.ts`, `packages/ux-vault/src/stealth-export-portable.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; shared-stack-content-review-pending; original donor `40b64e8f3a0f34f7b19235ba4655ef918687f22e`.

## 23. codex/ghostpay-private-scan-lint-20261119

- Head: `1b010ec910d04df105fd662cc360629cb0a2f5dd`
- Open PR: none in snapshot
- Differing code paths: 441
- Question: Review only the scan failure/cancellation repair in the #269 successor, preserving cancellation identity and error normalization tests; avoid reopening or bulk-merging this no-PR donor.
- Focus: `apps/web/src/lib/scanClient.test.ts`, `apps/web/src/lib/scanClient.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; shared-stack-content-review-pending; original donor `1b010ec910d04df105fd662cc360629cb0a2f5dd`.

## 24. codex/ghostpay-recovered-lean-checkpoint-20261028

- Head: `371d235c3e5926014c00e027196b6aa567ea1b82`
- Open PR: none in snapshot
- Differing code paths: 138
- Question: Compare the lean profile/runtime and release-evidence changes against current main by subsystem; keep vendor archive/dependency and report-path changes separate. Preserve this historical checkpoint until its 141 differing product paths are dispositioned.
- Focus: `.github/workflows/nightly.yml`, `apps/relayer/relayer.config.example.json`, `apps/relayer/src/abuse.test.ts`, `apps/relayer/src/abuse.ts`, `apps/relayer/src/api.test.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; historical-no-pr-content-review-pending; original donor `371d235c3e5926014c00e027196b6aa567ea1b82`.

## 25. dependabot/npm_and_yarn/npm-minor-patch-71cdd1547c

- Head: `3c95b2a00bdcfb45dd36242ff40c133dd19d1811`
- Open PR: #210
- Differing code paths: 67
- Question: Retain #210 ownership, compare manifests and exact lock with current dependency proposals, and require install/compiler/test compatibility evidence for the selected lock. Do not borrow passes from another dependency graph.
- Focus: `apps/web/package.json`, `package-lock.json`, `package.json`
- Prior evidence: #343 `residual-dispositions.json` branch record; dependency-proposal-review-pending; original donor `3c95b2a00bdcfb45dd36242ff40c133dd19d1811`.

## 26. evidence/ghostpay-idle-session-r2-20261120

- Head: `ebc3fea4640e2a82585a6cfb73a97fbf0b907949`
- Open PR: none in snapshot
- Differing code paths: 97
- Question: Preserve the post-#331 state and route it through the #333/current integration owner. Verify propagation and qualify the selected successor; neither a closed #331 nor the prior #325 merge establishes adoption by #307 or main.
- Focus: `apps/web/src/lib/session.ts`, `apps/web/src/views/Sweep.tsx`
- Prior evidence: #343 `residual-dispositions.json` branch record; late-merge-forward-propagation-pending; original donor `ebc3fea4640e2a82585a6cfb73a97fbf0b907949`.

## 27. feat/ghostpay-privacy-quick-hide-20261120

- Head: `137628961463fc5abd8b7927b2efe6b18a0a206a`
- Open PR: #300
- Differing code paths: 511
- Question: Review quick-hide event ownership, navigation and preview clearing against #326/#361/current recovery; parent snapshot has no own open PR.
- Focus: `apps/relayer/DEVIATIONS.md`, `apps/relayer/Dockerfile`, `apps/relayer/PRIVACY.md`, `apps/relayer/README.md`, `apps/relayer/package.json`, `apps/relayer/relayer.config.example.json`

## 28. feat/ghostpay-tor-completion-20261119

- Head: `e60c69f32dbbd9edf7e81ed8866144d665e3de9a`
- Open PR: #308
- Differing code paths: 2
- Question: Application/script blobs match existing integrations but workflow/configuration differs. Reconcile the full Tor/static artifact contract with #320/#363 without enabling deployment.
- Focus: `scripts/tor/browser-acceptance.mjs`, `scripts/tor/hosting-config.test.mjs`

## 29. feature/ghostpay-retention-completion-20261120

- Head: `a34ce43e296e302e3e65ed077ea8ac892c5189a1`
- Open PR: #326
- Differing code paths: 568
- Question: Verify retention, reload and cross-tab cancellation through #327/#336/#348/#352/#354/#355/#361; keep the parent candidate and privacy runtime dependency explicit.
- Focus: `apps/relayer/DEVIATIONS.md`, `apps/relayer/Dockerfile`, `apps/relayer/PRIVACY.md`, `apps/relayer/README.md`, `apps/relayer/package.json`, `apps/relayer/relayer.config.example.json`

## 30. fix/ghostpay-backup-preflight-20261120-r2

- Head: `3172a93ceb8fce5a4343a93b453dcc0e68f09d87`
- Open PR: #333
- Differing code paths: 99
- Question: Compare original ownership and renamed regression files with #365/#367/new recovery composition; preserve backup-preflight custody and durable-write revocation across current-main changes.
- Focus: `apps/web/DEVIATIONS.md`, `apps/web/e2e/backup-ownership.spec.ts`, `apps/web/e2e/core-journey.spec.ts`, `apps/web/e2e/devnet-journey.spec.ts`, `apps/web/e2e/flowMocks.ts`, `apps/web/e2e/idle-session.spec.ts`

## 31. fix/ghostpay-browser-acceptance-20261120-r3

- Head: `2affd298c364c284d4d74f703fd4a612cc0f16d9`
- Open PR: none in snapshot
- Differing code paths: 570
- Question: Use the #354/#355 overlap supplement: one coordinator-owned successor above #352, one runtime body, both distinct presenter test groups, and #354 browser assertions. Keep any remaining broader inherited source review separate.
- Focus: `apps/web/src/components/WalletDisclosure.test.tsx`, `apps/web/src/components/WalletDisclosure.tsx`
- Prior evidence: #343 `residual-dispositions.json` branch record; historical-no-pr-content-review-pending; original donor `2affd298c364c284d4d74f703fd4a612cc0f16d9`.

## 32. fix/ghostpay-hygiene-transfer-evidence-20261120

- Head: `d03600ca87c7156d4acd1ff78bef6e92c20d9ea4`
- Open PR: #339
- Differing code paths: 4
- Question: Compare full transfer evidence validation plus #347 fixture correction and #341 seven-testnet reuse ledger; select one composed successor without releasing existing owners.
- Focus: `packages/hygiene/src/fixtures.testutil.ts`, `packages/hygiene/src/verify.evidence-boundary.test.ts`, `packages/hygiene/src/verify.test.ts`, `packages/hygiene/src/verify.ts`

## 33. fix/ghostpay-policy-record-seller-identity-20261121

- Head: `e871eccc1238b7145cd1d0a667afb393c373cf83`
- Open PR: #357
- Differing code paths: 6
- Question: Consume independent review of the complete #368->#362->#357 stack, then reconcile child fixes in order and qualify the eventual parent head; current #357 alone is not that reviewed composition.
- Focus: `apps/web/locales/en.json`, `apps/web/src/features/policy/PolicyCreate.tsx`, `apps/web/src/features/policy/PolicyReceive.tsx`, `apps/web/src/features/policy/PolicyView.recordIdentity.test.tsx`, `apps/web/src/features/policy/PolicyView.tsx`, `apps/web/src/features/policy/recordIdentity.ts`

## 34. fix/ghostpay-tron-genesis-guard-gpbug15-20261120

- Head: `b86a3e6affe8b71c6f13d16783accad446271ba4`
- Open PR: #340
- Differing code paths: 5
- Question: #342 is merged; #369 carries the reviewed current-main composition. Verify that child and its hosted checks before parent qualification; source/runtime selected-network guard must remain intact.
- Focus: `apps/web/src/features/tron/TronView.network.test.tsx`, `apps/web/src/features/tron/TronView.tsx`, `apps/web/src/features/tron/chain.hardening.test.ts`, `apps/web/src/features/tron/rpc.network.test.ts`, `apps/web/src/features/tron/rpc.ts`

## 35. fix/ghostpay-vault-rekey-lock-revocation-20261120

- Head: `81598d93dd82cc440526c866d42b55be0657895b`
- Open PR: #328
- Differing code paths: 2
- Question: Retain #328 ownership and review/qualify context identity across rekey, lock and storage completion with its regression; reconcile any later vault changes before adoption.
- Focus: `packages/ux-vault/src/vault.rekey-lock.test.ts`, `packages/ux-vault/src/vault.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; focused-fix-review-pending; original donor `81598d93dd82cc440526c866d42b55be0657895b`.

## 36. ghostpay-cloud-recovery-2026-10-26

- Head: `2ec98b23942838c7177d91c46c66c3768b4ca493`
- Open PR: none in snapshot
- Differing code paths: 129
- Question: Review the old sweep invalidation/locale/runtime claims against current main and selected successors; preserve the 128 differing product paths as a named historical backlog, not as missing implementations solely because their branch is old.
- Focus: `.github/workflows/nightly.yml`, `apps/relayer/relayer.config.example.json`, `apps/relayer/src/abuse.test.ts`, `apps/relayer/src/abuse.ts`, `apps/relayer/src/api.test.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; historical-no-pr-content-review-pending; original donor `2ec98b23942838c7177d91c46c66c3768b4ca493`.

## 37. ghostpay-local-lean-boundary-20261027

- Head: `020ba327e1a26f6d989d428eee19fb12f63dec82`
- Open PR: none in snapshot
- Differing code paths: 138
- Question: Reconcile lean reachability, fixture and report-output protections with the current build/release owner; compare its relationship to the recovered-lean-checkpoint donor before any narrow port.
- Focus: `.github/workflows/nightly.yml`, `apps/relayer/relayer.config.example.json`, `apps/relayer/src/abuse.test.ts`, `apps/relayer/src/abuse.ts`, `apps/relayer/src/api.test.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; historical-no-pr-content-review-pending; original donor `020ba327e1a26f6d989d428eee19fb12f63dec82`.

## 38. ghostpay-offline-deps-2026-10-27

- Head: `3697f539d3a8e5c5c039fb64f4d2bfc970e7f48c`
- Open PR: none in snapshot
- Differing code paths: 129
- Question: Review the vendor Viem archive/provenance and lock metadata separately from the inherited October runtime changes; require current dependency-owner review before considering any dependency change.
- Focus: `.github/workflows/nightly.yml`, `apps/relayer/relayer.config.example.json`, `apps/relayer/src/abuse.test.ts`, `apps/relayer/src/abuse.ts`, `apps/relayer/src/api.test.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; historical-no-pr-content-review-pending; original donor `3697f539d3a8e5c5c039fb64f4d2bfc970e7f48c`.

## 39. ghostpay-sbom-repro-2026-10-27

- Head: `b5b04b999e84e7598dcb98adbf3c44e340223d05`
- Open PR: none in snapshot
- Differing code paths: 131
- Question: Compare normalize-sbom/provenance changes to current release tooling, then disposition inherited offline-dependency/runtime content separately. Preserve source pins; do not infer current packaging correctness from historical report subjects.
- Focus: `.github/workflows/nightly.yml`, `apps/relayer/relayer.config.example.json`, `apps/relayer/src/abuse.test.ts`, `apps/relayer/src/abuse.ts`, `apps/relayer/src/api.test.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; historical-no-pr-content-review-pending; original donor `b5b04b999e84e7598dcb98adbf3c44e340223d05`.

## 40. integration/ghostpay-idle-session-20261120-r2

- Head: `f5e04a30bd538b5dba6202885c8e1c3cceb31fa3`
- Open PR: none in snapshot
- Differing code paths: 97
- Question: Verify propagation of the late #331 merge through #333 and #365/#367/new recovery. The old #325 merge does not prove adoption in #307.
- Focus: `apps/web/DEVIATIONS.md`, `apps/web/e2e/core-journey.spec.ts`, `apps/web/e2e/devnet-journey.spec.ts`, `apps/web/e2e/flowMocks.ts`, `apps/web/e2e/idle-session.spec.ts`, `apps/web/e2e/pages-devnet.spec.ts`

## 41. integration/ghostpay-idle-session-completion-20261119

- Head: `e2ebb4902e53e2249c6585a1d72be6e1e416c36c`
- Open PR: #256
- Differing code paths: 17
- Question: Compare the 17-path idle/backup proposal with sleep-aware #331/#333 and current recovery; preserve every distinct clock/session regression.
- Focus: `apps/web/DEVIATIONS.md`, `apps/web/e2e/idle-session.spec.ts`, `apps/web/e2e/pages-devnet.spec.ts`, `apps/web/locales/ar.json`, `apps/web/locales/en.json`, `apps/web/locales/es.json`

## 42. integration/ghostpay-master-consolidation-20261118

- Head: `bf510471283cb0aa9cf6ff79e640e0b50a0b5d0a`
- Open PR: #264
- Differing code paths: 481
- Question: Use the per-family recovery/idle/private-scan dispositions and separately review self-host/nightly additions against current workflow owners. Keep the broad stack pending; select source-specific ports instead of promoting completion wording.
- Focus: `.github/workflows/nightly.yml`, `apps/web/src/lib/paymentKeyExport.ts`, `deploy/docker-compose.yml`
- Prior evidence: #343 `residual-dispositions.json` branch record; shared-stack-content-review-pending; original donor `bf510471283cb0aa9cf6ff79e640e0b50a0b5d0a`.

## 43. integration/ghostpay-mythril-security-closure-20261118

- Head: `ea47fa75eabb0be2045081ffeb120fc2bfae67ab`
- Open PR: #255
- Differing code paths: 21
- Question: Review evidence completeness and explicit deployment acknowledgments with the contract/security owner; reconcile #225 checker failure handling. Preserve analyzer failures and require current exact-head contract/tooling qualification before any wiring or deployment decision.
- Focus: `packages/contracts/script/DeployPolicy.s.sol`, `packages/contracts/scripts/run-mythril.sh`, `scripts/contract-analysis/mythril-disposition-check.mjs`
- Prior evidence: #343 `residual-dispositions.json` branch record; analyzer-proposal-review-pending; original donor `ea47fa75eabb0be2045081ffeb120fc2bfae67ab`.

## 44. integration/ghostpay-pages-completion-20261118

- Head: `198aa5baff22272453733a0f3dcfcac0e0994eec`
- Open PR: #238
- Differing code paths: 268
- Question: Use #239/#240/#260 and later privacy/recovery children to select precise source; preserve the source lineage and inspect current session/export behavior. Do not wholesale-promote the 285-path historical stack.
- Focus: `apps/web/src/components/StealthExportCommon.tsx`, `packages/ux-vault/src/stealth-export-portable.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; shared-stack-content-review-pending; original donor `198aa5baff22272453733a0f3dcfcac0e0994eec`.

## 45. integration/ghostpay-sweep-consent-20261120

- Head: `2748c9bfd55bd226c7801c15a7acdd955ab70339`
- Open PR: none in snapshot
- Differing code paths: 97
- Question: Preserve the post-#331 state and route it through the #333/current integration owner. Verify propagation and qualify the selected successor; neither a closed #331 nor the prior #325 merge establishes adoption by #307 or main.
- Focus: `apps/web/src/lib/session.ts`, `apps/web/src/views/Sweep.tsx`
- Prior evidence: #343 `residual-dispositions.json` branch record; late-merge-forward-propagation-pending; original donor `2748c9bfd55bd226c7801c15a7acdd955ab70339`.

## 46. integration/ghostpay-tor-qualified-20261121

- Head: `260caca240f9944c05ce8951a154193709e30a56`
- Open PR: #363
- Differing code paths: 5
- Question: Review the Tor/browser qualification changes against #308/#320 and new current-main/recovery artifact; obtain exact artifact execution without equating queued checks with passes.
- Focus: `scripts/tor/browser-acceptance.mjs`, `scripts/tor/hosting-config.test.mjs`, `scripts/tor/identity-container.mjs`, `scripts/tor/identity-diagnostics.test.mjs`, `scripts/tor/identity.test.mjs`

## 47. nodata/wonderful-darwin-kd1h22

- Head: `a92658b1ef6b95ff0145b2e1933d0047d51289d5`
- Open PR: #211
- Differing code paths: 74
- Question: Separate policy binding, chain-specific behavior and privacy UI claims; compare each with current main and narrower owners. Preserve stricter decoder/self-consistency tests and avoid equating this older completion report with finished current behavior.
- Focus: `apps/web/src/components/SecretBackup.tsx`, `apps/web/src/features/policy/send.ts`, `packages/policy-scheme/src/router.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; multi-area-content-review-pending; original donor `a92658b1ef6b95ff0145b2e1933d0047d51289d5`.

## 48. qualify/ghostpay-hygiene-composition-20261120-9a4ab6

- Head: `0e19ccc7d52b0d160fb756089e6a843a1d2831d7`
- Open PR: none in snapshot
- Differing code paths: 6
- Question: Ask the existing hygiene/integration owners to select a single successor preserving both evidence validation and seven-testnet reuse-history regressions, then qualify the composed exact head. Retain the no-PR composition as evidence until then.
- Focus: `packages/hygiene/src/ledger.ts`, `packages/hygiene/src/verify.evidence-boundary.test.ts`, `packages/hygiene/src/verify.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; unpublished-composition-review-pending; original donor `0e19ccc7d52b0d160fb756089e6a843a1d2831d7`.

## 49. repair/ghostpay-analyzer-recovered-20261119

- Head: `e4d54a6829fcc861de7af1669c0e0f64f62aa137`
- Open PR: none in snapshot
- Differing code paths: 464
- Question: Review the latest analyzer-repair commit separately from its inherited 464-path stack; compare #225/#255/current analyzer owners and avoid importing deferred contract/deployment behavior.
- Focus: `apps/relayer/DEVIATIONS.md`, `apps/relayer/Dockerfile`, `apps/relayer/PRIVACY.md`, `apps/relayer/README.md`, `apps/relayer/package.json`, `apps/relayer/relayer.config.example.json`

## 50. repair/ghostpay-final-lint-20261119

- Head: `73d7ccda4fd448dec1682082d633c90de9fa0d7a`
- Open PR: none in snapshot
- Differing code paths: 467
- Question: Identify exact lint-only fixes in the latest commits and compare surviving source in the selected successor; do not qualify the inherited 467-path stack from lint evidence.
- Focus: `apps/relayer/DEVIATIONS.md`, `apps/relayer/Dockerfile`, `apps/relayer/PRIVACY.md`, `apps/relayer/README.md`, `apps/relayer/package.json`, `apps/relayer/relayer.config.example.json`

## 51. repair/ghostpay-native-fee-recovered-20261119

- Head: `cbc96840c3dc4fede90afff55b4dfd94f66784da`
- Open PR: none in snapshot
- Differing code paths: 458
- Question: Isolate native-fee correction and tests from the inherited recovery stack; compare current OP Stack/operator fees and #217/#218 before any port.
- Focus: `apps/relayer/DEVIATIONS.md`, `apps/relayer/Dockerfile`, `apps/relayer/PRIVACY.md`, `apps/relayer/README.md`, `apps/relayer/package.json`, `apps/relayer/relayer.config.example.json`

## 52. repair/ghostpay-pr-87-20261119

- Head: `6b07e403dd26a8c8e12dfab82dedb0c36002b043`
- Open PR: #253
- Differing code paths: 68
- Question: Preserve the #253 dependency owner and bounded net-harness repair; reconcile current compiler/API compatibility and exact-lock evidence separately before deciding on the major upgrade. Do not merge the entire dependency graph based on the narrow fix.
- Focus: `package-lock.json`, `package.json`
- Prior evidence: #343 `residual-dispositions.json` branch record; dependency-proposal-review-pending; original donor `6b07e403dd26a8c8e12dfab82dedb0c36002b043`.

## 53. repair/ghostpay-pr-231-20261118

- Head: `4085622463411d3ba27f4efb7b73a70575170535`
- Open PR: #252
- Differing code paths: 14
- Question: Compare repaired sweep balance-consent/review-authority behavior with #231/#272/current sweep composition; require no request before consent and cancellation after scope changes.
- Focus: `apps/web/e2e/core-journey.spec.ts`, `apps/web/e2e/devnet-journey.spec.ts`, `apps/web/e2e/pages-devnet.spec.ts`, `apps/web/e2e/sweep.spec.ts`, `apps/web/locales/ar.json`, `apps/web/locales/en.json`

## 54. repair/ghostpay-qr-surrogates-20261119

- Head: `ac7b7a11f00896d105fa7a06e44e218046bdc56c`
- Open PR: none in snapshot
- Differing code paths: 467
- Question: Isolate surrogate-input guard and fixture repair from broad inherited source; compare current QR decoder and #360 payment-URI guard because they protect different boundaries.
- Focus: `apps/relayer/DEVIATIONS.md`, `apps/relayer/Dockerfile`, `apps/relayer/PRIVACY.md`, `apps/relayer/README.md`, `apps/relayer/package.json`, `apps/relayer/relayer.config.example.json`

## 55. review/ghostpay-sweep-quote-lifecycle-20261119

- Head: `63ff40d57af879a3d82166450f63aadb7bf0d5ff`
- Open PR: #272
- Differing code paths: 15
- Question: Compare quote invalidation, stale signing authority and unknown-broadcast preservation against current Sweep and selected recovery/journal composition.
- Focus: `apps/web/e2e/core-journey.spec.ts`, `apps/web/e2e/devnet-journey.spec.ts`, `apps/web/e2e/pages-devnet.spec.ts`, `apps/web/e2e/sweep.spec.ts`, `apps/web/locales/ar.json`, `apps/web/locales/en.json`

## 56. security/mythril-full-remediation-20261118

- Head: `16c48521f99903ccd2e584df5d00a9dec5ef754c`
- Open PR: #220
- Differing code paths: 12
- Question: Map each source change to its current workflow/contract/adapter/ledger owner, retain explicit failure gates, and review narrowed deltas against #255/#307. Keep contract and workflow qualification separate from source/ancestry evidence.
- Focus: `.github/workflows/ci.yml`, `packages/chain-adapters/src/rpc.ts`, `packages/confidential-contracts/contracts/GhostPayConfidentialRouter.sol`, `packages/merchant-ledger/src/reconcile.ts`
- Prior evidence: #343 `residual-dispositions.json` branch record; multi-area-content-review-pending; original donor `16c48521f99903ccd2e584df5d00a9dec5ef754c`.

## 57. snapshot/ghostpay-privacy-8be15289-20261120

- Head: `d6819796a9542acc488b896786faffe83b913d9b`
- Open PR: none in snapshot
- Differing code paths: 508
- Question: Use as the parent provenance for #300, then compare sensitive-view lifecycle and persistence paths against #326/#361/new recovery; inherited scope remains unresolved.
- Focus: `apps/relayer/DEVIATIONS.md`, `apps/relayer/Dockerfile`, `apps/relayer/PRIVACY.md`, `apps/relayer/README.md`, `apps/relayer/package.json`, `apps/relayer/relayer.config.example.json`

## 58. work/ghostpay-required-v1-candidate-20261120

- Head: `74dccc419bf5c82b21875d205ed5a97d0c4e69b6`
- Open PR: none in snapshot
- Differing code paths: 527
- Question: Split the 527 differing code paths into recovery, invoice, Sweep, scanning and deferred server/contract families; compare the selected current recovery composition before claiming accepted v1 completion.
- Focus: `apps/relayer/DEVIATIONS.md`, `apps/relayer/Dockerfile`, `apps/relayer/PRIVACY.md`, `apps/relayer/README.md`, `apps/relayer/package.json`, `apps/relayer/relayer.config.example.json`

## 59. work/ghostpay-required-v11-candidate-20261120

- Head: `8c196d12fd45dc5a49a6c1d69f9b5d6c532994e9`
- Open PR: none in snapshot
- Differing code paths: 566
- Question: Split 566 differing code paths into mandatory privacy surfaces and deferred runtime; compare #300/#326/#361/current recovery, including cross-tab/session/endpoint revocation.
- Focus: `apps/relayer/DEVIATIONS.md`, `apps/relayer/Dockerfile`, `apps/relayer/PRIVACY.md`, `apps/relayer/README.md`, `apps/relayer/package.json`, `apps/relayer/relayer.config.example.json`

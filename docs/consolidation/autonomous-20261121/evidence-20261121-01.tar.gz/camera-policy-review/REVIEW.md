# Independent camera and policy integration review

Reviewer: `/root/security_review`. Main snapshot: `aec179910c39081d820396409ff3139ff2264132`.

## Disposition

No blocking source findings in the exact camera PR #258 head `d073414b718242eefdd22c0debc56901045d5f7a` or the policy stack #357/#362/#368 through `18d0442a156106abe2309f8a6e82358aab37961a`. This is independent AI-assisted source review and focused executable verification, not a formal GitHub review or release approval. Required CI, browser, ownership, dependency-order, and branch-protection gates remain with the coordinator.

## Executed verification

- Camera: 77 passed, zero failed/skipped, six complete files; exit 0, 9.92 seconds.
- Full policy directory plus security-key classification suite: 259 passed, zero failed, four existing environment-gated Anvil tests skipped; 16 files passed, one file skipped; exit 0, 33.85 seconds.
- Original Vitest/Vite configuration, one worker, no file parallelism, Node 24.22.3 and Vitest 5.0.5. No assertion, timeout, coverage threshold or skip condition was changed. These commands are focused noncoverage selections, not full-application coverage passes.
- Root lockfile, package sources/manifests, TypeScript base and library build inputs match both heads exactly. Installed dependencies and matching compiled libraries were reused. The 1,665 compiled-file manifest is retained and checked after tests.

Exact commands, complete output hashes, reviewed file fingerprints and boundaries are in `independent-source-review.json`; raw outputs are `camera-tests.log` and `policy-security-tests.log`.

## Review reasoning

The camera patch revokes pending paste/image ownership on hidden-page transitions, denies dispatch and delivery while hidden, and rechecks visibility after synchronous caller invalidation. Existing idle text retention and multipart behavior remain. Consumers still must honor their AbortSignal after their own asynchronous operations; cancellation cannot undo completed actions.

Policy-record parsing already canonicalizes the full meta-address and verifies both public points, policy hashes and limits. The new de-duplication uses that canonical identity, synchronously records ownership, and returns accurate added/duplicate status. Selection for a received account matches the policy hash plus both current seller keys. Export filename hashing covers the full canonical meta-address. Regressions independently vary each seller key, inspect real Blob contents, restore an actually missing record from another record's known limits root, and separately retain duplicate-recovery feedback.

The added already-loaded message is explicitly security classified; exhaustive key parity and source-English fallback for unreviewed security translations remain enforced. The policy feature stays experimental with unchanged deployment admission, signatures and contracts.

## Further recovery ownership

`f03-backup-ownership.json` pins the F03/backup branch and file map. #365 and #367 contain the same application source apart from #367's additional final-account regression. Both preserve #333's SellerKeys source and #344's request-file synchronization test. F03 transport and both file components already match #310 in #307/#365/#367 despite absent #310 ancestry, so they should not be reimplemented.

The distinct Spec18 payment-key export/recovery implementation remains on the #239/#355/#361 lineage. #367 has neither `paymentKeyExport.ts` nor `StealthExportRecovery.tsx` nor #361's application-to-standalone interoperability regression. Seller-keystore backup tests on #367 therefore do not establish completion of independent single-payment recovery. Reconcile the existing implementation rather than creating a second one.

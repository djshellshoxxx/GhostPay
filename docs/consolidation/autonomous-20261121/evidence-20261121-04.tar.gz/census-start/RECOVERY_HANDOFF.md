# GhostPay branch recovery and census review handoff

Reviewer: `/root/branch_recovery`. Scope: read-only repository recovery, independent census review, and scratch evidence. No application edits, remote writes, reviews submitted, merges, deployments, or application tests were performed by this worker.

## Frozen baseline and live snapshot

- Main: `aec179910c39081d820396409ff3139ff2264132`.
- Reviewed census PR #366: `0d8437c1097fad30d505c343ce4da356350ea4c3`.
- Live branch snapshot captured at `2026-11-21T06:10:11.823Z` (November 20 Pacific).
- REST branch pages: **100, 100, 100, 100, 37, 0**. Exactly **437** unique names and immutable heads.
- Open PR pages: **100, 35, 0**, exactly **135** PRs. Mapping is frozen; refresh moving heads before integration.
- Main-equivalent ancestry: **189** heads reachable from main. **247** ahead branches. One unrelated `gh-pages` history.
- Same path heuristic as PR #366: **175** code-path candidates, **66** branches with only `docs/` changes, **6** other noncode branches. These are triage categories, not proof of unique behavior.
- All 437 branches received complete local Git comparisons; **53** live comparisons have at least 300 changed paths. Complete tree IDs, selected and alternative best merge bases, ahead commit lists, paths, and local numstats are preserved. There are **1,589 distinct ahead commit SHAs** across the snapshot.

New branches since the original 433 snapshot:

| Branch | Exact captured head |
| --- | --- |
| `audit/ghostpay-census-20261121-r7` | `0d8437c1097fad30d505c343ce4da356350ea4c3` |
| `fix/ghostpay-policy-security-translation-parity-20261121-r1` | `18d0442a156106abe2309f8a6e82358aab37961a` |
| `integrate/ghostpay-idle-main-scan-20261121-539818` | `45ece45defd2a26cfb7f471ea4654ba4d1d2266e` |
| `integration/ghostpay-idle-scan-candidate-20261121-fc3db` | `50ccf5c8b396247b524e5115ebe51575ca79d318` |

The existing Tor qualification branch moved from `313cea93d727a4ed620a69de6733a2bdff433400` to `260caca240f9944c05ce8951a154193709e30a56`. Later root mutations, including lock generation 12, are outside this frozen snapshot.

## Independent review of PR #366

**Source review passes for the documentation-only census, with the metadata limitations below.**

The 39 changed paths are all documentation/evidence. The 32 comparison chunks contain exactly 433 unique original inventory names with no duplicate, missing, or unexpected row. The recorded base is consistent. Recalculation reproduces **189 ancestry-redundant + 243 ahead + 1 unrelated**, and **172 code + 65 docs-only + 6 other = 243 ahead**.

Every recorded ahead/behind count and merge base is valid after accounting for the explicitly documented camera refresh. The camera row matches old head `84398a79e18673f3e371a405931bc464e1cca99a`, recovered from refreshed head's first parent. Its later pin `d073414b718242eefdd22c0debc56901045d5f7a` intentionally has ahead 2/behind 0 and removes the old ownership-file overlay. Fourteen branches have several valid best merge bases; GitHub's recorded choices are valid.

All recorded changed paths are supported by local Git. Uncapped rows match their complete rename-aware path inventories. The **51** original capped comparisons omit **53,887 path rows** in aggregate; this includes repeated paths across overlapping branches and must not be described as 53,887 unique files or features.

### Numeric metadata caveat

Of **22,384** recorded file rows, **9,459** rows across **70** branches have GitHub additions/deletions **0/0** even though the local Git diff is nonempty. All nonzero recorded statistics match. A fresh API request reproduced `0/0` with no patch for a newly added 168-line JSON file. The old census faithfully records the API; it does not prove those files have zero churn.

Direct reproduction source: `https://api.github.com/repos/djshellshoxxx/GhostPay/compare/aec179910c39081d820396409ff3139ff2264132...6dcd163413fc94d5b2db760d5e15db391760a099?per_page=1&page=1`, file `docs/audits/blue-team-2026-11-19/reviewer-notes/review-root-final-delta.json`.

Interpret these zero rows as omitted/unavailable churn metadata. Use the new complete local numstats for quantitative work. Independent review does not assert behavioral completeness or release readiness. Exact-head CI, branch protection, and the integration lease remain root-owned gates.

## Semantic and ownership dispositions

The refreshed machine-readable census records:

| Disposition | Branches |
| --- | ---: |
| Already incorporated by ancestry | 189 |
| Semantically redundant by exact changed blobs or scoped source review | 15 |
| Superseded by stronger/current source or an existing integration | 4 |
| Documentation or evidence only | 69 |
| Experimental or explicitly deferred | 5 |
| Blocked by existing dependency qualification | 1 |
| **Pending semantic review** | **154** |
| Total | 437 |

The 154 pending branches are not marked complete. **117** have their own open PR. **23** more have an active descendant PR or matching changed-source blobs in an open PR. **14** are outside that mechanical mapping and require targeted historical review. Exact branch-level mappings and reasons are in `branch-census-final.json`.

Seven historical branches have all changed application/package/script blobs identical to main:

- `chatgpt/ghostpay-six-fixes-combined-20261112`
- `chatgpt/zero-codex/cli-sentinel-value-20261111`
- `chatgpt/zero-codex/merchant-schedule-horizon-20261111`
- `chatgpt/zero-codex/onion-canonical-host-20261111`
- `chatgpt/zero-codex/pages-negative-fiat-regression-20261114`
- `chatgpt/zero-codex/ux-confirm-clock-boundary-20261111`
- `chatgpt/zero-codex/ux-guide-plain-object-20261111`

Additional scoped source review avoids reimplementing already incorporated sparse invoice-slot checks, idle-lock hint regressions, Transfer address/block filtering, bounded relayer response streaming, bearer QR warning precedence, and stronger report-file permission preservation.

Two historical corrections must not be restored blindly:

- `fix/remediation-b16c7936-5ce634` at `0b213bd9d43409aaa9671945761e51892aa5d69e`: main already replays claimed router records and adds the necessary resume-floor guard that prevents permanent pinning.
- `fix/remediation-f95457fd-22ecf9` at `6b3e689c15ca0a4ca0bc034ef24c3a2a5fb5ea7a`: main's policy send tests explicitly reject this remediation because it classifies any different scoped payment as legacy and blocks legitimate later payments. Preserve the current same-scope duplicate guard.

The non-string QR guard at `17333ceda784ecdf5734a666ef57ee1d1e599296` is already recovered in PR #290/#295 and broad #307, with reworked tests. Continue those existing integrations.

The TagArchive regression at `8aed22ad44ee2131b36a9e12ec2dc33fe3501e1b` remains preserved in closed, unmerged #193. The live PR description records its full-profile scope deferral. Current main already routes exports through `Common.downloadBlob`, which removes the anchor and revokes the URL when a click throws. No current runtime fix is missing from that specific path; further archive acceptance coverage needs its feature scope reconciled.

### Operational branch exclusion

`automation/ghostpay-integration-lock` contains only `integration-lock.json`. Its apparent thousands of changed code paths are source deletions relative to the selected merge base. It is operational evidence, never an application integration candidate. Root owns and has advanced the lease. This worker did not change it.

Historical paid/API-funded workflow branches are explicitly deferred. GitHub Actions dependency PR #207 remains a separate qualification item; its workflow changes are not labeled documentation.

## Highest-value family handoffs

| Family | Current source of work | Next action |
| --- | --- | --- |
| Camera cancellation | #258, with overlapping source in #365/#367 | Qualify #258's exact source; preserve the same patch when reconciling broad composites. |
| Policy identity/recovery | #368 into #362 into #357 | Preserve child order, source-pin translation classification and recovery tests, then qualify the parent. |
| Payment review revocation | #359 into #345 | Reuse existing lint repair; do not duplicate pending-edit implementation. |
| TRON selected genesis | #342 into #340 | Reuse existing caller corrections and exact chain-genesis tests. |
| Embedded checkout | #351 into #337 | Preserve no-opener behavior and the corrected popup assertion together. |
| Wallet disclosure/retention | #352/#348/#336 and #354/#355/#361, above #327/#326 | Reconcile the complete consent/focus/test chain; newer child checks cannot qualify a different parent composition. |
| Idle locking and backups | #333/#335/#344, #365/#367 and existing #307 | Treat broad candidates as overlapping compositions. Compare source before selecting one; do not bulk-merge both. |
| Recovery interoperability | #346 and recovered #361 | Preserve application-export-to-standalone-recovery coverage while choosing the owner branch. |
| Sweep journal validation | #349 on #307 | Reuse strict journal parse work; verify combined custody/unknown-broadcast safeguards. |
| Hygiene evidence and seven-chain reuse warnings | #339/#347 and #341; composition `0e19ccc7d52b0d160fb756089e6a843a1d2831d7` | Compare the existing composition with both source fixes before integration. No new duplicate implementation is justified. |
| Historical browser fixes | `7dc7eccc34af289050aa1606784a88dfe8a5633a`, `2527d6b9367887508d7d8f678a18564132652a03` | Inspect the four/eight unmatched paths against current tests and accepted Pages scope. These are the smallest remaining unmapped families. |
| Historical security/adapter bundles | `1d28f24d...`, `63994db6...`, `d6f6617e...` | Compare against #218 and current targeted safeguards, keeping CLI/relayer work outside the beta target. Full SHAs and paths are in the JSON census. |

## Evidence and reproduction

Preferred integration artifacts:

1. `PR366_INDEPENDENT_REVIEW.json`: concise independent review receipt.
2. `branch-census-final.json`: 437 pinned branches, classifications, explicit pending state, PR relationships, and feature families.
3. `branch-comparisons.json.gz` plus `branch-comparisons-manifest.json`: complete local comparisons, no 300-file truncation; contains full Git trees and 1,589 distinct ahead SHAs.
4. This handoff.

Supporting diagnostics:

- `historical-census-validation.json`: all 433 original row validations.
- `historical-numstat-validation.json`: API zero-metadata discrepancies.
- `live-branches.json`, `open-prs.json`: frozen connector snapshots.
- `audit_census.py`, `validate_numstats.py`, `map_families.py`: scratch analysis scripts. They use only Python standard library and local Git.
- `census-review.json` is an early diagnostic; its apparent merge-base/path mismatches are resolved by the final validation above. Do not publish it as the authoritative verdict.

Commands actually executed include local `git merge-base --all`, `git rev-list --left-right --count`, complete `git diff --numstat` and rename-aware path comparisons, `git ls-tree`, commit/source inspection, and the analysis scripts. These are census/source checks; no Vitest, browser, build, or security-gate execution is claimed by this worker.

No branch, historical provenance, or application source was modified. Root should append the selected evidence to the existing authoritative ledger after its product milestones and refresh every head affected since this snapshot.


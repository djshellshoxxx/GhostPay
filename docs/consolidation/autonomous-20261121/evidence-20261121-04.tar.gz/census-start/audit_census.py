import concurrent.futures
import collections
import datetime
import json
import pathlib
import subprocess

ROOT = pathlib.Path('/workspace/scratch/5ceb6203640a')
REPO = ROOT / 'GhostPay'
OUT = ROOT / 'recovery-evidence'
BASE = 'aec179910c39081d820396409ff3139ff2264132'
CENSUS = '0d8437c1097fad30d505c343ce4da356350ea4c3'

def git(*args, check=True):
    p = subprocess.run(['git', *args], cwd=REPO, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode:
        raise RuntimeError(f'{args}: {p.stderr}')
    return p.stdout.strip()

def show_json(path):
    return json.loads(git('show', CENSUS+':'+path))

def kind(path):
    if path.startswith(('apps/', 'packages/', 'scripts/')):
        return 'code'
    if path.startswith(('docs/', 'evidence/')) or path.endswith(('.md', '.txt')):
        return 'docs'
    return 'noncode'

def inspect(branch):
    name, head = branch['name'], branch['sha']
    merge_base = git('merge-base', BASE, head, check=False)
    if not merge_base:
        return dict(branch, comparison_base=BASE, merge_base=None, status='unrelated', classification='Experimental or deferred', classification_reason='Separate publication history; source merge inappropriate.', ahead=None, behind=None, files=[])
    behind, ahead = map(int, git('rev-list','--left-right','--count',BASE+'...'+head).split())
    raw = git('diff','--numstat','--no-renames',merge_base,head)
    files = []
    for line in raw.splitlines():
        add, remove, path = line.split('\t',2)
        files.append({'path':path,'additions':int(add) if add!='-' else None,'deletions':int(remove) if remove!='-' else None,'kind':kind(path)})
    final_changed = set(git('diff','--name-only','--no-renames',BASE,head).splitlines())
    sem_unmatched = [x['path'] for x in files if x['kind']=='code' and x['path'] in final_changed]
    stat = collections.Counter(x['kind'] for x in files)
    if ahead == 0:
        status, classification, reason = 'ancestry-redundant', 'Already incorporated', 'Exact head is reachable from main.'
    elif not files or not stat['code']:
        status = 'docs-only' if all(x['kind']=='docs' for x in files) else 'noncode-only'
        classification, reason = 'Documentation or evidence only', 'Changed paths contain no application/package/script code; config changes still need review.'
    elif not sem_unmatched:
        status, classification, reason = 'code-tree-equivalent', 'Semantically redundant', 'All changed application/package/script path blobs equal current main; documentation may remain unique.'
    else:
        status, classification, reason = 'code-candidate', None, 'Semantic review required; ahead commits and differing blobs do not prove unique useful behavior.'
    return dict(branch,comparison_base=BASE,merge_base=merge_base,ahead=ahead,behind=behind,status=status,classification=classification,classification_reason=reason,file_count=len(files),files=files,unmatched_code_paths=sem_unmatched)

live=json.loads((OUT/'live-branches.json').read_text())
original=show_json('docs/handoffs/GHOSTPAY_BRANCH_INVENTORY_20261121_R7.json')
pins=show_json('docs/handoffs/BRANCH_HEADS_R7_20261121.json')
pin_by_name={r['branch']:r['sha'] for r in pins['source_head_shas']}
paths=git('diff','--name-only',BASE,CENSUS).splitlines()
chunks=[show_json(p) for p in paths if '/BRANCH_COMPARE_R7_' in p]
rows=[r for c in chunks for r in c['results']]
historic_by_name={r['branch']:r for r in rows}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    results=list(pool.map(inspect,live['branches']))
by_name={r['name']:r for r in results}
drift=[]
mismatches=[]
truncated=[]
for name in original['branches']:
    old=historic_by_name[name]
    now=by_name.get(name)
    if now is None:
        drift.append({'branch':name,'kind':'removed'})
        continue
    if pin_by_name[name]!=now['sha']:
        drift.append({'branch':name,'kind':'moved','old':pin_by_name[name],'new':now['sha']})
        old_snapshot=inspect({'name':name,'sha':pin_by_name[name]})
    else:
        old_snapshot=now
    for k in ['ahead','behind','merge_base']:
        if old.get(k)!=old_snapshot.get(k) and old_snapshot['status']!='unrelated':
            mismatches.append({'branch':name,'field':k,'recorded':old.get(k),'pinned':old_snapshot.get(k),'pin':pin_by_name[name]})
    if old.get('truncated') or len(old.get('files',[]))>=300:
        old_paths={x[0] for x in old.get('files',[])}
        all_paths={x['path'] for x in old_snapshot['files']}
        truncated.append({'branch':name,'head':pin_by_name[name],'recorded_file_count':len(old_paths),'complete_file_count':len(all_paths),'omitted_paths':sorted(all_paths-old_paths),'unexpected_recorded_paths':sorted(old_paths-all_paths)})
    elif old_snapshot['status']!='unrelated':
        old_paths={x[0] for x in old.get('files',[])}
        all_paths={x['path'] for x in old_snapshot['files']}
        if old_paths!=all_paths:
            mismatches.append({'branch':name,'field':'file_paths','recorded_only':sorted(old_paths-all_paths),'pinned_only':sorted(all_paths-old_paths),'pin':pin_by_name[name]})
summary={
 'schema':'ghostpay-census-independent-review/1','reviewed_census_head':CENSUS,'comparison_base':BASE,
 'captured_at':live['captured_at'],'pagination_counts':live['source_pages'],
 'live_branch_count':len(results),'unique_branch_count':len(by_name),'historical_branch_count':len(original['branches']),
 'comparison_chunks':len(chunks),'historical_rows':len(rows),'duplicate_rows':[n for n,c in collections.Counter(r['branch'] for r in rows).items() if c>1],
 'missing_historical_names':sorted(set(original['branches'])-set(historic_by_name)),
 'unexpected_historical_names':sorted(set(historic_by_name)-set(original['branches'])),
 'chunk_base_mismatches':[c['base'] for c in chunks if c['base']!=BASE],
 'current_status_counts':dict(collections.Counter(r['status'] for r in results)),
 'current_category_counts':dict(collections.Counter('ancestry-redundant' if r['ahead']==0 else 'unrelated' if r['status']=='unrelated' else 'code' if any(f['kind']=='code' for f in r['files']) else 'docs-only' if all(f['kind']=='docs' for f in r['files']) else 'noncode-only' for r in results)),
 'post_snapshot_additions':[{'branch':r['name'],'head':r['sha'],'ahead':r['ahead'],'behind':r['behind'],'file_count':r.get('file_count'),'status':r['status']} for r in results if r['name'] not in historic_by_name],
 'branch_drift':drift,'historic_pin_mismatches':mismatches,'capped_comparisons':truncated,
 'limitations':['Files compared with --no-renames, so rename pairs may have two paths rather than GitHub rename metadata.','Late supplemental source pins cannot establish earlier moving-branch comparison heads.','Automatic tree and ancestry classification does not establish behavioral equivalence for unmatched code candidates.']
}
(OUT/'live-comparisons.json').write_text(json.dumps({'schema':'ghostpay-live-comparisons/1','base':BASE,'branches':results},indent=2)+'\n')
(OUT/'census-review.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='capped_comparisons'},indent=2))
print('Uncapped comparison totals:',len(truncated),sum(x['complete_file_count']-x['recorded_file_count'] for x in truncated))

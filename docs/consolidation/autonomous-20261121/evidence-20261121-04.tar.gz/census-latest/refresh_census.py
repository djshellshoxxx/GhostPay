"""Read-only exact-SHA branch census. Writes only this scratch evidence directory."""
import collections
import concurrent.futures
import functools
import gzip
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path('/workspace/scratch/5ceb6203640a')
REPO = ROOT / 'GhostPay'
OUT = ROOT / 'census-latest-evidence'
PRIOR = ROOT / 'census-followup-evidence'
live = json.loads((OUT / 'live-branches.json').read_text())
pr_snapshot = json.loads((OUT / 'open-prs.json').read_text())
previous = json.loads((PRIOR / 'branch-census-final.json').read_text())
BASE = live['main']
old_by_name = {b['name']: b for b in previous['branches']}

def git(*args, check=True):
    p = subprocess.run(['git', *args], cwd=REPO, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if check and p.returncode:
        raise RuntimeError(str(args) + ': ' + p.stderr.decode())
    return p.stdout.decode().rstrip('\n')

def kind(path):
    if path.startswith(('apps/', 'packages/', 'scripts/')):
        return 'code'
    if path.startswith(('docs/', 'evidence/')) or path.endswith(('.md', '.txt')):
        return 'docs'
    return 'noncode'

@functools.lru_cache(maxsize=None)
def tree(ref):
    result = {}
    for row in git('ls-tree', '-rz', ref).split('\0'):
        if row:
            meta, path = row.split('\t', 1)
            result[path] = meta.split()[2]
    return result

def inspect(branch):
    head = branch['sha']
    bases = git('merge-base', '--all', BASE, head, check=False).splitlines()
    common = dict(branch, comparison_base=BASE, source_tree=git('rev-parse', head+'^{tree}'), all_best_merge_bases=bases)
    if not bases:
        return dict(common, merge_base=None, ahead=None, behind=None, file_count=0, files=[], ahead_commit_shas=[], unmatched_code_paths=[], status='unrelated', classification='Experimental or deferred', classification_reason='Separate publication history; source merge inappropriate.', review_status='ancestry-or-tree-classified')
    merge_base = bases[0]
    behind, ahead = map(int, git('rev-list', '--left-right', '--count', BASE+'...'+head).split())
    files = []
    for entry in git('diff', '--numstat', '--no-renames', '-z', merge_base, head).split('\0'):
        if entry:
            adds, dels, path = entry.split('\t', 2)
            files.append(dict(path=path, additions=None if adds=='-' else int(adds), deletions=None if dels=='-' else int(dels), kind=kind(path)))
    final_changed = set(git('diff', '--name-only', '--no-renames', '-z', BASE, head).split('\0'))
    unmatched = [f['path'] for f in files if f['kind']=='code' and f['path'] in final_changed]
    status, classification, reason = 'code-candidate', None, 'Semantic review required; ahead commits and differing blobs do not establish unique useful behavior.'
    if ahead == 0:
        status, classification, reason = 'ancestry-redundant', 'Already incorporated', 'Exact source head is reachable from the frozen main.'
    elif not any(f['kind']=='code' for f in files):
        status = 'docs-only' if all(f['kind']=='docs' for f in files) else 'noncode-only'
        classification, reason = 'Documentation or evidence only', 'No application/package/script paths in merge-base delta; configuration still requires review.'
    elif not unmatched:
        status, classification, reason = 'code-tree-equivalent', 'Semantically redundant', 'Every changed application/package/script blob equals current main.'
    return dict(common, merge_base=merge_base, ahead=ahead, behind=behind, file_count=len(files), files=files, ahead_commit_shas=git('rev-list', head, '^'+BASE).splitlines(), unmatched_code_paths=unmatched, status=status, classification=classification, classification_reason=reason, review_status='semantic-review-pending' if classification is None else 'ancestry-or-tree-classified')

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    comparisons = list(pool.map(inspect, live['branches']))
print('Compared', len(comparisons), 'immutable branch heads', flush=True)
prs = pr_snapshot['prs']
pr_by_branch = {p['branch']: p for p in prs}
ancestors = {p['number']: set(git('rev-list', p['head']).splitlines()) for p in prs}
active_trees = {p['number']: tree(p['head']) for p in prs}
base_changed = set(git('diff', '--name-only', previous['baseline_main'], BASE).splitlines())
branches = []
for comp in comparisons:
    b = {k: v for k, v in comp.items() if k not in ('files','ahead_commit_shas')}
    old = old_by_name.get(b['name'])
    own = pr_by_branch.get(b['name'])
    b['open_pr'] = own['number'] if own else None
    b['open_pr_base'] = own['base'] if own else None
    b['active_descendant_prs'] = [p['number'] for p in prs if p['head'] != b['sha'] and b['sha'] in ancestors[p['number']]]
    b['family'] = old.get('family', []) if old else ['TRON validation'] if own and own['number']==369 else []
    if b['status']=='code-candidate' and b['name']!='automation/ghostpay-integration-lock':
        changed = [f['path'] for f in comp['files'] if f['kind']=='code' and not f['path'].endswith(('.md','.txt'))]
        source = tree(b['sha'])
        b['matching_changed_source_prs'] = [p['number'] for p in prs if p['head']!=b['sha'] and all(source.get(path)==active_trees[p['number']].get(path) for path in changed)]
    # Carry a prior scoped finding only when its source is identical and current-main edits
    # do not touch its inspected changed source paths. The original receipt stays referenced.
    if old and old['sha']==b['sha'] and old.get('review_status')=='scoped-source-review-complete' and b['ahead'] != 0:
        relevant = {f['path'] for f in comp['files'] if f['kind']=='code'}
        if not (base_changed & relevant):
            b.update(classification=old['classification'], classification_reason=old['classification_reason'], review_status='prior-scoped-source-review-revalidated')
            b['prior_review'] = {'main':previous['baseline_main'],'source_sha':old['sha'],'intersecting_new_main_paths':[],'artifact':'../recovery-evidence/branch-census-final.json'}
    if b['name']=='automation/ghostpay-integration-lock':
        b.update(classification='Documentation or evidence only', classification_reason='Operational metadata-only tree: apparent code delta consists of deletions. Never merge this ref as source.', review_status='operational-metadata-excluded')
    if b['classification'] is None:
        b['next_action'] = f"Continue existing PR #{own['number']}; inspect live dependencies, ownership, source and checks." if own else 'Review unique patches against current behavior; no merge qualification established.'
        if b.get('matching_changed_source_prs'):
            b['next_action'] = 'Continue an existing integration with matching changed source blobs; inspect behavior before retiring this historical ref.'
        elif b['active_descendant_prs'] and not own:
            b['next_action'] = 'Review surviving behavior in active descendant PRs; ancestry alone does not establish semantic retention.'
    branches.append(b)

by_name = {b['name']:b for b in branches}
pr_records = []
for p in prs:
    b = by_name.get(p['branch'])
    parent = pr_by_branch.get(p['base'])
    chain, seen, node = [], set(), p
    while node and node['number'] not in seen:
        seen.add(node['number']); chain.append(node['number']); node=pr_by_branch.get(node['base'])
    if node:
        raise RuntimeError('PR dependency cycle at '+str(p['number']))
    disposition = 'Pending source and exact-head qualification'
    if b and b['classification']=='Already incorporated': disposition='Source head incorporated in frozen main; reconcile PR metadata'
    elif b and b['classification']=='Documentation or evidence only': disposition='Evidence/configuration review pending; no application completion implied'
    elif b and b['classification'] in ('Experimental or deferred','Superseded','Semantically redundant'): disposition=b['classification']+'; verify PR-specific purpose before closing'
    record = {k:p[k] for k in ('number','title','url','head','branch','base','base_sha','draft','updated_at','author')}
    record.update(parent_pr=parent['number'] if parent else None, dependency_chain=chain, base_is_main=p['base']=='main', parent_branch_without_open_pr=p['base'] if p['base']!='main' and parent is None else None, disposition=disposition, merge_gate='Blocked: integration owner stop/release proof is absent; do not update shared target.', source_classification=b['classification'] if b else None, source_inventory_exact_head=b is not None and b['sha']==p['head'], review_limit='Metadata/dependency triage only; this index does not claim complete comments, reviews, executable tests or approval.')
    pr_records.append(record)

changes=[]
for b in branches:
    old=old_by_name.get(b['name'])
    if not old: changes.append({'name':b['name'],'kind':'added','new':b['sha']})
    elif old['sha']!=b['sha']: changes.append({'name':b['name'],'kind':'moved','old':old['sha'],'new':b['sha']})
for old in previous['branches']:
    if old['name'] not in by_name: changes.append({'name':old['name'],'kind':'removed','old':old['sha']})
summary = dict(schema='ghostpay-exact-main-branch-census/2', baseline_main=BASE, main_tree=git('rev-parse',BASE+'^{tree}'), captured_at=live['captured_at'], branch_pagination=live['source_pages'], open_pr_pagination=pr_snapshot['pages'], branch_count=len(branches), open_pr_count=len(prs), prior_snapshot={'main':previous['baseline_main'],'captured_at':previous['captured_at'],'branches':previous['branch_count'],'open_prs':previous['open_pr_count']}, ancestry_counts={'already_incorporated':sum(b['ahead']==0 for b in branches),'ahead':sum((b['ahead'] or 0)>0 for b in branches),'unrelated':sum(b['status']=='unrelated' for b in branches)}, original_heuristic_counts=dict(collections.Counter('code_path_candidates' if any(f['kind']=='code' for f in b['files']) else 'docs_directory_only' if all(f['path'].startswith('docs/') for f in b['files']) else 'other_noncode' for b in comparisons if (b['ahead'] or 0)>0)), classification_counts=dict(collections.Counter(b['classification'] or 'Pending semantic review' for b in branches)), full_comparison_counts={'branches_with_300_or_more_paths':sum(b['file_count']>=300 for b in comparisons),'branches_with_multiple_best_merge_bases':sum(len(b['all_best_merge_bases'])>1 for b in branches),'unique_ahead_commit_shas':len({s for b in comparisons for s in b['ahead_commit_shas']})}, changes_since_prior_snapshot=changes, branches=branches, limitations=['Complete uncapped Git inventory is not complete behavioral qualification.','Pending semantic reviews remain explicit; preserved past findings cite their old main snapshot.','All shared-target merges are on hold pending verified prior integration-owner release.','No application tests or security qualification ran in this census worker.','PR index is metadata/dependency disposition, not a claim to have read every discussion or reviewed every patch.'])
raw=(json.dumps({'schema':'ghostpay-live-comparisons/2','base':BASE,'comparison_method':'all best merge bases recorded; first chosen deterministically for complete --no-renames --numstat delta; exact source tree and every ahead SHA retained; no GitHub file cap','branches':comparisons},indent=2)+'\n').encode()
compressed=gzip.compress(raw,mtime=0)
(OUT/'branch-comparisons.json.gz').write_bytes(compressed)
manifest={'path':'branch-comparisons.json.gz','compression':'gzip','compressed_bytes':len(compressed),'compressed_sha256':hashlib.sha256(compressed).hexdigest(),'uncompressed_bytes':len(raw),'uncompressed_sha256':hashlib.sha256(raw).hexdigest(),'branches':len(branches),'main':BASE}
for name,data in [('branch-census-final.json',summary),('branch-comparisons-manifest.json',manifest),('pr-dependency-dispositions.json',{'schema':'ghostpay-pr-dependency-dispositions/1','main':BASE,'captured_at':live['captured_at'],'open_pr_count':len(prs),'prs':pr_records})]:
    (OUT/name).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k not in ['branches','limitations']},indent=2))

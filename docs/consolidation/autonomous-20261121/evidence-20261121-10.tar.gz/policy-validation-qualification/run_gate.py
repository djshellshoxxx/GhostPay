import datetime
import json
import os
from pathlib import Path
import subprocess
import sys
import time

name, cwd, *command = sys.argv[1:]
root = Path('/workspace/scratch/5ceb6203640a/policy-validation-evidence')
def git(*args):
    return subprocess.check_output(['git', '-C', cwd, *args], text=True).strip()
before = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain')}
start = time.monotonic()
at = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root / (name + '.log')).open('w') as output:
    result = subprocess.run(command, cwd=cwd, env=os.environ.copy(), stdout=output, stderr=subprocess.STDOUT)
receipt = {'command': command, 'cwd': cwd, 'started_at': at, 'elapsed_seconds': round(time.monotonic()-start, 3),
           'exit_code': result.returncode, 'before': before,
           'after': {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain')},
           'log': name+'.log'}
(root / (name + '.json')).write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
sys.exit(result.returncode)

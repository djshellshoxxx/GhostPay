# Policy defensive validation restoration — 2026-11-21 UTC

## Frozen source

- Exact parent: `e1ab03ca7b07c225ae42d0c16fb79b97f0a1f95c`.
- Source commit: `dee9202c4f7d3cfb0233aca838b361c15b2a5345`; tree `ff04943bef13c739d6fb914d1172ed2e7e828dfd`.
- Branch: `recover/ghostpay-policy-validation-20261121-5ceb`.
- Production restoration commit: `fc3c1f55aefe719fc1e906ff88dda81b3e0ceb7d`; tests: `2eafa9ab6199c97e877adaf9f92ef88fe6354c54` and `dee9202c4f7d3cfb0233aca838b361c15b2a5345`.
- This is an isolated child of policy withdrawal-asset recovery, not a competing mainline implementation. Root owns review, publication and integration decisions. Source remains frozen during independent review.

## Changes and preserved behavior

The restoration checks policy typed-data shape and reconstructs its supported signing domain, type and message before computing the signed digest. It checks canonical router calldata, compressed ephemeral point format and consistency between announced metadata and the transfer. Stored limit leaves must match their recomputed values. Viewing-key copies are made only after ordinary argument validation. The payment preparation and final submission share one comparison of the locally derived announcement fields.

The five package/docs files exactly match source `a92658b1ef6b95ff0145b2e1933d0047d51289d5`; source-manifest.json records blob identities and SHA-256. Application pay/send changes are selectively applied. Seventeen source checks verify donor equality and preservation of parent asset coverage, seller identity, record handling, policy UI, and catalogs. No contract, ABI, protocol, fee, custody, dependency or workflow changes are included.

The stricter decoder caused two old sender fixtures to reach an earlier error because their metadata no longer matched the changed token/gross. The original historical fixture repair rebuilds that metadata consistently. The existing error assertions and zero-wallet-send assertions remain unchanged. Nine ordinary supported-copy and missing-field API checks were added to retain the original coverage gates.

## Provenance

| Source commit | Restored defensive behavior |
| --- | --- |
| `0c0bbaa26d6ccf9e3a4a0c079c28a75559238374` | Canonical calldata, compressed point and metadata consistency |
| `6e27f497e3f526921b6f9ad3a98dc5cba87d82a2` | Policy typed-data shape validation |
| `86fa1fef1aeff8c37b9b5f2fd2d926087256774f` | Withdrawal leaf recomputation |
| `ba877c31e0730f5838322828ec3c02194028375c` | Restored limit-tree leaf recomputation |
| `1613308217adac75f7acf84b924b9ad4accdb41f` | Validate arguments before copying viewing secret |
| `ca2c6b75017504bee66c65e01653da21410f4a53` | Reconstruct supported domain/types/message and sign only recomputed digest |
| `60f44acdc6eb9ae87ddae6488ea6feafd5618f05` | Prepared-payment announcement consistency at prepare and submit |
| `0dab0db44c349a45a19e20df9449c430d3bcedbe` | Existing test fixtures rebuild consistent asset/amount metadata |

## Verification

All dependency installation and build output uses this worktree’s own directories; node_modules is not a symlink. Setup was `npm ci --ignore-scripts --prefer-offline --no-audit` (exit 0; 722 packages), Node v24.22.3 and npm 11.19.1.

Each `*.json` command receipt records command, working directory, elapsed time, exit code and before/after source/tree/status. Complete stdout/stderr is in its paired log. The library build ran on the production-restoration commit; later changes were tests only. Final source remains `dee9202c` for all final checks.

| Check | Exact command | Result |
| --- | --- |
| Own library build | `npm run build:libs` | Passed; 95.529 s |
| Policy package original coverage | `../../node_modules/.bin/vitest run --coverage --maxWorkers=2` in packages/policy-scheme | Passed: 103 tests, 7 native skips; statements 95.28%, branches 93.24%, functions 100%, lines 98.71%; original thresholds unchanged |
| Existing web policy suite | `../../node_modules/.bin/vitest run src/features/policy --maxWorkers=2` in apps/web | Passed: 262 tests, 4 native skips; 18 files passed, 1 skipped |
| Policy TypeScript | `npm run typecheck --workspace @ghostpay/policy-scheme` | Passed |
| Web TypeScript | `npm run typecheck --workspace @ghostpay/web` | Passed |
| Package lint | `npm run lint --workspace @ghostpay/policy-scheme` | Passed at the preceding test checkpoint; final changed-file lint also passed |
| Final changed-file lint | `node_modules/.bin/eslint --config eslint.config.js apps/web/src/features/policy/pay.ts apps/web/src/features/policy/send.ts apps/web/src/features/policy/send.test.ts packages/policy-scheme/src/validation-shape.test.ts` | Passed |
| Full profile build and bundle scan | `npm run build --workspace @ghostpay/web` | Passed; 19 bundle files; bundled deployment source validated |
| Lean profile build and bundle scan | `env GHOSTPAY_LOCAL_BUILD_PROFILE=lean GP_COMMIT=dee9202c4f7d3cfb0233aca838b361c15b2a5345 npm run build --workspace @ghostpay/web` | Passed; local static Pages build and bundle scan |
| Committed-secret scan | `npm run ci:scan-secrets` | Passed |
| Full web original coverage | `../../node_modules/.bin/vitest run --coverage --maxWorkers=2` in apps/web | Passed: 2,837 tests, 13 skipped; 206 files passed, 2 skipped; original thresholds unchanged; statements 93.30%, branches 89.54%, functions 94.82%, lines 97.03%; 676.780 s |
| Existing web noncoverage suite | `../../node_modules/.bin/vitest run --config vitest.nocov.config.ts --maxWorkers=2` in apps/web | Passed: 3 files, 3 tests |

Initial failed runs remain in the packet: package statement coverage was 94.24% despite 94 passing tests; the new shape-test cast failed TypeScript; the existing web policy selection had 260 passes/2 fixture assertion failures/4 native skips. These were corrected without changing production behavior, existing assertions or gate thresholds. Those initial runs are failures, not retroactive passes.

The full coverage selection and focused policy selection overlap; their pass counts must not be added as unique cases. The full web aggregate reports 13 skipped tests in two skipped files, all retained as skips. Final source/tree/status remained unchanged and clean.

## Qualification limits

- No vulnerable revisions executed and no new exploit-like payloads or attack tests designed.
- Historical adversarial decoder/signing/Merkle-leaf and prepared-payment regressions were not restored or executed; do not classify them as passed.
- Native package Anvil suite7 skipped; existing focused app Anvil suite4 skipped. Native-chain verification pending.
- Chromium/Firefox/WebKit/mobile/Tor checks have not run on this child.
- Release reproducibility/artifact integrity and hosted required CI are not asserted by local full build and bundle scan.
- No contract/protocol/fee/fund-control/dependency/workflow changes; no contract test execution claimed.
- Fresh independent review is complete in the separate policy-validation-review-evidence packet: no blocking source finding within the defined scope; not merge qualification. The reviewer independently ran 365 passing tests and recorded 11 native skips, both affected TypeScript checks and all changed-file lint. It independently verified 4,001 untouched parent entries and preservation of all 83 sender assertions and 42 suite/test titles.
- Generation11 integration lease remains held by994a0d214fb9-root-r3 and unreconciled; no remote ref updates, merge, deployment, release or real provider/funds actions performed.

## Next steps

1. Root attaches this packet and the separate fresh reviewer packet to the authoritative coordination ledger.
2. Root publishes the reviewed exact-source child of the policy asset recovery parent, preserving provenance and dependencies.
3. Complete the explicitly unexecuted sensitive/native/browser/release/hosted checks and reconcile integration authority before merge qualification.

## Recoverability

`policy-validation.bundle` was verified with `git bundle verify`. It includes the child and local parent history, requiring only public checkpoint commits #368 `18d0442a156106abe2309f8a6e82358aab37961a`, main `eb59d93cffed7848c4aac37d0e9650b87239c6da`, and #345 `ccc8c3521511e2a2b9b66ef11f12723d87ce5f44`. Its SHA-256 is in HANDOFF.json. No remote refs have been modified by this worker.

# Independent review — policy validation restoration

## Decision and exact scope

**No blocking source defect was identified within this bounded defensive review.** The independently executed corrected-source package and policy application suites passed **365 tests**, with **11 native integration cases skipped** and **0 failures**. Both package and web TypeScript checks, lint for all eight changed TypeScript/test files, the diff whitespace check and the source-preservation verifier exited 0.

This packet is **not merge qualification**. The skipped native tests, excluded historical sensitive regressions, browser/hosted gates and integration requirements remain separate. This is one independent AI-worker review, not a formal GitHub approval or external cryptographic audit.

| Reference | Exact value |
| --- | --- |
| Reviewed commit | `dee9202c4f7d3cfb0233aca838b361c15b2a5345` |
| Reviewed tree | `ff04943bef13c739d6fb914d1172ed2e7e828dfd` |
| Asset-coverage parent | `e1ab03ca7b07c225ae42d0c16fb79b97f0a1f95c` |
| Historical donor (#211) | `a92658b1ef6b95ff0145b2e1933d0047d51289d5` |
| Author | `/root/policy_validation_restore` |
| Independent reviewer | `/root/policy_validation_review` |
| Worktree | `/workspace/scratch/5ceb6203640a/GhostPay-policy-validation` |

All executable checks recorded the same head, tree and clean tracked/untracked Git status before and after. The reviewer edited no application source, installed or built no dependencies, and made no remote, PR, lease, deployment or provider/funds action. Evidence was written only to the separate review directory.

## Findings and contract assessment

The standards axis used the repository instructions, ownership claim and bounded assignment. The specification axis used the author claim, exact historical donor, API documentation, unchanged Solidity contracts and current parent behavior. Both axes were assessed by this independent reviewer; no additional review agents are claimed.

### Documented input contract and digest reconstruction

The signer validates the supported primary type, exact ordered field definitions, policy-domain shape/name/version/chain/account, and copied message field types. It reconstructs the struct and domain digest using the canonical package definitions, cross-checks with viem, requires claimed-digest equality, and signs/recovers only that local digest. Input validation precedes secret exposure. Four type strings and their field order match the unchanged Solidity source. Semantic approval of amounts/deadlines/destinations remains a caller responsibility, as documented.

Source: `packages/policy-scheme/src/eip712.ts`, `packages/policy-scheme/README.md`.

### Limit proof consistency

Merkle membership and the recomputed token/limit/window leaf are both checked before a stored proof is returned or accepted by the withdrawal builder. The recomputed double-hash encoding matches the unchanged contract. Existing amount and no-limits rules are retained. The new helper is not added to the package public index.

Source: `packages/policy-scheme/src/limits.ts`, `packages/policy-scheme/src/eip712.ts`.

### Secret-copy lifetime

Announcement argument validation now precedes the viewing-secret copy. Every subsequent return/error from the scanning body remains inside the existing try/finally zeroization boundary. Signing validates/copies public typed data before exposing the owner key; the signing key copy retains its finally zeroization. JavaScript cleanup is documented as best effort.

Source: `packages/policy-scheme/src/derive.ts`, `packages/policy-scheme/src/eip712.ts`.

### Payment decoding and derived-payment comparison

The decoder re-encodes the supported payment ABI canonically, validates the compressed announcement key and metadata, preserves CREATE2 policy-account binding, and checks asset/net/minNet consistency. Native msg.value remains explicitly outside the calldata decoder. The shared app comparison binds method, derived account/owner/policy, ephemeral key, full metadata and derivation prefix during preparation and the last synchronous send check.

Source: `packages/policy-scheme/src/router.ts`, `apps/web/src/features/policy/pay.ts`, `apps/web/src/features/policy/send.ts`.

### Current authority, identity, privacy and journal boundaries

The asset guard remains byte-identical to the parent, retaining policy-commitment negative evidence and exact seller-identity positive evidence. Review snapshots, equality checks, session authority checks, approval/readback handling, single-use reviews, broadcast errors and duplicate-journal submission behavior are preserved. All unchanged parent paths, including wallet/privacy/journal implementation, are verified by tree comparison.

Source: `apps/web/src/features/policy/pay.ts`, `apps/web/src/features/policy/send.ts`, `apps/web/src/features/policy/PolicyPay.tsx`, `apps/web/src/features/policy/recordIdentity.ts`, `apps/web/src/lib/wallet.ts`, `apps/web/src/lib/payExec.ts`, `apps/web/src/lib/duplicateAttemptJournal.ts`.

### Regression intent and standards

Existing send fixtures remain internally canonical so their original final token/amount guards are still reached. All 83 existing assertion lines and 42 test/suite title lines are exact parent matches. Nine new package cases cover supported plain-copy signing and ordinary missing fields. The ownership claim is additive; the scope does not change contracts, protocol, fees, custody, dependencies or CI gates.

Source: `apps/web/src/features/policy/send.test.ts`, `packages/policy-scheme/src/validation-shape.test.ts`, `docs/ai/ACTIVE_WORK.md`.

## Exact source and regression preservation

`source-preservation.json` records blob IDs, SHA-256 digests and the executable comparison results. The review compared all **4,011 tree entries** in the parent/head union: **10 paths changed; 4,001 entries are identical**. There are no unlisted modifications.

Five restored files are byte-identical to historical donor `a92658b1`: `derive.ts`, `eip712.ts`, `limits.ts`, `router.ts` and the policy package README. No historical revision was executed.

The preserved regions include the parent's full asset-coverage function, review snapshot types/copy logic, transaction comparison, and the complete sender/submission/journal section. Sixteen named protected files, including seller identity, asset UI/regressions, wallet, payment execution, duplicate journal and security translation catalogs, retain their exact parent blobs. All contracts, dependency manifests/lockfile, workflows, wallet library sources, other privacy code, CLI and relayer files remain unchanged.

The existing sender tests retain **83 identical assertion lines** and **42 identical test/suite title lines**. The two fixture repairs maintain canonical metadata and preserve the original final amount/token assertions. No assertion or coverage threshold was weakened. The new shape-contract test file contributes nine ordinary supported-copy/missing-field cases.

## Independent executable evidence

| Check | Actual outcome | Receipt / output |
| --- | --- | --- |
| Existing policy package suite | 103 passed; 7 skipped; 0 failed. 7 files passed, 1 skipped. | `package-tests.json`, `package-tests.log`, `package-results.json` |
| Existing web policy selection | 262 passed; 4 skipped; 0 failed. 18 files passed, 1 skipped. | `web-policy-tests.json`, `web-policy-tests.log`, `web-policy-results.json` |
| Policy package TypeScript | Exit 0 | `policy-typecheck.json`, `.log` |
| Web TypeScript | Exit 0 | `web-typecheck.json`, `.log` |
| All changed TypeScript/test files ESLint | Exit 0 | `changed-source-lint.json`, `.log` |
| Diff whitespace check | Exit 0 | `diff-check.json`, `.log` |
| Source/provenance/assertion preservation | Exit 0 | `source-preservation-check.json`, `.log`, `source-preservation.json` |

Exact working directories, argument arrays, start times, elapsed times, exit status and before/after source state are in each receipt. Test reporters preserve every executed and skipped test name. `test-summary.json` disambiguates test-file counts from Vitest's nested-suite counts.

The suite commands were:

```text
# cwd packages/policy-scheme
../../node_modules/.bin/vitest run --coverage=false --maxWorkers=2 --reporter=default --reporter=json --outputFile=/workspace/scratch/5ceb6203640a/policy-validation-review-evidence/package-results.json

# cwd apps/web
../../node_modules/.bin/vitest run src/features/policy --coverage=false --maxWorkers=2 --reporter=default --reporter=json --outputFile=/workspace/scratch/5ceb6203640a/policy-validation-review-evidence/web-policy-results.json

# cwd repository
npm run typecheck --workspace @ghostpay/policy-scheme
npm run typecheck --workspace @ghostpay/web
node_modules/.bin/eslint --config eslint.config.js packages/policy-scheme/src/derive.ts packages/policy-scheme/src/eip712.ts packages/policy-scheme/src/limits.ts packages/policy-scheme/src/router.ts packages/policy-scheme/src/validation-shape.test.ts apps/web/src/features/policy/pay.ts apps/web/src/features/policy/send.ts apps/web/src/features/policy/send.test.ts
git diff --check e1ab03ca7b07c225ae42d0c16fb79b97f0a1f95c dee9202c4f7d3cfb0233aca838b361c15b2a5345
python /workspace/scratch/5ceb6203640a/policy-validation-review-evidence/check-preservation.py
```

Coverage collection was deliberately left to the author's existing full qualification job so this reviewer would not write shared coverage outputs. The independent no-coverage runs are compatibility/regression evidence and are not counted as satisfying a coverage gate by themselves.

## Separately observed author evidence

`author-evidence-observations.json` records the author receipts and SHA-256 hashes of the logs actually read. It distinguishes observed author output from checks independently rerun here.

At the exact reviewed head, the author package coverage receipt reports exit 0 with **103 passed / 7 skipped** and **95.28% statements, 93.24% branches, 100% functions, 98.71% lines**. The original thresholds remain **95/90/95/95**, verified unchanged from the parent. The earlier **94 passed / 7 skipped** run failed its statement threshold at **94.24%**; that failure is retained in the observations rather than reclassified. Supported-format test coverage was then added.

The exact-head author focused policy results agree with the independent run. Author web build, secret scan and no-coverage pass receipts were also observed; the separate no-coverage selection reports **3 passed / 0 skipped**. These are not additional independent-review executions. The full web aggregate coverage completion receipt was not yet present at this review checkpoint.

Web tests consumed the author's already-built policy modules. `existing-compiled-artifacts.json` records those generated files. `library-build-provenance.json` verifies that the only changes since the successful author library build are the two test files; production library source is unchanged. No reviewer rebuild occurred.

## Unexecuted checks and remaining gates

- **Historical sensitive regression work — not_executed.** An earlier automated cybersecurity review stopped the broader reproduction task. This review deliberately excluded vulnerable-revision execution, exploit reconstruction, newly designed adversarial payloads and attack workflows. No such work was retried or classified as passing. Existing corrected-source suites and ordinary supported-format/missing-field checks only were executed.

- **Native contract integration — skipped.** Seven package and four web Anvil integration tests skipped under their unchanged availability checks. No native tooling was installed and no local chain was started. Exact skipped names are in test-summary.json. Static Solidity comparisons do not replace those executions.

- **Browser and full application qualification — not_executed_by_reviewer.** This reviewer did not run Chromium/Firefox/WebKit, mobile/Tor browser tests, the full aggregate web coverage suite, or hosted CI. The author full aggregate coverage receipt was not yet available when observed. These gates require their own final evidence.

- **Coverage, build and scanning — author_evidence_only.** Existing author receipts/logs were inspected and hashed separately. Exact-head package coverage passes original thresholds; the prior 94.24% statement-coverage failure is retained in the observations. The reviewer did not install dependencies, build, or rerun coverage/secret/dependency/release scans. Existing generated policy artifacts and their unchanged production-source build provenance were recorded.

- **Governance and integration — not_merge_authorization.** This is one independent AI-worker review, not a formal GitHub approval or external cryptographic audit. Parent asset integration, formal approvals, required exact-head CI, the existing integration owner and qualified merge process remain applicable. The reviewer changed no remote ref, PR, lease, source file, deployment or live transaction.

## Handoff

Retain the exact source SHA/tree, this review packet and donor provenance while the author finishes aggregate qualification. Collect the remaining permitted native/browser/security/hosted evidence, retaining explicit skip or restriction status for anything unexecuted. Parent asset integration and the current integration lock/approval process still determine whether and when the branch can merge. A new source tree requires renewed affected review and test qualification.

The checksum manifest covers the review, machine-readable results, commands, logs and source mapping. No exploitation procedure or new adversarial payload was created as part of this review.

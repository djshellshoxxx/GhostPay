import json, pathlib, subprocess, sys, time
from datetime import datetime, timezone
ROOT=pathlib.Path('/workspace/scratch/5ceb6203640a/GhostPay-policy-validation')
OUT=pathlib.Path(__file__).parent
EXPECTED='dee9202c4f7d3cfb0233aca838b361c15b2a5345'
TREE='ff04943bef13c739d6fb914d1172ed2e7e828dfd'
def git(*args):
 return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def snapshot():
 return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--porcelain=v1')}
name,cwd,*command=sys.argv[1:]
before=snapshot()
assert before['head']==EXPECTED and before['tree']==TREE and not before['status'], before
started=datetime.now(timezone.utc).isoformat()
t=time.monotonic()
with OUT.joinpath(name+'.log').open('w') as log:
 result=subprocess.run(command,cwd=ROOT/cwd,stdout=log,stderr=subprocess.STDOUT)
after=snapshot()
receipt={'check':name,'command':command,'cwd':str(ROOT/cwd),'started_at':started,'elapsed_seconds':round(time.monotonic()-t,3),'exit_code':result.returncode,'before':before,'after':after,'source_preserved':before==after,'log':name+'.log'}
OUT.joinpath(name+'.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
sys.exit(result.returncode if before==after else 99)

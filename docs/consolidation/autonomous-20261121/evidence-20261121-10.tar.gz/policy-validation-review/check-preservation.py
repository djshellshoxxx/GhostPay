import hashlib, json, pathlib, re, subprocess
ROOT=pathlib.Path('/workspace/scratch/5ceb6203640a/GhostPay-policy-validation')
OUT=pathlib.Path(__file__).parent
HEAD='dee9202c4f7d3cfb0233aca838b361c15b2a5345'
PARENT='e1ab03ca7b07c225ae42d0c16fb79b97f0a1f95c'
DONOR='a92658b1ef6b95ff0145b2e1933d0047d51289d5'
TREE='ff04943bef13c739d6fb914d1172ed2e7e828dfd'
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT)
def content(ref,path): return git('show',f'{ref}:{path}')
def sh(data): return hashlib.sha256(data).hexdigest()
def inventory(ref):
 result={}
 for line in git('ls-tree','-rz',ref).split(b'\0'):
  if line:
   meta,path=line.split(b'\t',1); mode,typ,oid=meta.decode().split(); result[path.decode()]={'mode':mode,'type':typ,'blob':oid}
 return result
base,head=inventory(PARENT),inventory(HEAD)
paths=sorted(set(base)|set(head))
changed=[p for p in paths if base.get(p)!=head.get(p)]
expected=['apps/web/src/features/policy/pay.ts','apps/web/src/features/policy/send.test.ts','apps/web/src/features/policy/send.ts','docs/ai/ACTIVE_WORK.md','packages/policy-scheme/README.md','packages/policy-scheme/src/derive.ts','packages/policy-scheme/src/eip712.ts','packages/policy-scheme/src/limits.ts','packages/policy-scheme/src/router.ts','packages/policy-scheme/src/validation-shape.test.ts']
assert changed==sorted(expected),changed
assert git('rev-parse','HEAD').decode().strip()==HEAD
assert git('rev-parse','HEAD^{tree}').decode().strip()==TREE
assert git('status','--porcelain=v1')==b''
files=[]
for path in changed:
 raw=content(HEAD,path)
 assert (ROOT/path).read_bytes()==raw,path
 files.append({'path':path,'parent_blob':base.get(path,{}).get('blob'),'reviewed_blob':head[path]['blob'],'sha256':sh(raw),'working_file_matches_frozen_head':True})
donor_paths=['packages/policy-scheme/src/derive.ts','packages/policy-scheme/src/eip712.ts','packages/policy-scheme/src/limits.ts','packages/policy-scheme/src/router.ts','packages/policy-scheme/README.md']
donor=[]
for path in donor_paths:
 a,b=content(DONOR,path),content(HEAD,path); assert a==b,path
 donor.append({'path':path,'donor_blob':git('rev-parse',f'{DONOR}:{path}').decode().strip(),'reviewed_blob':head[path]['blob'],'sha256':sh(b),'exact_match':True})
protected=['packages/policy-scheme/src/record.ts','packages/policy-scheme/src/index.ts','apps/web/src/features/policy/recordIdentity.ts','apps/web/src/features/policy/PolicyPay.tsx','apps/web/src/features/policy/PolicyCreate.tsx','apps/web/src/features/policy/PolicyView.tsx','apps/web/src/features/policy/PolicyAssetCoverage.test.tsx','apps/web/src/lib/wallet.ts','apps/web/src/lib/payExec.ts','apps/web/src/lib/duplicateAttemptJournal.ts','apps/web/src/i18n/securityKeys.ts','apps/web/src/i18n/securityKeys.test.ts','apps/web/locales/en.json','apps/web/locales/es.json','apps/web/locales/ar.json','apps/web/locales/ja.json']
protected_checks=[]
for path in protected:
 assert base[path]==head[path],path
 protected_checks.append({'path':path,'parent_blob':base[path]['blob'],'reviewed_blob':head[path]['blob'],'exact_match':True})
def region(data,start,end=None):
 data=data.decode(); text=data[data.index(start):]; return text if end is None else text[:text.index(end)]
regions=[]
for name,path,start,end in [('parent_asset_coverage_guard','apps/web/src/features/policy/pay.ts','export function assertPayeeTokenCoverage(', '\n}'),('review_snapshot_types_and_copy','apps/web/src/features/policy/send.ts','/** Exact transaction fields','const REVIEW_MISMATCH'),('transaction_review_equality','apps/web/src/features/policy/send.ts','const REVIEW_MISMATCH','/**\n * Synchronous final gate'),('submission_and_journal_logic','apps/web/src/features/policy/send.ts','export async function sendPolicyPayment(',None)]:
 a=region(content(PARENT,path),start,end); b=region(content(HEAD,path),start,end); assert a==b,name
 regions.append({'name':name,'path':path,'sha256':sh(b.encode()),'bytes':len(b.encode()),'exact_parent_match':True})
testpath='apps/web/src/features/policy/send.test.ts'
a,b=content(PARENT,testpath).decode().splitlines(),content(HEAD,testpath).decode().splitlines()
assertions=lambda lines:[s.strip() for s in lines if 'expect(' in s]
titles=lambda lines:[s.strip() for s in lines if s.lstrip().startswith(('it(', 'describe('))]
assert assertions(a)==assertions(b)
assert titles(a)==titles(b)
source=content(HEAD,'packages/policy-scheme/src/eip712.ts').decode(); contract=content(HEAD,'packages/contracts/src/PolicyAccount.sol').decode()
type_strings=re.findall(r"(?:Withdraw|CancelWithdraw|ProposeDestination|CancelDestination): '([^']+)'",source[:source.index('/** `PolicyAccount.WITHDRAW_TYPEHASH`. */')])
assert len(type_strings)==4
assert all('"'+value+'"' in contract for value in type_strings)
report={'head':HEAD,'tree':TREE,'parent':PARENT,'donor':DONOR,'status':'clean','changed_files':files,'total_compared_tree_entries':len(paths),'exact_unchanged_parent_entries':len(paths)-len(changed),'all_other_tree_entries_unchanged':True,'donor_exact_matches':donor,'protected_files':protected_checks,'protected_regions':regions,'send_test_preservation':{'assertion_lines':len(assertions(a)),'test_and_suite_title_lines':len(titles(a)),'assertion_lines_exact_parent_match':True,'title_lines_exact_parent_match':True},'contract_type_strings':{'strings':type_strings,'exact_matches':4},'protected_scopes_unchanged':['packages/contracts','package.json','package-lock.json','.github/workflows','apps/web/src/lib','apps/web/src/features/privacy','apps/web/locales','packages/cli','apps/relayer'],'verification_scope':'Static source comparisons only; historical revisions were not executed.'}
for scope in report['protected_scopes_unchanged']:
 assert not any(p==scope or p.startswith(scope+'/') for p in changed),scope
OUT.joinpath('source-preservation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'head':HEAD,'tree':TREE,'changed_files':len(changed),'exact_parent_entries':report['exact_unchanged_parent_entries'],'donor_exact_matches':len(donor),'protected_files':len(protected),'protected_regions':len(regions),'send_assertion_lines':len(assertions(a)),'send_title_lines':len(titles(a)),'contract_type_string_matches':4,'status':'passed'}))

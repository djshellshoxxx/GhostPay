import datetime,hashlib,json,os,shlex,subprocess,sys,time
from pathlib import Path
out=Path(__file__).resolve().parent
label=sys.argv[1]
cmd=sys.argv[2:]
def git(*args):
 return subprocess.check_output(['git',*args],text=True).strip()
def state():
 return {'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'status':git('status','--short')}
record={'command':shlex.join(cmd),'cwd':os.getcwd(),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before':state()}
start=time.monotonic()
with (out/f'{label}.log').open('w') as log:
 result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
record.update({'returncode':result.returncode,'duration_seconds':round(time.monotonic()-start,3),'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'after':state(),'log_sha256':hashlib.sha256((out/f'{label}.log').read_bytes()).hexdigest()})
(out/f'{label}.run.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
sys.exit(result.returncode)

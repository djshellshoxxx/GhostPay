import sys,json,subprocess,time,datetime,hashlib,os
from pathlib import Path
root=Path(__file__).parent
label,cwd,*command=sys.argv[1:]
def git(*args):
 return subprocess.check_output(['git',*args],cwd=cwd,text=True).strip()
source_before=git('rev-parse','HEAD');tree_before=git('rev-parse','HEAD^{tree}');status_before=git('status','--porcelain','--untracked-files=no')
start=datetime.datetime.now(datetime.timezone.utc).isoformat();clock=time.monotonic()
log=root/(label+'.log')
with log.open('w') as f:r=subprocess.run(command,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,'NODE_OPTIONS':'--max-old-space-size=2048'})
receipt={'schema':'ghostpay-independent-review-execution/1','reviewer':'remaining_semantic_review','label':label,'cwd':cwd,'command':command,'environment':{'NODE_OPTIONS':'--max-old-space-size=2048'},'started_at':start,'duration_seconds':round(time.monotonic()-clock,3),'exit_code':r.returncode,'source_before':source_before,'source_after':git('rev-parse','HEAD'),'tree_before':tree_before,'tree_after':git('rev-parse','HEAD^{tree}'),'tracked_status_before':status_before,'tracked_status_after':git('status','--porcelain','--untracked-files=no'),'log':log.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
(root/(label+'.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2));print(log.read_text()[-2500:]);sys.exit(r.returncode)

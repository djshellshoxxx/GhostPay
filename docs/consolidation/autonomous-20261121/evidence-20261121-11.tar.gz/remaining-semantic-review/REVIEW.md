# Bounded branch semantic review — 2026-11-21 UTC

**Decision:** no blocking source finding in the corrected narrow targets reviewed. The 26 records can have their source-semantic pending flag cleared, provided the authoritative overlay still has the exact same branch name and SHA. Existing classifications and integration gates remain.

## Scope and count

- Input: 438 branch snapshot captured 2026-11-21T06:33:38.109Z against main `eb59d93cffed7848c4aac37d0e9650b87239c6da`.
- Input pending 136; reviewed 26 records representing 25 distinct heads and 20 open PRs. Applying only this exact-pin overlay yields 110 remaining inherited source-semantic obligations in that historical snapshot. Later live additions require their own accounting.
- This review examined complete narrow changed-path inventories, changed source/test behavior, corrected successors and provenance. It does not close broad inherited feature stacks by ancestry or blob equality.
- Application source, remote refs, PRs, leases, installations, deployments, releases and funds were unchanged. Only this evidence directory was written; existing tests may write ignored caches/coverage. All executed source trees remained clean.

## Executed checks

| Check | Source | Passed | Failed | Skipped | Scope |
|---|---|---:|---:|---:|---|
| web-bounded | `783231a46840` | 36 | 0 | 0 | focused original tests |
| vault-rekey | `783231a46840` | 1 | 0 | 0 | focused original tests |
| invoice-json | `783231a46840` | 24 | 0 | 0 | focused original tests |
| pages-artifact | `783231a46840` | 17 | 0 | 0 | focused original tests |
| policy-chain | `dee9202c4f7d` | 28 | 0 | 0 | focused original tests |
| tron-chain | `5de4629aacfb` | 65 | 0 | 0 | focused original tests |
| tron-lock | `5de4629aacfb` | 1 | 0 | 0 | focused original tests |
| hygiene-package | `783231a46840` | 161 | 0 | 0 | original package coverage |

**333 passing executions, zero failures, zero skips.** These groups are nonoverlapping within this review, but overlap earlier author/coordinator runs. Do not add them as new unique tests to prior totals. Hygiene coverage remains 99.52% statements/99.12% branches/100% functions/100% lines with the original package thresholds. Other reviewer selections are noncoverage runs and do not replace aggregate coverage.

The first TRON command requested an absent `chain.test.ts` name while matching four real files, producing 65 passes. The actual fifth file, `TronView.lock.test.tsx`, was then run separately and passed 1/1. Nothing unexecuted is counted. Exact command arrays, source/tree/status before and after, timings and log digests are in eight individual execution receipts and REVIEW.json.

## Attribution and unchanged-source checks

The earlier independent #338 and #360 four-case receipts were read and their raw log SHA-256 values verified. Copies are included as `attributed-*` evidence; those 8 executions are not part of this reviewer’s 333. #370’s later type guard is preserved as the corrected payment-URI target, while both #338 and #360/#370 remain absent from pinned main and recovery.

Embedded checkout uses the previously inspected hosted qualification for #351. The exact child and actual #337 parent merge trees both equal `9ce013174e2417756abd8cc95407010414a66814`, which matches the tested synthetic merge tree. The historical hosted web result was 2817 passed/1 skipped plus 3 noncoverage; full E2E 82/1 skipped; lean 70/3 skipped. These are attributed prior observations, not fresh hosted or browser execution by this reviewer, and do not qualify a later main composition.

The current recovery counterpart of #314 preserves its original ownership regression blob under the renamed `SellerKeys.ownership.test.tsx`, preserves #319’s distinct operation file, and retains both browser journeys exactly. #317’s tag function differs only by adding reveal revocation on Lock, with the original three scope tests exact. Policy catalog inspection confirms 2254 existing message values unchanged in each of four catalogs, plus seven separately reviewed additions; no native linguistic review is claimed.

## Per-branch disposition

| PR / alias | Exact source | Class retained | Corrected target |
|---|---|---|---|
| #276 | `f39a9dd36c09f8b02d937c5f3d19676d334976d6` | Superseded | `783231a46840` |
| #328 | `81598d93dd82cc440526c866d42b55be0657895b` | Blocked by dependencies | `783231a46840` |
| #265 | `c591b54078febcf24cba01b29bc173b2fac1f9cb` | Superseded | `783231a46840` |
| #332 | `71632fa389ae93824b2f42d265278a9bd0f6de59` | Superseded | `783231a46840` |
| #338 | `692cac58b1c345137264936e60bee7b1e2eed8b2` | Blocked by dependencies | `692cac58b1c3` |
| #350 | `89b3572f7e60cb6f5e5a0d7830632d1bb5f04dd8` | Blocked by dependencies | `783231a46840` |
| #360 | `2844ec6c22fe179987585679a934e10033ff3384` | Blocked by dependencies | `3d57d9881033` |
| #314 | `e6ed3ee64a786c33b1af06b5fc7a51d742eb6544` | Superseded | `783231a46840` |
| #317 | `caa4bd7e3465b5d6655eb3dbe86e5f240eb21462` | Blocked by dependencies | `783231a46840` |
| historical alias | `caa4bd7e3465b5d6655eb3dbe86e5f240eb21462` | Blocked by dependencies | `783231a46840` |
| #319 | `627ab977c9cc4e5ebc682eda822cfe792cd76fc1` | Blocked by dependencies | `783231a46840` |
| #277 | `8cbae85c95fa707210704ee72bb4416b36e5a4d7` | Blocked by dependencies | `783231a46840` |
| historical alias | `b9911c7228e95a3f8a6666d10aae50bcda08bd7d` | Blocked by dependencies | `783231a46840` |
| #339 | `d03600ca87c7156d4acd1ff78bef6e92c20d9ea4` | Superseded | `783231a46840` |
| #337 | `08d2111a5fd3b71a148fc8648481200e680faf53` | Blocked by dependencies | `08d2111a5fd3` |
| historical alias | `0750012546aeb4336b4340fe16751f8d83804acd` | Blocked by dependencies | `08d2111a5fd3` |
| #357 | `e871eccc1238b7145cd1d0a667afb393c373cf83` | Unique but requiring correction | `dee9202c4f7d` |
| #340 | `b86a3e6affe8b71c6f13d16783accad446271ba4` | Blocked by dependencies | `5de4629aacfb` |
| historical alias | `06fd87c3e90000118ffa94048529db36f0a67d41` | Blocked by dependencies | `5de4629aacfb` |
| #345 | `ccc8c3521511e2a2b9b66ef11f12723d87ce5f44` | Blocked by dependencies | `dee9202c4f7d` |
| historical alias | `23f55bfea1068a5791b8e8e29409e4a13d0b28a3` | Blocked by dependencies | `dee9202c4f7d` |
| #369 | `500ece7a7c99b566ecaad5a8dd0d54fd0022395a` | Blocked by dependencies | `5de4629aacfb` |
| #347 | `95e60ce4948b7430865dafbd1ad01434310a75f7` | Blocked by dependencies | `783231a46840` |
| historical alias | `0e19ccc7d52b0d160fb756089e6a843a1d2831d7` | Blocked by dependencies | `783231a46840` |
| #362 | `67542c09ba180eec95004fb9b7a6d52d1a8dd809` | Blocked by dependencies | `dee9202c4f7d` |
| #368 | `18d0442a156106abe2309f8a6e82358aab37961a` | Blocked by dependencies | `dee9202c4f7d` |

Each full record in REVIEW.json includes the branch name, source tree, merge base(s), full path mappings, exact source/candidate/main blobs, bounded behavior assessment and test-evidence associations. A missing main blob or a successor-only correction is explicitly represented.

## Findings and integration consequences

- Vault rekey retains lock revocation while allowing the durable password change to finish; a fresh explicit unlock is required.
- Backup cancellation retires only its controller and busy state; durable save/delete operations retain independent symbol ownership.
- Receipt archive generation prevents a delayed write for an earlier receipt from changing the new receipt’s archived status.
- Canonical array and Pages artifact successors retain earlier coverage while adding stricter structure/identity checks.
- Tag lists remain chain/session scoped; duplicate router callbacks do not imply distinct payments.
- Hygiene binds provider rows to the requested token/range/event identity and keeps testnet destination history separate without widening experimental RPC helpers.
- Policy review revisions, seller record identity, recovery filenames and security-sensitive message classification survive in the corrected policy chain.
- TRON selected-genesis validation retains current-main strict incomplete-range checks. Endpoint-reported identity remains provider evidence, not cryptographic authentication.
- The popup correction retains opener/referrer isolation while removing the incorrect inference from a null window handle.

## Unqualified work and next owners

All original classifications remain, including Superseded and Blocked by dependencies. Source review completion does not mean direct-main readiness. Keep the already-composed #351 and #359 fixes in their #337 and #345 parents. #369 remains the reconciliation child of #340, which already contains #342. Preserve the #368→#362→#357 policy chain and any newer children using the coordinator’s live dependency ordering. The published owned children may have further qualification requirements.

Required current-target CI, formal approvals, native/browser/mobile/Tor and release checks remain coordinator-owned. The unreconciled generation 11lease is unchanged. This AI-worker review is not a formal GitHub approval or external cryptographic/protocol audit. Historical policy decoder/signing/Merkle regression gaps are outside these UI/recovery records and remain unqualified.

No broad donor is declared fully recovered by this packet. Next bounded candidates include receipt print scope #316 and Sweep consent/quote families #231/#252/#272, followed by broader retained feature stacks. Root should update only its authoritative ledger, verify live heads, and preserve the remaining 110historical obligations plus new live branches.

## Evidence delivery

REVIEW.json is the machine-readable overlay; this file is explanatory. MANIFEST.json covers every delivered file other than itself. Raw logs are included even though repository ignore rules may hide `*.log`; force-add or publish those manifest entries when capturing this packet.

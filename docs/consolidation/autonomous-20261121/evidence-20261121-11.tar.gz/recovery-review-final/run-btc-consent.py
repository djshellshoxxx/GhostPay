import pathlib, subprocess, hashlib, json, time, datetime, os
out=pathlib.Path('/workspace/scratch/5ceb6203640a/recovery-final-review-evidence'); repo=pathlib.Path('/workspace/scratch/5ceb6203640a/recovery-composition-fix')
donor='981cc2f4395d2d76c499a5cd46387daaaa3a6b1f'; path='apps/web/src/features/btc/BtcView.spentConsent.test.tsx'
raw=subprocess.check_output(['git','show',f'{donor}:{path}'],cwd=repo); (out/'BtcView.spentConsent.donor.tsx').write_bytes(raw)
s=raw.decode(); changes=[]
for old,new in [("'../../test/render'",repr(str(repo/'apps/web/src/test/render'))),("'./BtcView'",repr(str(repo/'apps/web/src/features/btc/BtcView'))),("'./fixtures.testutil'",repr(str(repo/'apps/web/src/features/btc/fixtures.testutil'))),("'./esplora'",repr(str(repo/'apps/web/src/features/btc/esplora'))),("'./scanWorkerClient'",repr(str(repo/'apps/web/src/features/btc/scanWorkerClient'))),("'./scanWorker.testutil'",repr(str(repo/'apps/web/src/features/btc/scanWorker.testutil'))),("'../../App'",repr(str(repo/'apps/web/src/App')))]:
 assert s.count(old)==1,(old,s.count(old));s=s.replace(old,new);changes.append({'old':old,'new':new})
(out/'src/BtcView.spentConsent.review.test.tsx').write_text(s)
cmd=[str(repo/'node_modules/.bin/vitest'),'run','--config',str(repo/'apps/web/vite.config.ts'),'--root',str(out),'src/BtcView.spentConsent.review.test.tsx','--maxWorkers=1','--no-file-parallelism','--no-cache']
start=datetime.datetime.now(datetime.timezone.utc).isoformat(); before=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip();t=time.monotonic()
env=os.environ.copy();env['NODE_OPTIONS']='--max-old-space-size=1024'
with (out/'btc-consent-baseline.log').open('w') as f:r=subprocess.run(cmd,cwd=out,env=env,stdout=f,stderr=subprocess.STDOUT)
log=(out/'btc-consent-baseline.log').read_bytes();after=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
result=dict(donor=donor,donor_path=path,donor_sha256=hashlib.sha256(raw).hexdigest(),adaptations=changes,command=cmd,environment={'NODE_OPTIONS':env['NODE_OPTIONS']},cwd=str(out),source_before=before,source_after=after,started_at=start,elapsed_seconds=round(time.monotonic()-t,3),exit_code=r.returncode,log_sha256=hashlib.sha256(log).hexdigest())
(out/'btc-consent-baseline-result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2));print(log.decode()[-7500:])

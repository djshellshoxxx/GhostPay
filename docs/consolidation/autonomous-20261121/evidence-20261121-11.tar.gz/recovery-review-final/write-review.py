import pathlib,json,subprocess,datetime,hashlib
out=pathlib.Path('/workspace/scratch/5ceb6203640a/recovery-final-review-evidence');repo=pathlib.Path('/workspace/scratch/5ceb6203640a/recovery-composition-fix')
inv=json.loads((out/'initial-path-inventory.json').read_text());head='b85e8160fbc1bc4b69b8652595a8adfd2defd927'
full=set('''apps/web/scripts/apply-csp.mjs
apps/web/scripts/csp.mjs
apps/web/src/components/Disclosure.tsx
apps/web/src/components/InvoiceSignerVerification.tsx
apps/web/src/components/WalletAttempts.tsx
apps/web/src/features/btc/scan.ts
apps/web/src/features/btc/scanWorkerClient.ts
apps/web/src/features/btc/scanWorkerMessages.ts
apps/web/src/features/btc/scanWorkerProtocol.ts
apps/web/src/features/btc/scanWorkerSource.ts
apps/web/src/features/policy/PolicyView.tsx
apps/web/src/features/policy/pay.ts
apps/web/src/features/policy/scan2.ts
apps/web/src/lib/frameGuard.ts
apps/web/src/lib/invoiceSignerPins.ts
apps/web/src/lib/invoiceVerification.ts
apps/web/src/lib/manifest.ts
apps/web/src/lib/stealthExport.ts
apps/web/src/main.tsx
apps/web/src/styles/walletDisclosure.css
apps/web/src/views/Sweep.tsx
deploy/nginx/render-security-headers.mjs
packages/btc-silent-payments/src/scan/state.ts
scripts/pages/lean-exclusions.mjs
scripts/pages/smoke-url.mjs
scripts/pages/smoke-walk.mjs
test-vectors/generate-stealth-export.mjs'''.splitlines())
notes='''apps/web/scripts/apply-csp.mjs|Enforcing direct-head CSP placement, duplicate/ambiguous attribute refusal, original source ranges, headers scope and exact origin policy.
apps/web/scripts/csp.mjs|Bare HTTPS/WSS origin validation, no credentials or policy syntax, canonicalization and exact connect-src policy.
apps/web/scripts/scan-bundle.mjs|All HTML entries scanned, configured CSP token masking only in validated content, exact declared own-origin exemption, shared lean exclusions, legacy manifest markers.
apps/web/scripts/test-reconciliation-idb.mjs|Local browser selection and exact stored-height canonical hash callbacks; no weakened reorg assertion.
apps/web/scripts/test-seller-vault-idb.mjs|Private optimizer cache, separate fresh recovery contexts, production KDF envelope, explicit re-encryption, occupied-store refusal and no egress assertions. Script not executed by this reviewer.
apps/web/scripts/validate-deployments.mjs|Bundled manifest signatures and fixed public fixture-key rejection; finite denylist is not proof arbitrary private keys are secret.
apps/web/src/components/Disclosure.tsx|Manifest service and chain scoping, cancellation, fixed errors and fee/observer/limit disclosures.
apps/web/src/components/InvoiceSignerVerification.tsx|Operation generations, identity/currentness guards, explicit pin review and removal, invalid selected-pin state.
apps/web/src/components/MerchantProfilePanel.tsx|Explicit endpoint authorization, signal and network revision invalidation, completion expiry guards; issuer parent key remounts changed profile/template.
apps/web/src/components/MerchantTemplateIssuer.tsx|Minimal metadata default, session generation, owned temporary preview and cancellation.
apps/web/src/components/WalletAttempts.tsx|Account plus chain filtering, no wallet means no hashes, scoped private history and explicit clear confirmation.
apps/web/src/features/btc/BtcView.tsx|Network-operation scope, checked-tip/spend coverage sweep gates, stale async result wiping, unknown broadcasts; finding BTC-OPTIONAL-CONSENT-RESET. Mandatory-light UX assessed separately.
apps/web/src/features/btc/esplora.ts|Coinbase status derived from serialized inputs, Merkle-bound spends, bounded transport errors, signal propagation for broadcast, no raw response text in errors.
apps/web/src/features/btc/headers.ts|Canonical discovery and coverage anchors; new or shorter chain tip invalidates local spentness, reorg clears stale spend count.
apps/web/src/features/btc/oracleSource.ts|Optional complete spends capability preserved only from local source, bound to agreed block hash and height.
apps/web/src/features/btc/scan.ts|Bounded recovery, continuous local coverage, mandatory light permission, proof before authority, provider status not persisted as local proof, all unreturned tweak buffers wiped.
apps/web/src/features/btc/scanWorkerClient.ts|Explicit transport, per-operation outpoint/proof grants, source bridge lifecycle, checkpoints, malformed result refusal and secret-copy disposal.
apps/web/src/features/btc/scanWorkerMessages.ts|Bounded messages/state/path allowlist; height/output/page syntax and separate permission flags.
apps/web/src/features/btc/scanWorkerProtocol.ts|One operation per worker, independent permission validation, bounded typed bridge, pinned genesis/header validation, checkpoint acknowledgements and disposal.
apps/web/src/features/btc/scanWorkerSource.ts|Selected fixed prefix, GET-only paths, separate outpoint/proof capabilities, response caps, timeout/abort handling and no redirects/cookies.
apps/web/src/features/btc/verification.ts|Disclosure describes incomplete coverage, mempool limitations and provider outpoint disclosure accurately.
apps/web/src/features/policy/PolicyCreate.tsx|Neutral export filename removes policy hash from filesystem metadata; payload semantics unchanged.
apps/web/src/features/policy/PolicyPay.tsx|Deployment guard before explicitly scoped policy RPC; wallet attempts scoped to current wallet.
apps/web/src/features/policy/PolicyReceive.tsx|Policy action signal and per-read currentness guards block resumed scans after session or view invalidation.
apps/web/src/features/policy/PolicyView.tsx|Deployment generation, network revision, operation signal, wallet privacy/disclosure, remounted scoped children and currentness guards.
apps/web/src/features/policy/chain.ts|Fixed contract-response catalog error avoids rendering contract/function details; existing anchored deployment checks retained.
apps/web/src/features/policy/pay.ts|Constructed payment self-check includes method, account, owner, policy hash, ephemeral key and view-tag metadata, exact router and approval fields.
apps/web/src/features/policy/scan2.ts|Every injected client read guarded before/after awaiting; returned data gated, canonical identity fields retained and reorg merge behavior.
apps/web/src/features/policy/send.ts|Last synchronous reviewed transaction checks now bind derived ephemeral key and metadata, not only account/owner/policy hash.
apps/web/src/features/registry/RegistryView.tsx|Network/controller revisions, disclosure before connect, session/current authority and privacy revocation, stale lookup result gates and scoped attempts.
apps/web/src/lib/errors.ts|Four fixed signer verification catalog classifications; no raw error payload.
apps/web/src/lib/frameGuard.ts|Fail-closed frame detection and scoped seller/settings restriction; intended home/pay/about allowance is not represented as universal frame prevention.
apps/web/src/lib/invoiceSignerPins.ts|Bounded exact-key storage, valid compressed points, exclusive locks, fresh snapshot and expected-key comparison, currentness guard, durable readback and sync.
apps/web/src/lib/invoiceVerification.ts|Valid pinned/unpinned, missing and unavailable verification remain distinct; invalid selected pin fails closed.
apps/web/src/lib/manifest.ts|Compiled bundled source only, configured release keys, declared-origin binding, chain verification failure disables flow; no unsigned development acceptance path.
apps/web/src/lib/stealthExport.ts|Small localized portable-codec wrapper with explicit message type and no alternate key processing.
apps/web/src/main.tsx|Fixed error class logging with guarded instanceof; avoids error-controlled name, message and stack.
apps/web/src/styles/walletDisclosure.css|Dialog wrapping and minimum controls, print suppression, no remote assets.
apps/web/src/views/Home.tsx|Release hash fetch bound to same resolved same-origin entry URL and context disposal.
apps/web/src/views/Settings.tsx|Finding SETTINGS-PARTIAL-DRAFTS: saved-settings effect erases unrelated unsaved sections after selective import; other inspected boundaries cover RPC ownership, profile revision, scan validation and retention.
apps/web/src/views/Sweep.tsx|Full source: native/relayer fee review, stale signing scope, vault/session guards, handed-off journal before request, unknown outcomes, bounded same-nonce replacement and status reconciliation.
deploy/nginx/render-security-headers.mjs|Validated origin lists and both output policies before writes, separate destination, no service reload/deployment.
packages/btc-silent-payments/src/scan/headersync.ts|Header wrapper preserves optional spends capability and validates hash after await; downstream scanner validates returned height.
packages/btc-silent-payments/src/scan/scanner.ts|Entire spend list validates before callbacks, contradictory duplicate spend identities refused, first spend reported once across scan.
packages/btc-silent-payments/src/scan/state.ts|Strict state parse, distinct identities, evidence hashes, continuous coverage, bounded rollback, pending recovery and block-atomic progress callbacks.
packages/i18n/src/format.ts|Unicode bidi controls represented by escapes with unchanged regex semantics.
packages/invoice-schema/src/errors.ts|Distinct typed errors for required signature and unavailable verification.
packages/policy-scheme/src/derive.ts|Secret copy allocated only after public argument validation and wiped in existing finally.
packages/policy-scheme/src/eip712.ts|Leaf proof binds token/limit/window, signing reconstructs validated fixed domain/type/message digest once, secret copy wiped and recovered signer checked.
packages/policy-scheme/src/limits.ts|Restored Merkle tree entry leaf recomputed from its fields before proof returned.
packages/policy-scheme/src/router.ts|Canonical ABI re-encoding, valid ephemeral key, metadata kind/token/net/minNet, derived account binding; does not overclaim payee authority without caller comparison.
packages/pool-circuits/scripts/install-circom.sh|HTTPS-only initial and redirected download, existing pinned checksum retained.
packages/scan-source/src/index.ts|Exports new padded API/types; no hidden behavior introduced by index.
packages/ux-core/src/errors.ts|Fixed diagnostic catalog additions and supported-format wording, no raw exception details.
packages/ux-vault/src/keystore-portable.ts|Owned passphrase byte copy wiped when scrypt throws and raw derived bytes wiped; no claim immutable strings can be erased.
packages/ux-vault/src/portable-errors.ts|Fixed typed export error message key additions.
packages/ux-vault/src/portable.ts|Portable codec exports align with wrapper; no Node-only runtime import.
scripts/devnet/e2e.mjs|Synthetic relayer feeTo follows manifest account instead of hardcoded account index; no runtime transaction executed in review.
scripts/integration/run-in-runner.sh|npx --no refuses implicit package downloads when invoking existing Vitest.
scripts/pages/lean-exclusions.mjs|Shared conservative exclusions for bundle/verifier, unknown rendered length remains significant, embedHost restricted to completion export.
scripts/pages/smoke-url.mjs|Same origin plus project subpath boundaries, data/blob nonnetwork handling, declared deployment origin consistency.
scripts/pages/smoke-walk.mjs|All lean navigation and synthetic signed invoice fixture only; no payment-control clicks.
scripts/pages/smoke.mjs|Preflight origin check before live requests, fixed render-error marker and all-view egress recording; no live site execution by reviewer.
scripts/pages/verify-pages-site.mjs|Shared lean module policy adopted with existing symlink, manifest and artifact checks retained.
test-vectors/generate-stealth-export.mjs|Independent primitives generate synthetic documented public/keypair/master formats with domain-bound AAD and refusal vectors; production KDF not weakened by fixed test parameters. Generator not executed in repository.
'''
by={line.split('|',1)[0]:line.split('|',1)[1] for line in notes.splitlines() if line}
assert len(by)==len(inv['paths'])==65
rows=[]
for p in inv['paths']:
 path=p['path'];actual=subprocess.check_output(['git','rev-parse',f'{head}:{path}'],cwd=repo,text=True).strip();assert actual==p['blob'],path
 rows.append({**p,'reviewed_head':head,'scope':'full-file' if path in full else 'changed-section-and-relevant-context','note':by[path]})
extra=[('packages/ux-vault/src/vault.ts','changed-section-and-relevant-context','Rekey durable completion may publish fresh context only while original captured context remains current; lock during await cannot resurrect session.'),('packages/ux-vault/src/vault.rekey-lock.test.ts','full-file','Synthetic gated write proves old session remains locked and new password requires fresh explicit unlock; previous worker execution separately attributed.'),('packages/hygiene/src/verify.ts','changed-section-and-relevant-context','Emitter, height range, block hash and index bind event evidence; identical event deduped and contradictory valid duplicate discarded. Provider evidence does not establish chain finality.'),('packages/hygiene/src/ledger.ts','changed-section-and-relevant-context','Only local destination ledger follows enabled browser EVM testnet table and Anvil; narrower PoC RPC guard unchanged.'),('packages/hygiene/src/verify.evidence-boundary.test.ts','full-file','Seven synthetic accepted/denied event evidence checks; previous residual worker execution separately attributed.'),('packages/hygiene/src/ledger.browser-chains.test.ts','full-file','Seven testnets, invalid/mainnet rejection, chain-separated history and unchanged narrow RPC helper policy.'),('apps/web/src/lib/networkAuthorization.ts','context-only','Release resource matching and operation cancellation helpers inspected; prior reviewer owns complete module review.'),('apps/web/src/AppShell.tsx','context-only','Privacy scope and Sweep mount context inspected; not a complete AppShell audit.')]
extras=[]
for path,scope,note in extra:
 extras.append({'path':path,'reviewed_head':head,'blob':subprocess.check_output(['git','rev-parse',f'{head}:{path}'],cwd=repo,text=True).strip(),'scope':scope,'note':note})
report={'reviewer':'/root/recovery_remaining_review','created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'review_base':inv['base'],'reviewed_head':head,'reviewed_tree':subprocess.check_output(['git','rev-parse',f'{head}^{{tree}}'],cwd=repo,text=True).strip(),'status':'findings-await-author-repair-and-independent-retest','primary_scope_counts':{'total':65,'full_file':len(full),'changed_section_and_relevant_context':65-len(full),'unreviewed_assigned_paths':0},'paths':rows,'additional_scopes':extras,'findings':[{'id':'SETTINGS-PARTIAL-DRAFTS','status':'confirmed-open','scope':'application-settings','evidence':'partial-import-baseline-result.json','observed':'Both exact donor #356 selective-import regressions fail on b85: preferences-only erases RPC draft; RPC-only replaces unsaved theme.','requested_correction':'Reconcile only specifically changed saved fields while preserving explicit selected-section import application and unconditional stale RPC-test revocation.'},{'id':'BTC-OPTIONAL-CONSENT-RESET','status':'confirmed-open-pending-integration-disposition','scope':'full-profile-bitcoin-only','evidence':'btc-consent-baseline-result.json','observed':'Exact donor #244 test confirms optional provider checkbox stays true after provider URL edit.','requested_correction':'Clear optional provider consent on source edits; preserve mandatory-light explicit disclosure and independent guards.'}],'compatibility_dispositions':[{'source_pr':244,'source_head':'981cc2f4395d2d76c499a5cd46387daaaa3a6b1f','behavior':'Additional separate light-mode consent checkbox','disposition':'Old assertion conflicts with current explicitly disclosed light mode contract; not adopted automatically. Candidate selects no oracle and light=false by default, explains per-outpoint disclosure before Scan, and refuses missing permission in main client, worker and scan engine. Exact donor test failure is a compatibility difference, not evidence of hidden light-mode requests.','sources':['apps/web/src/features/btc/BtcView.tsx','apps/web/locales/en.json','docs/specs/12-bip352-light-client-scanning.md','docs/user/bitcoin-spent-status.md']}],'independent_runs':['partial-import-baseline-result.json','btc-consent-baseline-result.json','boundary-test-results.json'],'limits':['No source/ref/remote edits, deployment, release or real-funds transaction by reviewer.','No formal GitHub approval or whole-application security certification.','No native browser, Tor, complete application coverage, dependency/secret scan or contract tests executed by this reviewer; author/root evidence remains separate.','Full-file means source read in full, not proof all possible runtime paths are correct. Changed-section scope does not cover every unchanged line.','Prior independent 451 and216 tests plus residual20 tests are not counted as this reviewer executions.']}
(out/'REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'path':str(out/'REVIEW.json'),'counts':report['primary_scope_counts'],'extras':len(extras)}))

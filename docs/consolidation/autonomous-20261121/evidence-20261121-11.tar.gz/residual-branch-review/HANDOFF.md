# Residual branch source review — 2026-11-21

Pinned main: `eb59d93cffed7848c4aac37d0e9650b87239c6da`. Final source comparison: `89c9b8035afa29fc291944a00a23667c12bd2ecc` (tree `eaeee1879b43474cccbb13e334224eeb88d468b3`). Focused independent test source: `bd024ca06cd3f55afcf0a4ba543f963eb6b0499b`.

This packet assigns a supported disposition to all **59** previously unresolved heads. It does **not** close the earlier 142 semantic-review obligations, qualify whole inherited stacks, or claim a main merge. Broad partial branches and exact known-defect inheritance remain explicit.

## Concrete outcomes

- Found six missing hygiene source/test blobs from `0e19ccc7d52b0d160fb756089e6a843a1d2831d7`; the implementation owner adopted those exact files at bd024ca0. No whole-donor recovery is claimed.
- Independently reviewed those six blobs plus the two #328 vault blobs. **19 hygiene tests + 1 vault test = 20 passed, 0 failed, 0 skipped**, at bd024ca0. Commands/log hashes are in independent-runs.json. These focused runs do not replace coverage or browser gates.
- Found missing policy withdrawal-asset coverage from #211. Exact helper/UI/test blobs are in policy-asset-coverage-gap.json. Root accepted the next bounded recovery on the current policy identity/review-authority chains. This remains a source-level finding until execution.
- Preserved #244-specific Bitcoin consent coverage. A separate reviewer reproduced endpoint-edit consent retention on b85; the owner recovered the narrow reset/case at 89c9b803. Old separate-light-checkbox expectations are deliberate design drift.
- Proved bulk-evidence defect-region inheritance on **16** residual heads, including **11** entire-file matches. Other inherited features remain review obligations.
- Verified original #314 regression retained under its ownership-test filename and exact retention of #210 external dependency graph (752 entries).

## Classification counts

| Category | Heads |
| --- | ---: |
| Blocked by dependencies | 8 |
| Documentation or evidence only | 1 |
| Experimental or deferred | 1 |
| Partially implemented | 12 |
| Superseded | 17 |
| Unique but requiring correction | 20 |

## Every head

| Index / PR | Branch | Exact head | Disposition |
| --- | --- | --- | --- |
| 0 / #358 | `audit/ghostpay-complete-claim-reconciliation-20261120` | `c9e53c2c5908cbb64c104d096ce84773cf804ccc` | Documentation or evidence only |
| 1 / #337 | `automation/ghostpay-20261120-embed-popup-noopener-r1` | `08d2111a5fd3b71a148fc8648481200e680faf53` | Blocked by dependencies |
| 2 / #265 | `automation/20261119T083600Z/bug/json-canonical-array` | `c591b54078febcf24cba01b29bc173b2fac1f9cb` | Superseded |
| 3 / #314 | `automation/20261120T0835Z/bug/sellerkeys-operation-supersession` | `e6ed3ee64a786c33b1af06b5fc7a51d742eb6544` | Superseded |
| 4 / #332 | `automation/20261120T1840Z/bug/receipt-archive-identity` | `71632fa389ae93824b2f42d265278a9bd0f6de59` | Superseded |
| 5 / #338 | `automation/20261120T2036Z/bug/btc-preview-network` | `692cac58b1c345137264936e60bee7b1e2eed8b2` | Blocked by dependencies |
| 6 / #345 | `automation/20261120/bug/policy-review-revocation-r1` | `ccc8c3521511e2a2b9b66ef11f12723d87ce5f44` | Blocked by dependencies |
| 7 / #360 | `automation/20261121T0440Z/bug/payment-uri-utf16-failclosed` | `2844ec6c22fe179987585679a934e10033ff3384` | Blocked by dependencies |
| 8 / #244 | `chatgpt/btc-spent-private-scan-20261118` | `981cc2f4395d2d76c499a5cd46387daaaa3a6b1f` | Partially implemented |
| 9 / #254 | `chatgpt/btc-spentness-private-scan-20261118` | `2b4b1e912350cb18c630a68b5c1990426e29dbc0` | Unique but requiring correction |
| 10 / — | `chatgpt/ghostpay-idle-lifecycle-20261119` | `7e6089e2e40a2a7daf93961eddef17d3fe8501fd` | Unique but requiring correction |
| 11 / — | `chatgpt/ghostpay-idle-lifecycle-qualified-20261119` | `d5fe06e7a7b383da1726c4d38165c824e996b9db` | Superseded |
| 12 / #276 | `chatgpt/ghostpay-pages-artifact-integrity-20261119` | `f39a9dd36c09f8b02d937c5f3d19676d334976d6` | Superseded |
| 13 / #248 | `chatgpt/ghostpay-private-scan-completion-20261119` | `18b367457103fb1731a5b4ef5c51faa37a010e47` | Partially implemented |
| 14 / #218 | `claude/exciting-brown-7v69cr` | `b1327d4d0e263fdfc7d4fb0b5546b18de2d7434e` | Partially implemented |
| 15 / #209 | `claude/ghostpay-completion-audit-ot5jjm` | `b5e2ea3e5030b56c79063eb1f91c8a634ee5d740` | Partially implemented |
| 16 / #217 | `claude/ghostpay-consolidation-9xhtxg-feeguard` | `9e5cc3789b7b8a3c550ed2680304ab6245ec6676` | Superseded |
| 17 / #212 | `claude/ghostpay-consolidation-9xhtxg-security` | `4894d0d8d94333dffa8ae3937a4d8314f27c686f` | Unique but requiring correction |
| 18 / #213 | `claude/ghostpay-consolidation-9xhtxg-spec18` | `ebf7c92c3be1c7aebd37fc58b5567e114fb932fc` | Partially implemented |
| 19 / #219 | `claude/vibrant-cori-scu18b` | `9617e8572f9bc414410bd937b0e7718d0c5bd55c` | Superseded |
| 20 / — | `codex/ghostpay-export-authorization-20261119` | `b0abb726c138ad1df2f03b7b102c9bd9de318887` | Unique but requiring correction |
| 21 / #262 | `codex/ghostpay-feature-consolidation-20261119` | `40b64e8f3a0f34f7b19235ba4655ef918687f22e` | Unique but requiring correction |
| 22 / — | `codex/ghostpay-private-scan-lint-20261119` | `1b010ec910d04df105fd662cc360629cb0a2f5dd` | Unique but requiring correction |
| 23 / — | `codex/ghostpay-recovered-lean-checkpoint-20261028` | `371d235c3e5926014c00e027196b6aa567ea1b82` | Partially implemented |
| 24 / #210 | `dependabot/npm_and_yarn/npm-minor-patch-71cdd1547c` | `3c95b2a00bdcfb45dd36242ff40c133dd19d1811` | Superseded |
| 25 / — | `evidence/ghostpay-idle-session-r2-20261120` | `ebc3fea4640e2a82585a6cfb73a97fbf0b907949` | Superseded |
| 26 / #300 | `feat/ghostpay-privacy-quick-hide-20261120` | `137628961463fc5abd8b7927b2efe6b18a0a206a` | Unique but requiring correction |
| 27 / #308 | `feat/ghostpay-tor-completion-20261119` | `e60c69f32dbbd9edf7e81ed8866144d665e3de9a` | Superseded |
| 28 / #326 | `feature/ghostpay-retention-completion-20261120` | `a34ce43e296e302e3e65ed077ea8ac892c5189a1` | Unique but requiring correction |
| 29 / #333 | `fix/ghostpay-backup-preflight-20261120-r2` | `3172a93ceb8fce5a4343a93b453dcc0e68f09d87` | Superseded |
| 30 / — | `fix/ghostpay-browser-acceptance-20261120-r3` | `2affd298c364c284d4d74f703fd4a612cc0f16d9` | Unique but requiring correction |
| 31 / #339 | `fix/ghostpay-hygiene-transfer-evidence-20261120` | `d03600ca87c7156d4acd1ff78bef6e92c20d9ea4` | Superseded |
| 32 / #357 | `fix/ghostpay-policy-record-seller-identity-20261121` | `e871eccc1238b7145cd1d0a667afb393c373cf83` | Unique but requiring correction |
| 33 / #340 | `fix/ghostpay-tron-genesis-guard-gpbug15-20261120` | `b86a3e6affe8b71c6f13d16783accad446271ba4` | Blocked by dependencies |
| 34 / #328 | `fix/ghostpay-vault-rekey-lock-revocation-20261120` | `81598d93dd82cc440526c866d42b55be0657895b` | Blocked by dependencies |
| 35 / — | `ghostpay-cloud-recovery-2026-10-26` | `2ec98b23942838c7177d91c46c66c3768b4ca493` | Partially implemented |
| 36 / — | `ghostpay-local-lean-boundary-20261027` | `020ba327e1a26f6d989d428eee19fb12f63dec82` | Partially implemented |
| 37 / — | `ghostpay-offline-deps-2026-10-27` | `3697f539d3a8e5c5c039fb64f4d2bfc970e7f48c` | Partially implemented |
| 38 / — | `ghostpay-sbom-repro-2026-10-27` | `b5b04b999e84e7598dcb98adbf3c44e340223d05` | Partially implemented |
| 39 / — | `integration/ghostpay-idle-session-20261120-r2` | `f5e04a30bd538b5dba6202885c8e1c3cceb31fa3` | Superseded |
| 40 / #256 | `integration/ghostpay-idle-session-completion-20261119` | `e2ebb4902e53e2249c6585a1d72be6e1e416c36c` | Superseded |
| 41 / #264 | `integration/ghostpay-master-consolidation-20261118` | `bf510471283cb0aa9cf6ff79e640e0b50a0b5d0a` | Unique but requiring correction |
| 42 / #255 | `integration/ghostpay-mythril-security-closure-20261118` | `ea47fa75eabb0be2045081ffeb120fc2bfae67ab` | Unique but requiring correction |
| 43 / #238 | `integration/ghostpay-pages-completion-20261118` | `198aa5baff22272453733a0f3dcfcac0e0994eec` | Unique but requiring correction |
| 44 / — | `integration/ghostpay-sweep-consent-20261120` | `2748c9bfd55bd226c7801c15a7acdd955ab70339` | Superseded |
| 45 / #363 | `integration/ghostpay-tor-qualified-20261121` | `260caca240f9944c05ce8951a154193709e30a56` | Blocked by dependencies |
| 46 / #211 | `nodata/wonderful-darwin-kd1h22` | `a92658b1ef6b95ff0145b2e1933d0047d51289d5` | Partially implemented |
| 47 / — | `qualify/ghostpay-hygiene-composition-20261120-9a4ab6` | `0e19ccc7d52b0d160fb756089e6a843a1d2831d7` | Blocked by dependencies |
| 48 / — | `repair/ghostpay-analyzer-recovered-20261119` | `e4d54a6829fcc861de7af1669c0e0f64f62aa137` | Unique but requiring correction |
| 49 / — | `repair/ghostpay-final-lint-20261119` | `73d7ccda4fd448dec1682082d633c90de9fa0d7a` | Unique but requiring correction |
| 50 / — | `repair/ghostpay-native-fee-recovered-20261119` | `cbc96840c3dc4fede90afff55b4dfd94f66784da` | Unique but requiring correction |
| 51 / #253 | `repair/ghostpay-pr-87-20261119` | `6b07e403dd26a8c8e12dfab82dedb0c36002b043` | Experimental or deferred |
| 52 / #252 | `repair/ghostpay-pr-231-20261118` | `4085622463411d3ba27f4efb7b73a70575170535` | Superseded |
| 53 / — | `repair/ghostpay-qr-surrogates-20261119` | `ac7b7a11f00896d105fa7a06e44e218046bdc56c` | Unique but requiring correction |
| 54 / #272 | `review/ghostpay-sweep-quote-lifecycle-20261119` | `63ff40d57af879a3d82166450f63aadb7bf0d5ff` | Superseded |
| 55 / #220 | `security/mythril-full-remediation-20261118` | `16c48521f99903ccd2e584df5d00a9dec5ef754c` | Partially implemented |
| 56 / — | `snapshot/ghostpay-privacy-8be15289-20261120` | `d6819796a9542acc488b896786faffe83b913d9b` | Unique but requiring correction |
| 57 / — | `work/ghostpay-required-v1-candidate-20261120` | `74dccc419bf5c82b21875d205ed5a97d0c4e69b6` | Unique but requiring correction |
| 58 / — | `work/ghostpay-required-v11-candidate-20261120` | `8c196d12fd45dc5a49a6c1d69f9b5d6c532994e9` | Unique but requiring correction |

## Next executable work

1. Finish independent verification and required gates for 89c9b803 Settings partial-import and Bitcoin consent corrections; retain their separate failed-baseline evidence.
2. Fresh worker: reproduce/selectively recover policy asset coverage on #368/#362/#357 and #345. Preserve seller identity, pending-review revocation, unknown coverage and native-buffer checks; do not merge all #211.
3. Finish complete recovery package/web/browser/security/CI qualification; my focused 20 tests retain their actual bd024ca0 pin.
4. Continue explicit residual questions for broad October, checkpoint, early completion and contract/security stacks. Each JSON record retains its original question and bounded-review limits.
5. Root incorporates this subordinate overlay into the authoritative ledger and refreshes newly published refs.

## Ownership and limits

Only this evidence directory was changed by this worker. No application edits, remote mutations, lock changes, PR action, repository setting, deployment, release or live-funds transaction occurred. Source publication/shared integration remain with root and existing owners. Final source 89c9b803 can receive later documentation commits; recheck its exact final head without relabeling older tests. No formal GitHub approval or external professional audit is claimed.

import { CHAINS, type RpcLog } from '@ghostpay/chain-adapters';
import { encodeMetaAddress, generateKeySet, unsafeRevealSecret } from '@ghostpay/core-crypto';
import { expect, it } from 'vitest';
import { runScan } from '../../recovery-spec18/apps/web/src/lib/scanClient';
import { FAKE_ANNOUNCER, FAKE_ROUTER, fakeManifest } from '../../recovery-spec18/apps/web/src/test/fakeManifest';
import { InlineWorker } from '../../recovery-spec18/apps/web/src/test/inlineWorker';
import { makeLog } from '../../recovery-spec18/apps/web/src/test/announcements';
import { mockRpc } from '../../recovery-spec18/apps/web/src/test/mockRpc';

it('bulk evidence does not expose whether a router log without a transaction hash matches the viewer', async () => {
  const owner = generateKeySet();
  const other = generateKeySet();
  const made = makeLog({ announcer: FAKE_ANNOUNCER, metaAddress: encodeMetaAddress(owner), block: 120, index: 0, caller: FAKE_ROUTER });
  const { transactionHash: _ignored, ...withoutTransactionHash } = made.log;
  const log: RpcLog = withoutTransactionHash;
  const run = async (keys: ReturnType<typeof generateKeySet>) => {
    const client = mockRpc(84532, (method, params) => {
      if (method === 'eth_blockNumber') return '0x96';
      if (method === 'eth_getBlockByNumber') {
        const n = BigInt(params[0] as bigint);
        return { hash: `0x${n.toString(16).padStart(64, '0')}`, parentHash: `0x${(n - 1n).toString(16).padStart(64, '0')}` };
      }
      if (method === 'eth_getLogs') return [log];
      throw new Error(`Unexpected request: ${method}`);
    });
    const result = await runScan({
      chain: CHAINS.find((chain) => chain.chainId === 84532)!, manifest: fakeManifest(84532),
      client, cursor: { nextBlock: 0n }, spendingPublicKeyHex: Buffer.from(keys.spendingPublicKey).toString('hex'),
      keyId: 'review-only', viewingKey: unsafeRevealSecret(keys.viewingSecret), createWorker: () => new InlineWorker(),
      signal: new AbortController().signal, bulkEvidence: 10,
    });
    return { result, calls: client.calls };
  };
  const unmatched = await run(other);
  const matched = await run(owner);
  expect(unmatched.result.matches).toHaveLength(0);
  expect(matched.result.matches).toHaveLength(1);
  expect(matched.result.matches[0]?.receipt).toBe('claimed');
  expect(matched.calls).toEqual(unmatched.calls);
});

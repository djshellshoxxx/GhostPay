# Owner directive: stop and preserve non-beta products

**Effective: 2026-11-25. Binding owner instruction, overriding older plans, completion prompts, automation queues and branch-local instructions.** GhostPay's release focus is a privacy payment and recovery client. A new explicit owner instruction is required to restart any product below. There is no automatic restart date or next-release assignment.

## Stopped scope

| ID | Product/workstream | Disposition |
| --- | --- | --- |
| F01 | GhostTips | Preserve earlier permanent archive; no development or activation. |
| F02 | GhostStore | Stop now; archive indefinitely for a possible future version. Deferred and disabled for beta/v1.0 (owner clarification). |
| F04 | Merchant dashboard and aggregate analytics | Stop now; archive indefinitely for a possible future version. Deferred and disabled for beta/v1.0 (owner clarification). |
| F08 / F8 | GhostID | Preserve earlier deferral beyond v1.0; no development or activation. |
| F09 | GhostPOS, including the POS terminal example product | Preserve earlier permanent archive; no development or activation. |
| F11 | GhostTeams | Preserve earlier deferral beyond v1.0; no development or activation. |
| F12 | GhostBridge / GhostPay integration with P2P-Offramp | Preserve earlier deferral beyond v1.0; the independent P2P-Offramp repository is outside this instruction. |
| F13 | Fiat conversion and provider/off-ramp handoff | Preserve earlier permanent archive; no development or activation. |
| P07 | Encrypted device synchronization | Stop now; archive indefinitely for a possible future version. A separate exclusion; do not confuse original module IDs with conversational inventory IDs. |
| F14 | Multi-chain routing | Preserve the earlier stop/deferral beyond v1.0. The latest list did not reverse it. |

All ten are excluded from beta and v1.0. The duplicate GhostTeams mention means one stopped workstream. **P07 device synchronization is not F07 GhostPayouts.** An archived workstream is not a completed feature, failed acceptance test or outstanding release blocker. Only F01/F09/F13 are permanently archived; every other stopped product needs a new explicit owner instruction for any future release. **Conversational P14 RPC provider disclosure is included in beta/v1.0; it is not F14 multi-chain routing.**

Do not implement, complete, assign, repair feature-specific behavior for promotion, revive, integrate, merge feature work, enable, advertise or deploy these products. Permitted work is limited to archival bookkeeping, containment, release-exclusion verification and narrowly necessary shared-core privacy/payment/recovery maintenance. Missing shared-core requirements are scoped as separate core work, never on archived product branches. Do not start subscriptions, cross-chain, storefront, POS, team or new hosted privacy-service programs as part of this beta.

## Preserve source and shared functionality

The owner explicitly requested preservation. Do not delete branches, overwrite source refs, revert integrated source merely to remove product scope, remove persisted data formats, or break recovery of existing records. Leave integrated product code dormant and disabled. Keep original tests and research available for a possible later version.

| Stopped product | Functionality that remains core |
| --- | --- |
| Merchant dashboard | Individual invoice status, payment evidence, reconciliation, receipts and truthful pending/confirmed/unknown state. Encrypted local payment history and masking. |
| GhostID | Ordinary invoice signing keys, signature verification and the recipient keys required for payment. Pseudonymous payment identities, identity separation and cryptographic identity verification. |
| GhostStore / GhostTips / GhostPOS | Generic payment requests, links, QR and amount entry used by the basic browser payment flow. Stealth destinations, minimal metadata, encrypted invoices, private links, ordinary private QR and secure invoice exchange. |
| GhostTeams | Local encryption and session isolation. |
| P07 device sync | Manual encrypted export/import, verified backup, fresh-browser recovery, sole-copy protection, and local cross-tab payment integrity. Spec 18 recovery obligations are not waived. |
| Fiat conversion | Exact crypto-amount parsing, integer bounds, shared arithmetic and persisted reference-currency compatibility. A reference rate is not an executed fiat trade. Generic external-service disclosure, consent and data minimization. |
| GhostBridge | Ordinary direct person-to-person crypto requests. Only the separate fiat/off-ramp integration is stopped. Generic external-service disclosure, consent and data minimization. |
| Multi-chain routing | Chain identity, network checks, replay protection and existing supported-chain selection. Network isolation and chain validation within approved EVM scope; no chain-scope expansion. |

**Mandatory shared-core privacy (binding owner clarification).** The [owner clarification in AGENTS.md](../../AGENTS.md) is the complete list of protected mechanisms. They include stealth destinations and local discovery, spending/viewing key separation, address-reuse warnings, encrypted invoices/storage/history, private links/QR, masking, clipboard cleanup, vault/session isolation, retention controls, external-wallet and RPC provider disclosure, consent, local filtering, Tor compatibility and truthful network disclosures, sweep linkability warnings, selective-disclosure evidence, encrypted backups and independent recovery, and qualified privacy settings with no silent downgrades. It overrides any narrower reading of this table but does not reinstate a stopped product. Before release, document and verify core privacy retention and excluded-product dormancy separately.

The privacy product recommendations are separately recorded in [PRIVACY_PAYMENT_BETA.md](../product/PRIVACY_PAYMENT_BETA.md). They do not authorize activating experimental privacy packages or silently changing accepted recovery requirements.

## Archive and pull-request record

[The machine-readable archive manifest](../archive/feature-freeze-20261125.json) records original refs, exact commit SHAs, feature identifiers, preserved mixed compositions and actions taken. Original refs remain intact. **34 frozen archive branches** were created under `archive/owner-stop-20261125/`: 31 feature/adjacent refs and three mixed compositions. These snapshot branches are preservation records, not candidates for automatic consolidation or feature completion. Do not move them.

The following **17 feature-only PRs were closed and marked archived**, preserving their original descriptions and source heads:

| Scope | Archived PRs |
| --- | --- |
| GhostStore | [#550](https://github.com/djshellshoxxx/GhostPay/pull/550), [#556](https://github.com/djshellshoxxx/GhostPay/pull/556) |
| Merchant dashboard | [#322](https://github.com/djshellshoxxx/GhostPay/pull/322), [#397](https://github.com/djshellshoxxx/GhostPay/pull/397), [#460](https://github.com/djshellshoxxx/GhostPay/pull/460), [#535](https://github.com/djshellshoxxx/GhostPay/pull/535), [#543](https://github.com/djshellshoxxx/GhostPay/pull/543), [#564](https://github.com/djshellshoxxx/GhostPay/pull/564), [#579](https://github.com/djshellshoxxx/GhostPay/pull/579), [#618](https://github.com/djshellshoxxx/GhostPay/pull/618), [#636](https://github.com/djshellshoxxx/GhostPay/pull/636) |
| GhostTeams | [#552](https://github.com/djshellshoxxx/GhostPay/pull/552), [#554](https://github.com/djshellshoxxx/GhostPay/pull/554), [#562](https://github.com/djshellshoxxx/GhostPay/pull/562) |
| Fiat conversion | [#566](https://github.com/djshellshoxxx/GhostPay/pull/566) |
| POS follow-ups | [#411](https://github.com/djshellshoxxx/GhostPay/pull/411), [#646](https://github.com/djshellshoxxx/GhostPay/pull/646) |

Four PRs remain **open but explicitly held**. [#371](https://github.com/djshellshoxxx/GhostPay/pull/371) and [#621](https://github.com/djshellshoxxx/GhostPay/pull/621) mix stopped F04 work with F05/F10 and shared tooling. [#614](https://github.com/djshellshoxxx/GhostPay/pull/614) mixes POS with amount, countdown and QR changes. Preserve these compositions and unrelated core work, but do not merge them as-is to promote stopped features. [#592](https://github.com/djshellshoxxx/GhostPay/pull/592) is held as non-beta reference-rate checkout/relayer qualification; it is distinct from F13 provider conversion.

Merged GhostID and POS work remains in main, with its original donor heads also pinned. Broad catalogs, unrelated descendants carrying inherited stopped-feature paths and the integration coordination lock are not whole-branch cancellation targets. The manifest records those distinctions. The review covered the 734-branch census and fresh target-PR/ref reads; unpublished local work or newly created refs require a fresh check.

## Current main containment evidence

Source baseline: `595a184b381980a440165832f51a83e8dfd3e8a8`. This is **source inspection, not a new runtime, artifact, browser, deployment or privacy-audit qualification**.

- [AppLean](../../apps/web/src/AppLean.tsx) and [AppShell](../../apps/web/src/AppShell.tsx) expose the core home, seller, create, pay, scan, sweep, registry, settings and about routes. No stopped-product route is reachable in the lean beta source.
- GhostStore, GhostTeams and the merchant dashboard implementation stacks remain unmerged. [Scan](../../apps/web/src/views/Scan.tsx) retains the core reconciliation ledger; it is not the stopped dashboard product.
- [MerchantProfilePanel](../../apps/web/src/components/MerchantProfilePanel.tsx) gates the integrated GhostID offline reviewer on `VITE_GHOSTID_OFFLINE_REVIEW === '1'`. It is default-off and excluded from the lean entry point. Do not set the activation flag for a beta build.
- The integrated [POS example](../../examples/pos-terminal/README.md) and the tip-link helper remain preserved source. No lean application route or runtime import was identified for either product.
- Lean [CreateInvoice](../../apps/web/src/views/CreateInvoice.tsx) forces fixed-token mode, and [Pay](../../apps/web/src/views/Pay.tsx) rejects unsupported fiat-quoted invoices. Full-profile reference-rate pricing is still possible for configured feeds; it is not the F13 provider/off-ramp product. This directive does not falsely claim that every fiat-related path in every profile was removed or disabled.
- [The Pages build](../../scripts/pages/build-pages.sh) uses a clean lean environment. Existing [site verification](../../scripts/pages/verify-pages-site.mjs) and [profile checks](../../apps/web/scripts/localBuildProfile.mjs) provide partial deferred-module guards. Exact emitted-artifact exclusion for all ten stopped products remains a release check; source absence is not a substitute for that check.

This archival change deliberately leaves application, contract, dependency and workflow source intact. If a later integration exposes a stopped product, perform a bounded containment change; do not resume product completion or remove shared payment/recovery behavior.

## Worker and tracker instructions

All five saved GhostPay worker tasks were updated with the expanded scope while preserving their schedules and original allowed operations. A status-only task remains status-only; a narrow repair remains narrow. The [Feature Completion Tracker](https://chatgpt.com/space/page_d3d451a9e2b48191a759601e7b3e538f) now carries the same ten-feature directive and archives 23 stopped-feature launch prompts as plain-text historical records. Checkbox states and historical evidence were retained; archive status was not recorded as completion.

Saved instructions do not forcibly interrupt an already running external session. At its next safe checkpoint, that session must preserve local work, record its head and stop the affected feature task. Use this instruction when handing control back to a running worker:

> Stop work on F01/F02/F04/F08/F09/F11/F12/F13/P07 and the previously stopped F14. Preserve your local changes and branch head; do not merge, enable or continue feature development. Read current main AGENTS.md and docs/ai/STOP_WORK_20261125.md. Report any unpushed checkpoint. Continue only separately authorized core privacy, payment or recovery work within your existing task scope.

## Restart rule

A later restart needs a new explicit owner decision identifying the product, intended user benefit, acceptance milestone and release scope. Reinspect the archived source against then-current main and review privacy, shared-data compatibility and recovery implications before implementation. The existence of code, a passing old test, an open mixed PR or a historical completion prompt is not restart authorization.

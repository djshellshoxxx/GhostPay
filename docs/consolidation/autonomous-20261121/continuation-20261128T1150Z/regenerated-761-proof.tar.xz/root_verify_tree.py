from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).parent
source = json.loads((ROOT / 'source-inputs.json').read_text())

def identity(kind, data):
    return hashlib.sha1(kind.encode() + b' ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def leaves(tree):
    assert not tree['truncated']
    return {e['path']: (e['mode'], e['type'], e['sha']) for e in tree['entries'] if e['type'] != 'tree'}

def tree_hash(entries):
    root = {}
    for path, item in entries.items():
        cursor = root
        segments = path.split('/')
        for segment in segments[:-1]:
            cursor = cursor.setdefault(segment, {})
        assert segments[-1] not in cursor
        cursor[segments[-1]] = item
    def walk(folder):
        data = bytearray()
        for name in sorted(folder, key=lambda n: (n + ('/' if isinstance(folder[n], dict) else '')).encode()):
            value = folder[name]
            mode, sha = ('40000', walk(value)) if isinstance(value, dict) else (value[0], value[2])
            data.extend(mode.encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(sha))
        return identity('tree', bytes(data))
    return walk(root)

graphs = {name: leaves(tree) for name, tree in source['trees'].items()}
source_checks = {}
for name, entries in graphs.items():
    computed = tree_hash(entries)
    assert computed == source['trees'][name]['sha'], name
    source_checks[name] = {'tree': computed, 'leaves': len(entries)}

base, main, candidate = (graphs[n] for n in ['base', 'main', 'candidate'])
candidate_paths = {p for p in base.keys() | candidate.keys() if base.get(p) != candidate.get(p)}
main_paths = {p for p in base.keys() | main.keys() if base.get(p) != main.get(p)}
active = 'docs/ai/ACTIVE_WORK.md'
assert candidate_paths & main_paths == {active}
assert len(candidate_paths) == 3
registry = source['registry_equality_precheck']
base_text = source['files']['active_base']['content']
assert source['files']['active_main']['content'] == registry['prefix'] + base_text
assert source['files']['active_candidate']['content'] == base_text + registry['suffix']
combined_text = registry['prefix'] + base_text + registry['suffix']
combined_blob = identity('blob', combined_text.encode())
merged = dict(main)
for path in candidate_paths:
    assert path in candidate
    merged[path] = candidate[path]
merged[active] = (candidate[active][0], candidate[active][1], combined_blob)
computed = tree_hash(merged)
assert computed == source['expected_prospective_tree']
result = {
    'scope': 'Root independently recomputed all three source Git tree identities and the prospective composition; no test execution or remote mutation.',
    'sourceTrees': source_checks,
    'main': source['refs']['main'],
    'candidate': source['refs']['candidate'],
    'commonBase': source['common_base'],
    'candidateChangedPaths': sorted(candidate_paths),
    'mainChangedPaths': sorted(main_paths),
    'sharedChangedPaths': sorted(candidate_paths & main_paths),
    'registryBlob': combined_blob,
    'registryPrefixLines': len(registry['prefix'].splitlines()),
    'registrySuffixLines': len(registry['suffix'].splitlines()),
    'prospectiveTree': computed,
    'prospectiveLeafCount': len(merged),
    'candidateGitHubSyntheticCommit': source['commits']['synthetic'],
    'note': 'GitHub synthetic merge is historical/stale against current main; this separately derived current-main composition is not a newly hosted or locally executed test run.',
}
(ROOT / 'ROOT_TREE_HASH_CHECK.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'main': result['main'], 'candidate': result['candidate'], 'tree': computed, 'leaves': len(merged), 'candidateChangedPaths': sorted(candidate_paths), 'commonOverlap': [active]}))

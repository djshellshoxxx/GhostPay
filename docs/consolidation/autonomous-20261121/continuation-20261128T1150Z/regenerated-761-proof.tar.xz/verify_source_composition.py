"""Verify immutable Git object composition only. Does not execute application tests."""
from pathlib import Path
import copy
import hashlib
import json

ROOT = Path(__file__).resolve().parent
INPUT = ROOT / "source-inputs.json"
source = json.loads(INPUT.read_text(encoding="utf-8"))

def object_sha(kind, body):
    return hashlib.sha1(kind.encode("ascii") + b" " + str(len(body)).encode("ascii") + bytes([0]) + body).hexdigest()

def entry_value(entry):
    return {k: entry[k] for k in ("mode", "type", "sha")}

def leaf_map(snapshot):
    return {e["path"]: entry_value(e) for e in snapshot["entries"] if e["type"] != "tree"}

def hash_tree(snapshot, verify_declared=True):
    root = {}
    declared = {}
    for e in snapshot["entries"]:
        parts = e["path"].split("/")
        cursor = root
        for part in parts[:-1]:
            cursor = cursor.setdefault(part, {})
            assert isinstance(cursor, dict)
        if e["type"] == "tree":
            assert e["mode"] == "040000"
            cursor.setdefault(parts[-1], {})
            declared[e["path"]] = e["sha"]
        else:
            assert parts[-1] not in cursor, "duplicate path"
            cursor[parts[-1]] = (e["mode"], e["type"], e["sha"])
    computed = {}
    def recurse(directory, prefix):
        records = []
        for name, item in directory.items():
            raw_name = name.encode("utf-8")
            if isinstance(item, dict):
                child_path = prefix + name
                digest = recurse(item, child_path + "/")
                computed[child_path] = digest
                mode = "40000"
                key = raw_name + b"/"
            else:
                mode, kind, digest = item
                assert kind in ("blob", "commit")
                mode = format(int(mode, 8), "o")
                key = raw_name
            record = mode.encode("ascii") + b" " + raw_name + bytes([0]) + bytes.fromhex(digest)
            records.append((key, record))
        return object_sha("tree", b"".join(r for _, r in sorted(records)))
    result = recurse(root, "")
    mismatches = [{"path": p, "expected": h, "computed": computed.get(p)} for p, h in declared.items() if computed.get(p) != h]
    if verify_declared:
        assert result == snapshot["sha"], (result, snapshot["sha"])
        assert not mismatches, mismatches
    return result, len(computed), mismatches

roundtrips = {}
for role, snapshot in source["trees"].items():
    assert snapshot["truncated"] is False
    value, subtrees, mismatches = hash_tree(snapshot)
    roundtrips[role] = {
        "tree": value, "all_tree_entries": len(snapshot["entries"]),
        "leaf_entries": len(leaf_map(snapshot)), "verified_subtrees": subtrees,
        "subtree_mismatches": mismatches, "root_sha_matches": True,
    }

b, m, c = [leaf_map(source["trees"][x]) for x in ("base", "main", "candidate")]
def diff(left, right):
    return [{"path": p, "before": left.get(p), "after": right.get(p)}
            for p in sorted(set(left) | set(right)) if left.get(p) != right.get(p)]
main_delta = diff(b, m)
candidate_delta = diff(b, c)
overlap = sorted(set(x["path"] for x in main_delta) & set(x["path"] for x in candidate_delta))
registry = "docs/ai/ACTIVE_WORK.md"
assert overlap == [registry]
assert len(main_delta) == 5
assert len(candidate_delta) == 3
expected_candidate_paths = {
    "apps/web/src/components/PrivacyControls.donor300.test.tsx",
    "docs/handoffs/QUICK_HIDE_300_DISPOSITION_20261127.md", registry,
}
assert set(x["path"] for x in candidate_delta) == expected_candidate_paths

file_verification = []
for name, f in source["files"].items():
    data = f["content"].encode("utf-8")
    calculated = object_sha("blob", data)
    assert calculated == f["sha"], name
    if name == "active_base":
        origin = b
    elif name == "active_main":
        origin = m
    else:
        origin = c
    assert origin[f["path"]]["sha"] == calculated, name
    file_verification.append({"name": name, "path": f["path"], "commit": f["ref"],
                              "blob": calculated, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

instruction_verification = []
for path, f in {**source["instructions"], **source["workflow_handoff"]}.items():
    data = f["content"].encode("utf-8")
    calculated = object_sha("blob", data)
    assert calculated == f["sha"] == m[path]["sha"]
    instruction_verification.append({"path": path, "blob": calculated, "sha256": hashlib.sha256(data).hexdigest()})

base = source["files"]["active_base"]["content"].encode("utf-8")
main = source["files"]["active_main"]["content"].encode("utf-8")
candidate = source["files"]["active_candidate"]["content"].encode("utf-8")
assert main.endswith(base) and candidate.startswith(base)
prefix = main[:-len(base)]
suffix = candidate[len(base):]
assert len(prefix.splitlines()) == 11 and len(suffix.splitlines()) == 7
combined_registry = prefix + base + suffix
assert combined_registry == prefix + candidate == main + suffix
registry_sha = object_sha("blob", combined_registry)

composed_leaves = copy.deepcopy(m)
for row in candidate_delta:
    path = row["path"]
    if path == registry:
        continue
    if row["after"] is None:
        composed_leaves.pop(path, None)
    else:
        composed_leaves[path] = row["after"]
composed_leaves[registry] = {"mode": m[registry]["mode"], "type": "blob", "sha": registry_sha}
assert c[registry]["mode"] == m[registry]["mode"] == b[registry]["mode"] == "100644"
entries = [copy.deepcopy(e) for e in source["trees"]["main"]["entries"] if e["type"] == "tree"]
entries += [{"path": path, **value} for path, value in sorted(composed_leaves.items())]
prospective, prospective_subtrees, _ = hash_tree({"entries": entries}, verify_declared=False)
assert prospective == source["expected_prospective_tree"], prospective

main_only_preserved = all(composed_leaves[r["path"]] == r["after"] for r in main_delta if r["path"] != registry)
candidate_only_preserved = all(composed_leaves[r["path"]] == r["after"] for r in candidate_delta if r["path"] != registry)
untouched = set(b) - set(r["path"] for r in main_delta) - set(r["path"] for r in candidate_delta)
untouched_errors = [p for p in sorted(untouched) if not b[p] == m[p] == c[p] == composed_leaves[p]]
assert main_only_preserved and candidate_only_preserved and not untouched_errors
assert len(composed_leaves) == 5059
assert source["commits"]["synthetic"]["tree"] == source["commits"]["candidate"]["tree"]
assert source["commits"]["synthetic"]["parents"] == [source["common_base"], source["refs"]["candidate"]]
assert source["common_base"] in source["commits"]["main"]["parents"]
assert source["common_base"] in source["commits"]["candidate"]["parents"]

leaf_bytes = json.dumps(composed_leaves, sort_keys=True, separators=(",", ":")).encode("utf-8")
proof = {
    "review_kind": "NEW read-only source-composition proof; no product tests executed",
    "reviewer": source["reviewer"],
    "refs_checked_at": source["refs"]["checked_at"],
    "input_created_at": source["created_at"],
    "source_inputs_sha256": hashlib.sha256(INPUT.read_bytes()).hexdigest(),
    "refs": source["refs"],
    "common_base": source["common_base"],
    "commits": source["commits"],
    "recursive_tree_roundtrips": roundtrips,
    "main_delta": main_delta,
    "candidate_delta": candidate_delta,
    "overlap": overlap,
    "file_blob_verification": file_verification,
    "current_main_instruction_verification": instruction_verification,
    "active_work": {
        "base_blob": b[registry]["sha"], "main_blob": m[registry]["sha"],
        "candidate_blob": c[registry]["sha"], "prospective_blob": registry_sha,
        "base_bytes": len(base), "main_prefix_bytes": len(prefix), "candidate_suffix_bytes": len(suffix),
        "main_prefix_lines": len(prefix.splitlines()), "candidate_suffix_lines": len(suffix.splitlines()),
        "combined_bytes": len(combined_registry), "combined_sha256": hashlib.sha256(combined_registry).hexdigest(),
        "main_equals_prefix_plus_base": True, "candidate_equals_base_plus_suffix": True,
        "combined_equals_prefix_plus_complete_candidate": True, "combined_equals_complete_main_plus_suffix": True,
        "prefix_utf8": prefix.decode("utf-8"), "suffix_utf8": suffix.decode("utf-8"),
    },
    "synthetic_merge": {
        "stale_relative_to_current_main": True,
        "actual_tree": source["commits"]["synthetic"]["tree"],
        "actual_tree_is_exact_candidate_tree": True,
        "actual_base_parent": source["commits"]["synthetic"]["parents"][0],
        "current_main": source["refs"]["main"],
        "does_not_establish_current_main_qualification": True,
    },
    "prospective_composition": {
        "tree": prospective, "matches_previously_reported_tree": True,
        "leaf_entries": len(composed_leaves), "computed_subtrees": prospective_subtrees,
        "canonical_leaf_map_sha256": hashlib.sha256(leaf_bytes).hexdigest(),
        "relative_to_main": diff(m, composed_leaves), "relative_to_candidate": diff(c, composed_leaves),
        "main_only_changes_preserved": main_only_preserved,
        "candidate_only_changes_preserved": candidate_only_preserved,
        "unchanged_base_leaf_entries_verified": len(untouched), "unchanged_leaf_errors": untouched_errors,
        "unexpected_paths": [],
    },
    "scope": {
        "application_tests_executed": False, "browser_tests_executed": False,
        "source_edits": False, "remote_mutations": False, "lock_or_merge_attempts": False,
        "historical_test_logs_restored_or_recreated": False,
        "calculation_method": "Git SHA-1 object serialization, validated against all source root and subtree identities; additive three-way leaf composition with byte-exact registry union.",
        "qualification_limit": "Source preservation only. Existing exact-head CI, main/lease/owner checks and resulting-composition qualification remain required."
    },
}
text = json.dumps(proof, indent=2) + "\n"
(ROOT / "composition-proof.json").write_text(text, encoding="utf-8")
print(text, end="")

# Retention completion review — current recovery candidate

## Decision

**Retention remains partially implemented. A small persistent metadata adapter is actionable; whole transaction, invoice, journal, receipt, tag, or vault deletion is not justified.**

This independent, read-only review examined source `783231a46840cd869e39bd704751d4ab4c349c45`, tree `65e5cc6fdb7ab3337951ba0b0b58e87b71df095b`, in `recovery-settings-fix`. The source was clean before and after review and execution. The reviewer changed only this evidence directory. No source, dependency, remote ref, integration lease, deployment, release, network provider, or funds operation was changed.

Live GitHub issues [286](https://github.com/djshellshoxxx/GhostPay/issues/286) and [287](https://github.com/djshellshoxxx/GhostPay/issues/287) were reread during this assignment. Both remain open, have no comments, and their last update remains 2026-11-19. The retrieved complete JSON is retained in this packet. Issue 287 item 4 applies to v1.1; it must not become an additional v1.0 release dependency.

## Standards review

No new blocking defect was identified in the scoped presentation-retention implementation. Its registry accepts only bounded presentation callbacks, stores no record contents, isolates invoice/proof consent, and binds manual plans to an exact in-memory revision. Unknown, inaccessible, ambiguous, or unsupported policies resolve to off. The three production adapters clear only their generated/displayed copies. The source does not pass a durable store or journal mutation capability into this registry.

Current ownership and source pins were respected. The review used the standards/spec split from the code-review skill, but did not spawn nested reviewers because all four team slots were occupied. It is one AI-worker review, not formal GitHub approval or an external security audit.

## Specification review

**One open requirement:** issue 287 item 4 is not complete because the existing cleanup adapter covers mounted presentation copies, not persistent transaction/invoice metadata. `docs/privacy-release/STATUS.md` correctly says partial. Existing full-web receipts supplied by the coordinator and this review's additional focused execution do not implement the missing persistent behavior.

The historic census correctly excludes entire protected records. It is too broad to establish that every field in those records is essential. A current field-level examination identifies a defensible smaller next step: local save-time metadata, beginning with `RegisteredInvoice.registeredAt`.

## Current implementation and preserved boundaries

| Family | Current decision | Source evidence |
| --- | --- | --- |
| Completed CreateInvoice result | Implemented presentation cleanup; editable draft, seller session, registration and shared links remain outside the callback | `CreateInvoice.tsx`, `useInvoicePreviewRetention.ts`, complete current regression |
| Completed MerchantTemplateIssuer result | Implemented presentation cleanup; current seller identity, pending generation, immutable profile and form mode remain separate | `MerchantTemplateIssuer.tsx`, complete current regression |
| Explicitly shown included-payment proof | Implemented presentation cleanup; exact parent result, payment authority, hash, copy/download and journal remain available | `PaymentRequestQr.tsx`, `Pay.tsx`, complete component and Pay tests |
| Registered invoice rows | Preserve the row, digest, nonce, chain, asset, amount, creation and expiry window; expired invoices can still matter to late-payment matching | `reconciliation-portable.ts`: RegisteredInvoice, candidate, proposeInvoiceMatch |
| Archived signed receipt rows | Preserve each complete signed receipt and signature; it may be the user's only stored receipt | `reconciliation-portable.ts`: ArchivedReceipt, archiveReceipt, exportReceipts |
| Observations and reorg state | Protect `recordedAt`, `blockTimestamp`, `invalidatedFrom`, `invalidatedAt`, provenance, tombstones, annotations and saturation state | `withSaved`, `covers`, `mergeCutoffs`, `mergeImport`, `invalidateFrom` |
| Tag vault, user notes and profile state | Protect: free-form user content has no positive nonessentialness proof; timestamps and revisions also participate in archival merge/CAS; no automatic cleanup is justified by age | `tags.ts`, `idbStore.ts`, `tag-archive-portable.ts` |
| Encrypted seller vault and backups | Protect; never part of the proposed adapter | `keyVault.ts`, explicit vault lifecycle |
| Wallet and policy attempt journals | Protect unknown/submitted attempts and hashes; no expiry proves a prior request cannot mine | `duplicateAttemptJournal.ts`, `withdrawalJournal.ts` |
| Sweep locks and failure tombstone | Protect from a generic TTL policy. The existing bounded writer can replace a resolved lock at capacity; that specific behavior is not permission for a new cleanup adapter | `sweepAttemptJournal.ts` |
| Signer/merchant pins and scan state | Protect trust decisions and scan/reorg state | `invoiceSignerPins.ts`, `merchantIdentity.ts`, `scanClient.ts` |
| Preferences and endpoint authorization | Keep explicit choices; these are not disposable transaction/invoice metadata | `networkAuthorization.ts`, current settings consumers |
| Legacy plaintext reconciliation | Existing read/export/explicit removal remains separate; no new plaintext writes or automatic TTL | `reconciliationLedger.ts` |

The current `PaymentProofQr` browser acceptance is authored in `apps/web/e2e/flows.spec.ts`. This reviewer read the assertions but launched no browser. Runtime browser results must come from the coordinator's exact-source hosted receipts.

## Actionable field-level proposal

### First slice: local invoice registration timestamp only

`RegisteredInvoice.registeredAt` is generated locally by `registrationFromInvoice`. The complete production consumer search finds it in its type, strict key list, validation, constructor and serialization, but no matching, payment amount, expiry, reorg, nonce, key recovery, signature, or UI decision uses the value. The complete invoice registration still contains its original `createdAt` and `expiresAt`; those are different fields and remain protected.

`createInvoicePaymentSummarizer` calls the registration validator, so this is not permission to delete the property from an otherwise unchanged format. A compatible explicit representation and validator path are prerequisites. The evidence supports a metadata-only implementation proposal, not an already-tested new schema.

A bounded next assignment can:

1. Add an explicitly versioned representation for a removed local save timestamp. Continue reading all existing document versions and reject unknown versions without overwriting their bytes. Never substitute a fabricated timestamp such as zero or reuse an invoice's signed time as if it were the actual local save time.
2. Keep the complete invoice row, row identity, every financial/signing field and every existing security field. No new collection is necessary.
3. Add a current-unlocked-scope, count-only preview and explicit confirmation for the timestamp category. The preview must bind exact current ciphertext plus session/scope/revision, be single-use, and fail on any intervening storage write. The existing generic `change()` loop retries optimistic writes; a destructive reviewed plan must not silently expand onto a different snapshot during those retries.
4. Keep existing invoice-preview and proof-preview consent separate. Start the persistent category off. A manual-only first slice is sufficient to implement real persistent cleanup, but it does not by itself establish the entire user-configurable retention acceptance.
5. Preserve removed-time state across export/import, normal duplicate registration and refresh. The current merge keeps an already present local invoice by digest or nonce, which can preserve an explicit removed-time marker; test that behavior rather than assuming it. New imported rows need a clear, separate current policy decision.
6. Keep all processing local, encrypted at rest and active/unlocked-session scoped. No RPC, new network request, new sensitive store or global origin clearing is needed.

Suggested owned production paths: `packages/ux-vault/src/reconciliation-portable.ts`, the browser reconciliation API re-export if necessary, and a dedicated small cleanup panel wired into `apps/web/src/components/ReconciliationLedger.tsx`. A preference helper should remain separate from the existing presentation callback registry; that registry is not a transactional persistent-store executor. Add only the necessary localization keys and bounded specification amendment. Update `ADR-0026` for the explicit format transition.

### Second slice, only after a separate eligibility review

`ArchivedReceipt.archivedAt` is likewise a local timestamp outside the signed receipt. Its only additional production consumer is one display line in `ReconciliationLedger.tsx`. The signed receipt's `issuedAt` must remain unchanged. Removing the local archive time therefore appears feasible without removing receipt evidence, but it changes an existing visible archival detail. Review that field separately, name it explicitly in the preview and update its display without inventing a date. Do not infer permission to remove the receipt itself.

### Necessary tests for the proposed persistent slice

These are **unexecuted proposed acceptance tests**, not claims about this review's 119 passing cases:

- Legacy version 1/2/3 encrypted documents still open and export; the new removed-time representation round-trips; an old/unsupported reader fails closed and preserves ciphertext.
- Manual preview/cancel has no write; confirmation changes only the allowlisted timestamp field; complete rows, invoice digest/nonce/amount/window, signed receipts, observed records, tombstones/cutoffs, keys and unrelated stores compare unchanged.
- Matching and partial/overpayment summaries give identical results before and after timestamp removal.
- Same-object replay, replacement source, lock, same-key session reinstall, cross-tab write, storage denial and CAS failure all reject stale cleanup without erasing records.
- Backup import and duplicate registration do not restore a timestamp the current row has explicitly removed; newly imported rows remain governed by the documented consent.
- If automatic retention is subsequently added: separate default-off consent, policy revocation/focus/reload, exact deadlines, rollback/non-finite clocks, current unlock and scope, no background capability after unmount, and no cleanup of unknown record types.
- Complete existing reconciliation package/browser suites, source review, original type/lint/coverage/build gates, Chromium/Firefox/WebKit, mobile and accessibility qualification on the exact combined candidate.

This is an actionable engineering gap. It should not be relabeled a permanently blocked external dependency merely because no whole stored record was safe to delete. It also should not be rushed into a blanket cleanup operation or advertised as completed before those schema, concurrency and browser checks exist.

## Actual independent execution

Command, from `recovery-settings-fix/apps/web`:

```text
node ../../node_modules/vitest/vitest.mjs run --coverage=false --maxWorkers=1 src/lib/metadataRetention.test.ts src/components/MetadataRetentionControls.test.tsx src/views/CreateInvoice.retention.test.tsx src/components/MerchantTemplateIssuer.retention.test.tsx src/components/PaymentProofQr.retention.test.tsx src/views/Pay.test.tsx
```

**119 tests passed, 6 files passed, 0 failed, 0 skipped; exit 0.** Process wall time: **32.858 seconds**. Vitest reports 32.56 seconds. Before/after HEAD and tree are identical and the tracked worktree remains clean. This uses the original assertions and corrected source. It is focused execution with coverage disabled, not a new aggregate coverage pass.

The selection verifies current callback-plan ownership, bounded capacity, cleanup failure/disposal/reentry handling, policy persistence/focus/remount/isolation, actual issuer cleanup, included-proof eligibility/lifetimes, preserved export bytes and current Pay authority. These cases overlap the coordinator's full 4,405-test web run and must not be added as new unique tests.

No test source, assertion, threshold, include/exclude set, dependency, or workflow was edited. No vulnerable revision was run and no exploit payload or attack workflow was created.

## Open qualification and integration gates

- Persistent metadata cleanup is unimplemented. The first slice above is a concrete next task, not a completion claim.
- Browser engines, mobile, Tor routing, full aggregate coverage, native chain integration and hosted CI were not executed by this reviewer.
- The existing parent-chain and unreconciled generation-11 integration lease remain coordinator gates.
- Existing original data, source branches and current candidate were preserved.
- v1.1 remains unqualified; this review does not change v1.0 feature scope.

## Evidence

`retention-focused.receipt.json` and `retention-focused.log` retain the actual execution. `reviewed-source-files.json` pins 40 reviewed source/test/spec files to Git blobs and SHA-256 hashes. Consumer searches and wiring/storage inventory commands are retained with their exit statuses and log hashes. `HANDOFF.json` is the machine-readable decision; `MANIFEST.json` covers the delivered packet.


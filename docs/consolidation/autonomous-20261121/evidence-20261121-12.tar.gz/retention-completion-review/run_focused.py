import subprocess,json,time,datetime,hashlib,pathlib,os
repo=pathlib.Path('/workspace/scratch/5ceb6203640a/recovery-settings-fix')
out=pathlib.Path('/workspace/scratch/5ceb6203640a/retention-completion-review-evidence')
cmd=['node','../../node_modules/vitest/vitest.mjs','run','--coverage=false','--maxWorkers=1','src/lib/metadataRetention.test.ts','src/components/MetadataRetentionControls.test.tsx','src/views/CreateInvoice.retention.test.tsx','src/components/MerchantTemplateIssuer.retention.test.tsx','src/components/PaymentProofQr.retention.test.tsx','src/views/Pay.test.tsx']
cwd=repo/'apps/web'
before=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD','HEAD^{tree}'],text=True).splitlines()
t0=time.monotonic();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
log=out/'retention-focused.log'
with log.open('wb') as f:
 p=subprocess.run(cmd,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,env=os.environ.copy())
after=subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD','HEAD^{tree}'],text=True).splitlines()
receipt={'command':cmd,'cwd':str(cwd),'started_at_utc':started,'ended_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'duration_seconds':round(time.monotonic()-t0,3),'exit_code':p.returncode,'before':before,'after':after,'worktree_status':subprocess.check_output(['git','-C',str(repo),'status','--short'],text=True),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'coverage':False,'scope':'Existing corrected-source focused tests; no source or assertion modifications'}
(out/'retention-focused.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2));print(log.read_text()[-8000:])

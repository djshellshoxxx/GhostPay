import datetime
import hashlib
import json
import pathlib
import re
import shutil
import subprocess

OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parent / 'GhostPay-chain-interop'
SOURCE = '08ac68148861ca00b68720572afd0f22fad5dd27'
TREE = '9cdb74017b5950ea78da3e058e6c1831003c21cc'
BASE = 'eb59d93cffed7848c4aac37d0e9650b87239c6da'
DONOR = 'a92658b1ef6b95ff0145b2e1933d0047d51289d5'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

final_state = {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
               'status_porcelain': git('status', '--porcelain=v1', '--untracked-files=all')}
assert final_state['head'] == SOURCE and final_state['tree'] == TREE and not final_state['status_porcelain']
dump('source_after_final.json', final_state)

receipts = json.loads((OUT / 'test_receipts.json').read_text())
static = json.loads((OUT / 'static_receipts.json').read_text())
results = []
for receipt in receipts:
    assert receipt['exit_code'] == 0
    log = (OUT / receipt['log']).read_bytes()
    assert hashlib.sha256(log).hexdigest() == receipt['log_sha256']
    text = re.sub(r'\x1b\[[0-9;]*m', '', log.decode())
    entry = dict(receipt)
    if receipt['name'] == 'cli-compiled':
        for field in ['tests', 'pass', 'fail', 'cancelled', 'skipped', 'todo']:
            match = re.search(r'^. ' + field + r' (\d+)$', text, re.M)
            assert match, (field, text[-400:])
            entry[field] = int(match[1])
    else:
        file_counts = re.search(r'Test Files\s+(\d+) passed \((\d+)\)', text)
        test_counts = re.search(r'Tests\s+(\d+) passed \((\d+)\)', text)
        assert file_counts and test_counts
        assert file_counts[1] == file_counts[2] and test_counts[1] == test_counts[2]
        entry.update(files=int(file_counts[1]), tests=int(test_counts[1]), passed=int(test_counts[1]), failed=0, skipped=0)
        coverage = {}
        for field in ['Statements', 'Branches', 'Functions', 'Lines']:
            m = re.search(field + r'\s+: ([\d.]+)% \( (\d+)/(\d+) \)', text)
            assert m, field
            coverage[field.lower()] = {'percent': float(m[1]), 'covered': int(m[2]), 'total': int(m[3])}
        entry['coverage'] = coverage
    results.append(entry)

assert sum(r['tests'] for r in results) == 763
for receipt in static:
    assert receipt['exit_code'] == 0
    assert hashlib.sha256((OUT / receipt['log']).read_bytes()).hexdigest() == receipt['log_sha256']

prior = json.loads((OUT / 'provenance_and_prior_audit_evidence.json').read_text())
paths = json.loads((OUT / 'independent_path_verification.json').read_text())

review = {
    'schema': 'ghostpay-independent-chain-interop-review/1',
    'reviewer': '/root/chain_interop_review',
    'completed_utc': final_state['utc'],
    'source': SOURCE, 'tree': TREE, 'base_main': BASE, 'donor': DONOR,
    'verdict': 'no_blocking_source_findings_in_bounded_recovery_review',
    'blocking_source_findings': [],
    'formal_github_approval': False,
    'external_cryptographic_protocol_audit': 'not_performed',
    'release_ready': False,
    'merge_qualified_by_this_review_alone': False,
    'source_unchanged_before_after': True,
    'recovered_path_count': 34, 'changed_path_count_including_claim': 35,
    'all_recovered_blobs_equal_donor': all(p['matches_donor'] for p in paths['recovered_paths']),
    'all_protected_paths_equal_base': all(p['identical'] for p in paths['preserved']),
    'cherry_pick_source_trailers_verified': 7,
    'independent_test_results': results,
    'independent_suite_case_total': 763,
    'independent_suite_cases_failed': 0,
    'independent_suite_cases_skipped': 0,
    'property_iteration_counting': 'Included within their suite test cases; not added to 763.',
    'independent_static_and_reference_results': static,
    'python_reference_counts': {'solana': {'cases': 6, 'invalid_point_checks': 12, 'transactions': 3, 'openssl': 'yes'}, 'tron': {'output': 'tron vectors OK', 'case_count_not_reported': True}},
    'author_prior_audit_evidence_not_reexecuted': prior['author_audit_receipts'],
    'remaining_gates': [
        {'gate': 'Full dependency audit', 'status': 'failed_in_author_exact_source_receipt', 'findings': {'low': 17, 'moderate': 0, 'high': 0, 'critical': 0}, 'waived': False},
        {'gate': 'Global integration lease', 'status': 'unresolved_as_reported_by_coordinator', 'modified_by_reviewer': False},
        {'gate': 'External cryptographic/protocol audit', 'status': 'not_performed'},
        {'gate': 'Hosted exact-source CI and required branch approvals', 'status': 'not_qualified_by_this_local_review'},
    ],
    'checks_not_executed_by_reviewer': [
        {'check': 'Installation and repository build', 'reason': 'Explicitly outside review scope; author supplied isolated built dependencies/dist. Existing CLI build stamp names this exact source.'},
        {'check': 'Vector regeneration', 'reason': 'Generator writes tracked vectors. Frozen vectors were instead consumed by final-source differential/property/reference tests.'},
        {'check': 'Network dependency/secret audit rerun', 'reason': 'No dependency changes; independent source scope. Prior exact-source author dependency receipts copied and hash-verified without claiming independent execution.'},
        {'check': 'Browser matrix, mobile, Tor, Pages/release artifacts', 'reason': 'Browser code/workflows/dependencies are unchanged; this is package/CLI recovery qualification, not release qualification.'},
        {'check': 'Live Solana/TRON provider or validator acceptance and real payments', 'reason': 'Outside scope; local fixtures only.'},
        {'check': 'Contracts', 'reason': 'Contract tree is unchanged.'},
        {'check': 'Hosted CI, remote reviews, merging, deployment and release', 'reason': 'Reviewer has no shared-write authority; integration lease remains unresolved.'},
    ],
    'source_review_detail': 'BEHAVIOR_REVIEW.md',
    'path_and_preservation_evidence': 'independent_path_verification.json',
    'provenance_evidence': 'provenance_and_prior_audit_evidence.json',
    'generated_coverage_retention': 'Raw lcov.info plus complete console coverage logs retained; redundant generated HTML coverage pages removed from this review packet only.',
}
dump('REVIEW.json', review)

test_rows = []
for r in results:
    name = r['name']
    detail = f"{r['tests']} passed; 0 failed; 0 skipped"
    if 'files' in r:
        detail += f"; {r['files']} files"
    test_rows.append(f"| `{name}` | {detail} | 0 | `{r['log']}` |")

md = f'''# Independent review result: chain interoperability recovery

**No blocking source finding was identified in this bounded recovery review.** All independently executed checks below passed. This result is source-pinned and is not a release-readiness claim, external protocol audit, formal GitHub approval, or a waiver of the remaining integration gates.

| Pin | Value |
|---|---|
| Candidate | `{SOURCE}` |
| Tree | `{TREE}` |
| Base main | `{BASE}` |
| Historical donor | `{DONOR}` |
| Reviewer | `/root/chain_interop_review` |
| Completed UTC | `{final_state['utc']}` |

## What was verified

All **34 recovered files** match the donor blobs exactly. The base-to-candidate diff contains **35 paths**, including the additive ownership claim. All seven original cherry-pick source SHAs are recorded in the recovered commit messages. Browser-facing packages, web source, contracts, root dependency manifests and workflows equal the pinned base. HEAD, tree and clean worktree status were checked before testing, after testing, and after this review.

The source review covered Solana codec/cluster/checksum/key validation, ADR-0017 derivation and memo compatibility, supported-set differences, TRON ADR-0019 encoding and memo construction, the unconditional refusal to produce an unbound TRON payment request, CLI network reporting and fixed legacy-format errors. Detailed behavior/path evidence is in [BEHAVIOR_REVIEW.md](BEHAVIOR_REVIEW.md); recomputed object IDs are in [independent_path_verification.json](independent_path_verification.json).

## Independently executed tests

**763 suite test cases passed, zero failed, zero skipped.** Internal property iterations and Python vector checks are not added to this test-case total.

| Suite | Actual outcome | Exit | Raw log |
|---|---|---:|---|
{chr(10).join(test_rows)}

The three Vitest commands were:

```text
npm run test --workspace @ghostpay/chain-solana -- --maxWorkers=2 --coverage.reportsDirectory=/workspace/scratch/5ceb6203640a/chain-interop-review-evidence/coverage/chain-solana
npm run test --workspace @ghostpay/chain-tron -- --maxWorkers=2 --coverage.reportsDirectory=/workspace/scratch/5ceb6203640a/chain-interop-review-evidence/coverage/chain-tron
npm run test --workspace @ghostpay/cli -- --maxWorkers=2 --coverage.reportsDirectory=/workspace/scratch/5ceb6203640a/chain-interop-review-evidence/coverage/cli
npm run test:compiled --workspace @ghostpay/cli
```

Coverage thresholds were unchanged. Statement/branch/function/line percentages were respectively:

| Workspace | Statements | Branches | Functions | Lines |
|---|---:|---:|---:|---:|
| chain-solana | 99.41% | 98.99% | 98.41% | 99.64% |
| chain-tron | 100% | 100% | 100% | 100% |
| cli | 98.62% | 97.34% | 99.07% | 99.49% |

These additional independent commands all exited **0**:

```text
npm run typecheck --workspace @ghostpay/chain-solana --workspace @ghostpay/chain-tron --workspace @ghostpay/cli
npm run lint --workspace @ghostpay/chain-solana --workspace @ghostpay/chain-tron --workspace @ghostpay/cli
python -I packages/solana-stealth/scripts/crosscheck_vectors.py test-vectors/solana-stealth.json
python -I packages/tron-adapter/scripts/crosscheck_vectors.py packages/tron-adapter/test-vectors/tron.json
```

Solana's Python output was `OK: 6 cases, 12 invalid points, 3 transactions; openssl=yes`. TRON's was `tron vectors OK`, without a reported case count. Individual receipt JSON files preserve command arrays, cwd, source SHA, start time, duration, exit code, log name and SHA-256. Node was `v24.22.3` and npm was `11.19.1`. No `NODE_OPTIONS` override was present in this reviewer process.

The compiled CLI check used existing author-built dist files. Its build-info module states this exact candidate source revision and `dirty:false`. No source edit, install or repository build was performed by the reviewer. Build-stamp tests write only their own temporary fixtures. Raw LCOV data and complete console coverage reports are retained; redundant generated HTML pages were removed from this review packet only.

## Gates still open

The **full dependency audit is not green**: the author's exact-source `npm audit --json` receipt exits 1 with **17 low, zero moderate, zero high and zero critical** findings. The production-only audit exits 0 with zero findings. Both prior logs were hash-verified against the author's receipts and copied as `author-*`; neither was independently rerun or waived. The dependency files equal the base.

The global integration lease remains unresolved as reported by the coordinator. Hosted exact-source CI, repository review/approval rules and target-head qualification must still be handled before integration. External cryptographic/protocol review remains unperformed. Browser/mobile/Tor, Pages/release artifact checks, external provider/validator acceptance, and contract tests were not run by this reviewer; their exact dispositions are machine-readable in [REVIEW.json](REVIEW.json). No unexecuted check is recorded as passed.

Solana's equal-key rejection remains an explicit accepted-set difference. TRON meta-addresses do not encode a network; format compatibility alone cannot authenticate a chain. TRON construction deliberately remains unsupported until the memo can be bound into signed bytes. These limits must remain visible during later integration.

No remote reference, PR, mainline, integration lock, deployment, release, live provider or real-payment action occurred. Preserve this review at the exact candidate; if source changes, requalify the affected code and tests.

## Evidence

- [REVIEW.json](REVIEW.json): machine-readable verdict, results, counts and skipped checks.
- [BEHAVIOR_REVIEW.md](BEHAVIOR_REVIEW.md): source reasoning and limits.
- [independent_path_verification.json](independent_path_verification.json): exact donor/preservation comparisons.
- [provenance_and_prior_audit_evidence.json](provenance_and_prior_audit_evidence.json): source history and explicitly attributed prior audits.
- `*.receipt.json`, `*.log`, `coverage/*/lcov.info`: actual independent execution receipts and raw coverage evidence.
- [MANIFEST.json](MANIFEST.json): byte sizes and SHA-256 of every packet file other than the manifest itself.
'''
(OUT / 'REVIEW.md').write_text(md)

for package in ['chain-solana', 'chain-tron', 'cli']:
    html = OUT / 'coverage' / package / 'lcov-report'
    if html.is_dir():
        shutil.rmtree(html)
    assert (OUT / 'coverage' / package / 'lcov.info').is_file()

files = []
for path in sorted(OUT.rglob('*')):
    if path.is_file() and path.name != 'MANIFEST.json':
        data = path.read_bytes()
        files.append({'path': str(path.relative_to(OUT)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
dump('MANIFEST.json', {'schema': 'ghostpay-evidence-manifest/1', 'source': SOURCE, 'tree': TREE,
                       'files': files, 'file_count': len(files), 'total_bytes': sum(f['bytes'] for f in files)})
manifest_sha = hashlib.sha256((OUT / 'MANIFEST.json').read_bytes()).hexdigest()
print(json.dumps({'packet': str(OUT), 'source': SOURCE, 'suite_cases_passed': 763, 'suite_cases_failed': 0,
                  'suite_cases_skipped': 0, 'file_count_excluding_manifest': len(files),
                  'bytes_excluding_manifest': sum(f['bytes'] for f in files), 'manifest_sha256': manifest_sha}, indent=2))

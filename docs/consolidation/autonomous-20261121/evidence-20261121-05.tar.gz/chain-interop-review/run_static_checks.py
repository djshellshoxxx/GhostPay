import concurrent.futures
import datetime
import hashlib
import json
import pathlib
import subprocess
import time

ROOT = pathlib.Path('/workspace/scratch/5ceb6203640a/GhostPay-chain-interop')
OUT = pathlib.Path(__file__).resolve().parent
SOURCE = '08ac68148861ca00b68720572afd0f22fad5dd27'

def run(job):
    name, argv = job
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    log = OUT / (name + '.log')
    with log.open('wb') as stream:
        result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=600)
    record = {'name': name, 'source': SOURCE, 'cwd': str(ROOT), 'argv': argv,
              'start_utc': start, 'duration_seconds': round(time.monotonic() - clock, 3),
              'exit_code': result.returncode, 'log': log.name,
              'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    (OUT / (name + '.receipt.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    return record

workspaces = ['--workspace', '@ghostpay/chain-solana', '--workspace', '@ghostpay/chain-tron', '--workspace', '@ghostpay/cli']
jobs = [
    ('typecheck', ['npm', 'run', 'typecheck', *workspaces]),
    ('lint', ['npm', 'run', 'lint', *workspaces]),
    ('solana-python-reference', ['python', '-I', 'packages/solana-stealth/scripts/crosscheck_vectors.py', 'test-vectors/solana-stealth.json']),
    ('tron-python-reference', ['python', '-I', 'packages/tron-adapter/scripts/crosscheck_vectors.py', 'packages/tron-adapter/test-vectors/tron.json']),
]
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(run, jobs))
(OUT / 'static_receipts.json').write_text(json.dumps(results, indent=2) + '\n')

# Independent review result: chain interoperability recovery

**No blocking source finding was identified in this bounded recovery review.** All independently executed checks below passed. This result is source-pinned and is not a release-readiness claim, external protocol audit, formal GitHub approval, or a waiver of the remaining integration gates.

| Pin | Value |
|---|---|
| Candidate | `08ac68148861ca00b68720572afd0f22fad5dd27` |
| Tree | `9cdb74017b5950ea78da3e058e6c1831003c21cc` |
| Base main | `eb59d93cffed7848c4aac37d0e9650b87239c6da` |
| Historical donor | `a92658b1ef6b95ff0145b2e1933d0047d51289d5` |
| Reviewer | `/root/chain_interop_review` |
| Completed UTC | `2026-11-21T08:05:10.706192+00:00` |

## What was verified

All **34 recovered files** match the donor blobs exactly. The base-to-candidate diff contains **35 paths**, including the additive ownership claim. All seven original cherry-pick source SHAs are recorded in the recovered commit messages. Browser-facing packages, web source, contracts, root dependency manifests and workflows equal the pinned base. HEAD, tree and clean worktree status were checked before testing, after testing, and after this review.

The source review covered Solana codec/cluster/checksum/key validation, ADR-0017 derivation and memo compatibility, supported-set differences, TRON ADR-0019 encoding and memo construction, the unconditional refusal to produce an unbound TRON payment request, CLI network reporting and fixed legacy-format errors. Detailed behavior/path evidence is in [BEHAVIOR_REVIEW.md](BEHAVIOR_REVIEW.md); recomputed object IDs are in [independent_path_verification.json](independent_path_verification.json).

## Independently executed tests

**763 suite test cases passed, zero failed, zero skipped.** Internal property iterations and Python vector checks are not added to this test-case total.

| Suite | Actual outcome | Exit | Raw log |
|---|---|---:|---|
| `chain-solana` | 111 passed; 0 failed; 0 skipped; 11 files | 0 | `chain-solana.log` |
| `chain-tron` | 54 passed; 0 failed; 0 skipped; 6 files | 0 | `chain-tron.log` |
| `cli` | 577 passed; 0 failed; 0 skipped; 37 files | 0 | `cli.log` |
| `cli-compiled` | 21 passed; 0 failed; 0 skipped | 0 | `cli-compiled.log` |

The three Vitest commands were:

```text
npm run test --workspace @ghostpay/chain-solana -- --maxWorkers=2 --coverage.reportsDirectory=/workspace/scratch/5ceb6203640a/chain-interop-review-evidence/coverage/chain-solana
npm run test --workspace @ghostpay/chain-tron -- --maxWorkers=2 --coverage.reportsDirectory=/workspace/scratch/5ceb6203640a/chain-interop-review-evidence/coverage/chain-tron
npm run test --workspace @ghostpay/cli -- --maxWorkers=2 --coverage.reportsDirectory=/workspace/scratch/5ceb6203640a/chain-interop-review-evidence/coverage/cli
npm run test:compiled --workspace @ghostpay/cli
```

Coverage thresholds were unchanged. Statement/branch/function/line percentages were respectively:

| Workspace | Statements | Branches | Functions | Lines |
|---|---:|---:|---:|---:|
| chain-solana | 99.41% | 98.99% | 98.41% | 99.64% |
| chain-tron | 100% | 100% | 100% | 100% |
| cli | 98.62% | 97.34% | 99.07% | 99.49% |

These additional independent commands all exited **0**:

```text
npm run typecheck --workspace @ghostpay/chain-solana --workspace @ghostpay/chain-tron --workspace @ghostpay/cli
npm run lint --workspace @ghostpay/chain-solana --workspace @ghostpay/chain-tron --workspace @ghostpay/cli
python -I packages/solana-stealth/scripts/crosscheck_vectors.py test-vectors/solana-stealth.json
python -I packages/tron-adapter/scripts/crosscheck_vectors.py packages/tron-adapter/test-vectors/tron.json
```

Solana's Python output was `OK: 6 cases, 12 invalid points, 3 transactions; openssl=yes`. TRON's was `tron vectors OK`, without a reported case count. Individual receipt JSON files preserve command arrays, cwd, source SHA, start time, duration, exit code, log name and SHA-256. Node was `v24.22.3` and npm was `11.19.1`. No `NODE_OPTIONS` override was present in this reviewer process.

The compiled CLI check used existing author-built dist files. Its build-info module states this exact candidate source revision and `dirty:false`. No source edit, install or repository build was performed by the reviewer. Build-stamp tests write only their own temporary fixtures. Raw LCOV data and complete console coverage reports are retained; redundant generated HTML pages were removed from this review packet only.

## Gates still open

The **full dependency audit is not green**: the author's exact-source `npm audit --json` receipt exits 1 with **17 low, zero moderate, zero high and zero critical** findings. The production-only audit exits 0 with zero findings. Both prior logs were hash-verified against the author's receipts and copied as `author-*`; neither was independently rerun or waived. The dependency files equal the base.

The global integration lease remains unresolved as reported by the coordinator. Hosted exact-source CI, repository review/approval rules and target-head qualification must still be handled before integration. External cryptographic/protocol review remains unperformed. Browser/mobile/Tor, Pages/release artifact checks, external provider/validator acceptance, and contract tests were not run by this reviewer; their exact dispositions are machine-readable in [REVIEW.json](REVIEW.json). No unexecuted check is recorded as passed.

Solana's equal-key rejection remains an explicit accepted-set difference. TRON meta-addresses do not encode a network; format compatibility alone cannot authenticate a chain. TRON construction deliberately remains unsupported until the memo can be bound into signed bytes. These limits must remain visible during later integration.

No remote reference, PR, mainline, integration lock, deployment, release, live provider or real-payment action occurred. Preserve this review at the exact candidate; if source changes, requalify the affected code and tests.

## Evidence

- [REVIEW.json](REVIEW.json): machine-readable verdict, results, counts and skipped checks.
- [BEHAVIOR_REVIEW.md](BEHAVIOR_REVIEW.md): source reasoning and limits.
- [independent_path_verification.json](independent_path_verification.json): exact donor/preservation comparisons.
- [provenance_and_prior_audit_evidence.json](provenance_and_prior_audit_evidence.json): source history and explicitly attributed prior audits.
- `*.receipt.json`, `*.log`, `coverage/*/lcov.info`: actual independent execution receipts and raw coverage evidence.
- [MANIFEST.json](MANIFEST.json): byte sizes and SHA-256 of every packet file other than the manifest itself.

import concurrent.futures
import datetime
import hashlib
import json
import pathlib
import subprocess
import time

ROOT = pathlib.Path('/workspace/scratch/5ceb6203640a/GhostPay-chain-interop')
OUT = pathlib.Path(__file__).resolve().parent
SOURCE = '08ac68148861ca00b68720572afd0f22fad5dd27'
TREE = '9cdb74017b5950ea78da3e058e6c1831003c21cc'
BASE = 'eb59d93cffed7848c4aac37d0e9650b87239c6da'
DONOR = 'a92658b1ef6b95ff0145b2e1933d0047d51289d5'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def snapshot():
    return {'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status_porcelain': git('status', '--porcelain=v1', '--untracked-files=all')}

def dump(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')

before = snapshot()
assert before['head'] == SOURCE and before['tree'] == TREE and not before['status_porcelain'], before
dump('source_before.json', before)
provenance = json.loads((OUT.parent / 'chain-interop-recovery-evidence/SOURCE_PROVENANCE.json').read_text())
paths = []
for item in provenance['paths']:
    p = item['path']
    actual = {'path': p, 'source_blob': git('rev-parse', SOURCE + ':' + p),
              'donor_blob': git('rev-parse', DONOR + ':' + p)}
    actual['matches_donor'] = actual['source_blob'] == actual['donor_blob']
    actual['matches_author_record'] = actual['source_blob'] == item['recovered_blob'] and actual['donor_blob'] == item['donor_blob']
    assert actual['matches_donor'] and actual['matches_author_record'], actual
    paths.append(actual)
changed = git('diff', '--name-only', BASE, SOURCE).splitlines()
assert set(changed) == {p['path'] for p in paths} | {'docs/ai/ACTIVE_WORK.md'}
preserved = []
for p in ['packages/solana-stealth', 'packages/tron-adapter', 'apps/web', 'package.json', 'package-lock.json', '.github/workflows', 'packages/contracts']:
    record = {'path': p, 'base_tree_or_blob': git('rev-parse', BASE + ':' + p), 'source_tree_or_blob': git('rev-parse', SOURCE + ':' + p)}
    record['identical'] = record['base_tree_or_blob'] == record['source_tree_or_blob']
    assert record['identical'], record
    preserved.append(record)
dump('independent_path_verification.json', {'source': SOURCE, 'tree': TREE, 'base': BASE, 'donor': DONOR, 'changed_paths': changed, 'recovered_paths': paths, 'preserved': preserved})

def run(name, argv):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    clock = time.monotonic()
    log = OUT / (name + '.log')
    with log.open('wb') as stream:
        result = subprocess.run(argv, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=1800)
    rec = {'name': name, 'source': SOURCE, 'cwd': str(ROOT), 'argv': argv,
           'start_utc': start, 'duration_seconds': round(time.monotonic() - clock, 3),
           'exit_code': result.returncode, 'log': log.name,
           'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
    dump(name + '.receipt.json', rec)
    print(json.dumps(rec), flush=True)
    return rec

jobs = []
for pkg in ['chain-solana', 'chain-tron', 'cli']:
    jobs.append((pkg, ['npm', 'run', 'test', '--workspace', '@ghostpay/' + pkg, '--', '--maxWorkers=2', '--coverage.reportsDirectory=' + str(OUT / 'coverage' / pkg)]))
jobs.append(('cli-compiled', ['npm', 'run', 'test:compiled', '--workspace', '@ghostpay/cli']))
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    receipts = list(pool.map(lambda job: run(*job), jobs))
after = snapshot()
dump('source_after_tests.json', after)
assert after['head'] == SOURCE and after['tree'] == TREE and not after['status_porcelain'], after
dump('test_receipts.json', receipts)
print('SOURCE_UNCHANGED', flush=True)

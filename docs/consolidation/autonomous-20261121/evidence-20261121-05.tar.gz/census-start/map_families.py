import collections
import gzip
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path('/workspace/scratch/5ceb6203640a')
REPO = ROOT / 'GhostPay'
OUT = ROOT / 'recovery-evidence'
BASE = 'aec179910c39081d820396409ff3139ff2264132'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode()

def tree(ref):
    result = {}
    for row in git('ls-tree', '-rz', ref).split('\0'):
        if row:
            metadata, path = row.split('\t', 1)
            result[path] = metadata.split()[2]
    return result

def family(paths):
    names = set()
    for path in paths:
        p = path.lower()
        if 'sellerkeys' in p or 'keyvault' in p or 'backup' in p or 'recovery' in p or '/ux-vault/' in p:
            names.add('Key custody and recovery')
        if 'idle' in p or '/session' in p:
            names.add('Session and idle authority')
        if '/policy/' in p or '/policy-scheme/' in p:
            names.add('Policy payments and recovery')
        if 'wallet' in p or 'retention' in p or 'clipboard' in p or 'privacy' in p:
            names.add('Wallet disclosure and privacy')
        if 'requestfile' in p or 'paymentrequest' in p or 'invoice' in p:
            names.add('Invoice interchange and validation')
        if 'sweep' in p:
            names.add('Sweep safety and journals')
        if 'scan' in p:
            names.add('Scanning and payment evidence')
        if '/tron' in p:
            names.add('TRON validation')
        if '/btc' in p or 'bitcoin' in p:
            names.add('Bitcoin adapter and consent')
        if '/hygiene' in p:
            names.add('Hygiene evidence and reuse warnings')
        if 'embed' in p:
            names.add('Embedded checkout')
        if 'camera' in p or 'qr' in p:
            names.add('QR and camera privacy')
        if 'tor' in p or 'onion' in p or 'hosting' in p:
            names.add('Tor and static hosting')
        if '/.github/' in '/'+p or '/package.json' in p or p in ['package.json','package-lock.json']:
            names.add('CI and dependencies')
        if '/coordination/' in p or '/automation/' in p:
            names.add('Coordination tooling')
    return sorted(names or {'Other source or tests'})

data = json.loads((OUT/'live-comparisons.json').read_text())
branches = data['branches']
prs = json.loads((OUT/'open-prs.json').read_text())['prs']
pr_by_branch = {p['branch']: p for p in prs}
pr_by_head = collections.defaultdict(list)
for p in prs:
    pr_by_head[p['head']].append(p)
active_ancestors = {p['number']: set(git('rev-list', p['head']).splitlines()) for p in prs}
active_trees = {p['number']: tree(p['head']) for p in prs}
main_tree = tree(BASE)
manual = {
 'codex/ghostpay-cloud-41868394956': ('Semantically redundant', 'Main validates every line-item array slot with Array.from and includes the sparse-slot regressions; historical source/test additions are preserved with newer hardening.'),
 'claude/happy-maxwell-onl4x5': ('Superseded', 'Main preserves existing report read permissions, uses lstat/fchmod, and caps mode at 0644; the older chmod/umask patch and its regression are already incorporated with stronger restrictions.'),
 'claude/vigilant-johnson-yjgq94': ('Semantically redundant', 'Main Settings tests already assert both the unverified-download warning and verified-keystore requirement.'),
 'chatgpt/ghostpay-rpc-filter-guard-20261114': ('Semantically redundant', 'Main scanSpam checks exact token address and requested block interval before counting Transfer logs; remaining blob differences are newer main changes.'),
 'chatgpt/zero-codex/pages-owner-transfer-filter-20261115': ('Semantically redundant', 'Main scanSpam already implements token and interval rejection and contains the corresponding historical tests.'),
 'chatgpt/zero-codex/pages-scan-transfer-filter-20261114': ('Semantically redundant', 'Main scanSpam already implements token and interval rejection and contains the corresponding historical tests.'),
 'fix/remediation-b16c7936-5ce634': ('Superseded', 'Main already passes pageMatches to persistable and replays claimed router records once above the resume floor. The historical patch lacks the later anti-pinning floor guard.'),
 'fix/remediation-f95457fd-22ecf9': ('Superseded', 'Main send.test.ts explicitly records rejection of this remediation: journal keys have no version, so treating every other payment as legacy blocks legitimate distinct payments. Do not restore the rejected patch.'),
 'chatgpt/zero-codex/pages-tagarchive-blocked-click-20261117': ('Experimental or deferred', 'Test-only TagArchive change remains outside the accepted lean Pages surface; prior handoff records paused PR193. Revisit only with the feature owner, preserving current Common.downloadBlob cleanup.'),
 'automation/ghostpay-integration-lock': ('Documentation or evidence only', 'Operational metadata tree contains only integration-lock.json. The apparent code diff consists of source-tree deletions; never merge this ref into main.'),
 'automation/ghostpay-recurrent-backlog-20261103': ('Experimental or deferred', 'Historical paid/API-funded recurring workflow is outside the browser-beta consolidation target. Preserve without activating scheduled spending.'),
 'codex/setup-autonomous-agent-20261104': ('Experimental or deferred', 'Historical API-funded automation setup is outside the browser-beta consolidation target. Preserve without enabling it.'),
 'fix/ghostpay-cloud-api-secret-aliases-20261103': ('Experimental or deferred', 'Historical secret-name workflow repair belongs to the deferred API-funded automation family; no browser feature is added.'),
 'dependabot/github_actions/actions-b9ade1236b': ('Blocked by dependencies', 'Existing PR207 contains workflow dependency updates and requires current workflow/security CI qualification. Do not treat configuration as documentation-only.'),
 'chatgpt/ghostpay-rpc-filter-guard-beta-20261114': ('Semantically redundant', 'Main retains bounded streaming response reads, byte budgets, best-effort cancellation and the associated relayer tests; main also contains the off-filter RPC guards.'),
 'chatgpt/pages-browser-fixes-combined-20261114': ('Semantically redundant', 'Same exact head as the historical RPC-filter beta branch; bounded relayer reads, their regressions and off-filter RPC checks are already in main.'),
 'chatgpt/zero-codex/pages-qr-combined-20261115': ('Semantically redundant', 'Main retains the bounded relayer/RPC fixes and secret-or-bearer precedence over caution flags, with the corresponding QR regression assertions and newer runtime guards.'),
 'automation/20261120T0035Z/worker/qr-kind-primitives': ('Superseded', 'The non-string QR guard is recovered in existing PR290 and broad PR307, with reworked and expanded regressions in PR295. Preserve provenance; qualify the existing integration instead of applying this older test version.'),
}
records = []
for b in branches:
    item = {k: b.get(k) for k in ['name','sha','comparison_base','merge_base','ahead','behind','file_count','status','classification','classification_reason']}
    item['family'] = family([f['path'] for f in b['files']]) if b['files'] else []
    own = pr_by_branch.get(b['name'])
    item['open_pr'] = own['number'] if own else None
    item['open_pr_base'] = own['base'] if own else None
    descendants = [p['number'] for p in prs if b['sha'] != p['head'] and b['sha'] in active_ancestors[p['number']]]
    item['active_descendant_prs'] = descendants
    if b['status'] == 'code-candidate' and b['name'] != 'automation/ghostpay-integration-lock':
        bt = tree(b['sha'])
        changed = [f['path'] for f in b['files'] if f['kind'] == 'code' and not f['path'].endswith(('.md','.txt'))]
        item['matching_changed_source_prs'] = [p['number'] for p in prs if p['head'] != b['sha'] and all(bt.get(path)==active_trees[p['number']].get(path) for path in changed)]
        item['unmatched_code_paths'] = b['unmatched_code_paths']
        item['review_status'] = 'semantic-review-pending'
        if own:
            item['next_action'] = f"Continue existing PR #{own['number']}; inspect current parent/child gates and ownership before edits."
        elif item['matching_changed_source_prs']:
            item['next_action'] = 'Recover through an existing PR with the same changed source blobs; do not create a duplicate implementation.'
        elif descendants:
            item['next_action'] = 'Inspect retained behavior in active descendant PRs before any historical cherry-pick; ancestry alone is not semantic proof.'
        else:
            item['next_action'] = 'Review unique commit patches against current behavior and tests; no merge readiness has been established.'
    else:
        item['review_status'] = 'ancestry-or-tree-classified'
    if b['name'] in manual:
        item['classification'], item['classification_reason'] = manual[b['name']]
        item['review_status'] = 'scoped-source-review-complete'
    records.append(item)

summary = {
 'schema': 'ghostpay-exact-main-branch-census/1',
 'baseline_main': BASE,
 'captured_at': json.loads((OUT/'live-branches.json').read_text())['captured_at'],
 'branch_pagination': [100,100,100,100,37,0],
 'open_pr_pagination': [100,35,0],
 'branch_count': len(records),
 'open_pr_count': len(prs),
 'ancestry_counts': {'already_incorporated':sum(r['ahead']==0 for r in records),'ahead':sum((r['ahead'] or 0)>0 for r in records),'unrelated':sum(r['status']=='unrelated' for r in records)},
 'original_heuristic_counts': {'code_path_candidates':175,'docs_directory_only':66,'other_noncode':6},
 'classification_counts':dict(collections.Counter(r['classification'] or 'Pending semantic review' for r in records)),
 'branches':records,
 'limitations': [
  'The snapshot is frozen, not a claim about later branch heads or main.',
  'Ancestry, exact blob matches and scoped source review are distinguished; no test or feature-completion status is inferred.',
  'Pending semantic review is intentionally explicit and must not be renamed to a completed classification without evidence.',
  'Operational metadata and gh-pages histories are excluded from source integration.',
  'Code-path heuristics also include documentation under packages; original census categories are useful triage, not semantic classifications.'
 ]
}
(OUT/'branch-census-final.json').write_text(json.dumps(summary,indent=2)+'\n')
raw=(OUT/'live-comparisons.json').read_bytes()
compressed=gzip.compress(raw,mtime=0)
(OUT/'branch-comparisons.json.gz').write_bytes(compressed)
manifest={'path':'branch-comparisons.json.gz','compression':'gzip','compressed_bytes':len(compressed),'compressed_sha256':hashlib.sha256(compressed).hexdigest(),'uncompressed_bytes':len(raw),'uncompressed_sha256':hashlib.sha256(raw).hexdigest(),'branches':len(records),'main':BASE}
(OUT/'branch-comparisons-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'counts':summary['classification_counts'],'artifact':manifest},indent=2))
print('Unowned unmatched branches:')
for r in records:
    if r['classification'] is None and not r['open_pr'] and not r.get('matching_changed_source_prs') and not r['active_descendant_prs']:
        print(r['name'],r['sha'],len(r.get('unmatched_code_paths',[])))

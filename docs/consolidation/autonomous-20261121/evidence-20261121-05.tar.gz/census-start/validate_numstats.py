import json
import pathlib
import subprocess

REPO = pathlib.Path('/workspace/scratch/5ceb6203640a/GhostPay')
OUT = REPO.parent / 'recovery-evidence'
CENSUS = '0d8437c1097fad30d505c343ce4da356350ea4c3'
BASE = 'aec179910c39081d820396409ff3139ff2264132'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

paths = git('diff', '--name-only', BASE, CENSUS).decode().splitlines()
rows = [r for p in paths if '/BRANCH_COMPARE_R7_' in p for r in json.loads(git('show', CENSUS+':'+p))['results']]
pins = {r['branch']: r['sha'] for r in json.loads(git('show', CENSUS+':docs/handoffs/BRANCH_HEADS_R7_20261121.json'))['source_head_shas']}
mismatches = []
checked = 0
for row in rows:
    if 'merge_base' not in row:
        continue
    head = pins[row['branch']]
    if row['branch'] == 'automation/20261119T073600Z/bug/camera-visibility':
        head = git('rev-parse', head+'^1').decode().strip()
    raw = git('diff', '--numstat', '-z', '-M', row['merge_base'], head).decode()
    parts = raw.split('\x00')
    stats = {}
    i = 0
    while i < len(parts) and parts[i]:
        add, delete, path = parts[i].split('\t', 2)
        i += 1
        if not path:
            old, path = parts[i:i+2]
            i += 2
        stats[path] = (int(add) if add != '-' else 0, int(delete) if delete != '-' else 0)
    for path, status, add, delete in row['files']:
        checked += 1
        if stats.get(path) != (add, delete):
            mismatches.append({'branch': row['branch'], 'head': head, 'path': path, 'recorded': [add, delete], 'git': stats.get(path)})
result = {'reviewed_census_head': CENSUS, 'comparison_base': BASE, 'checked_file_rows': checked, 'mismatches': mismatches}
(OUT/'historical-numstat-validation.json').write_text(json.dumps(result, indent=2)+'\n')
print('checked', checked, 'mismatches', len(mismatches))
print(json.dumps(mismatches[:25], indent=2))

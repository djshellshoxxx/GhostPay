# Chain interoperability recovery handoff

## Result and frozen source

Recovered the missing CLI-side Solana/TRON interoperability work and the unsupported TRON request-construction refusal into an isolated branch. The complete affected executable suites passed: **763 tests**, zero failures and zero skips. The all-dependency audit reported **17 existing low findings** in development contract tooling; it did not pass. Independent source review and repository integration ownership are still unresolved. This packet does not qualify a release or a merge.

- Branch: `recover/ghostpay-chain-interop-20261121-5ceb`
- Starting and ending verified main: `eb59d93cffed7848c4aac37d0e9650b87239c6da`
- Candidate head: `08ac68148861ca00b68720572afd0f22fad5dd27`
- Candidate tree: `9cdb74017b5950ea78da3e058e6c1831003c21cc`
- Historical PR #211 donor: `a92658b1ef6b95ff0145b2e1933d0047d51289d5`
- Worktree: `/workspace/scratch/5ceb6203640a/GhostPay-chain-interop`
- Changed paths: **35 total**, comprising 34 recovered paths that exactly match the donor and one additive claim in `docs/ai/ACTIVE_WORK.md`.

`SOURCE_PROVENANCE.json` records each recovered path's base, candidate and donor blob and original commit trailers. `HANDOFF.json` records all changed paths, checks, outcomes, skipped qualification and next actions. Tracked source remained clean and unchanged through qualification.

## Recovered behavior

Solana's CLI-side package now follows the existing ADR-0017/browser format: cluster-bound `st:sol:` meta-addresses, the same shared-point and hash derivation, and `gpst1:` base58 memos. Metadata unsupported by that memo is refused. Adapter recipients are bound to the selected devnet/testnet cluster. The CLI reports the encoded cluster and refuses mainnet. Retired `gpsol:` input receives the fixed `LEGACY_META_ADDRESS` error.

The CLI-side TRON package now accepts `st:trx:0x` meta-addresses and produces the matching GPT1 announcement memo. The adapter can validate and quote an input, but its `build()` method always refuses with `MEMO_NOT_BOUND`: this package cannot bind the memo into the signed transaction bytes. This preserves a documented construction limit; it does not implement TRON sending.

The existing browser packages `packages/solana-stealth` and `packages/tron-adapter`, `apps/web`, contracts, workflows and root manifests/lockfile remain byte-identical to main. They retain their newer isolation, cancellation and network-validation work. No fee, custody, provider or protocol contract changed. The only CLI changes are its chain-command fixtures, cluster reporting and fixed legacy-format error propagation.

The Solana accepted sets deliberately retain one documented distinction: this CLI package rejects equal spending/viewing public keys, while the existing browser decoder accepts them. Shared tests record the distinction. Retired formats are rejected rather than automatically migrated; no historic fund-recovery guarantee is made.

## Provenance and ownership

Seven commits were selectively recovered with `git cherry-pick -x`:

- `e2427c20387aa2e228309c49a1558d3edc6583ce` — shared vectors and generator.
- `179a5b433f35396ca4f0961c99226dbb38e4e4cd` — Solana interoperability.
- `28ce8a0b6fe22458505da6a77ae7c7cf81db8864` — TRON interoperability.
- `c3d7d70207f74df4a6857231647dcf1ab87122c5` — CLI format fixtures.
- `b9af22a9c85c6a8674d8ac72d7f038954ce713b9` — TRON construction refusal.
- `67a3c3c0f305eb0f82414c3623300a81afd59cc3` — CLI Solana cluster reporting.
- `b79bb24a81e254b3ca06501c8669c54403a19f0a` — fixed legacy-format error propagation.

The selected TRON README blob originated in `90146562b7f7809746966edbedccb4a4e68e8a68` and matches final donor `a92658b1ef6b95ff0145b2e1933d0047d51289d5`. Other donor documentation and web-facing changes were excluded. The original PR #211 and #218 branches were untouched. Before recovery, the scoped current-main files matched the first donor commit's parent; #218's three relevant CLI files already matched current main. The donor registry stated no lane worker remained active. PR #369's web-facing TRON work owns different paths.

The final live ref check returned main `eb59d93cffed7848c4aac37d0e9650b87239c6da`, donor `a92658b1ef6b95ff0145b2e1933d0047d51289d5`, and lock branch `6edfcd4dfb85c29e11aa0dee9fa0dabcc5b0ac79`. The integration lock remains held by the previous owner `994a0d214fb9-root-r3`. This worker performed no remote mutation, shared-branch update or merge.

## Executed checks

Environment: Node v24.22.3, npm 11.19.1. Dependencies were installed in a new real directory using `npm ci --ignore-scripts`, with no shared dependency symlink. Every listed test/build/reference check ran against frozen candidate `08ac68148861ca00b68720572afd0f22fad5dd27`. Installation occurred at the preceding claim commit; manifests and lockfile were unchanged. Per-command receipts preserve timestamps, duration, return code and source SHAs. Raw logs are SHA-256 indexed.

| Exact command | Exit | Observed result | Receipt |
|---|---:|---|---|
| `npm run lint --workspace @ghostpay/chain-solana --workspace @ghostpay/chain-tron --workspace @ghostpay/cli` | 0 | Exit 0 | `affected-lint.json` |
| `npm run typecheck --workspace @ghostpay/chain-solana --workspace @ghostpay/chain-tron --workspace @ghostpay/cli` | 0 | Exit 0 | `affected-typecheck.json` |
| `npm run build:libs` | 0 | Exit 0 | `build-libs.json` |
| `npm run test --workspace @ghostpay/chain-solana -- --maxWorkers=2` | 0 | 111 tests, 11 files; no failures or skips | `chain-solana-coverage.json` |
| `npm run test --workspace @ghostpay/chain-tron -- --maxWorkers=2` | 0 | 54 tests, 6 files; no failures or skips | `chain-tron-coverage.json` |
| `npm run test:compiled --workspace @ghostpay/cli` | 0 | 21 tests; no failures, cancellations or skips | `cli-compiled.json` |
| `npm run test --workspace @ghostpay/cli -- --maxWorkers=2` | 0 | 577 tests, 37 files; no failures or skips | `cli-coverage.json` |
| `npm audit --json` | 1 | FAILED: 17 low; 0 moderate/high/critical | `full-dependency-audit.json` |
| `git ls-remote origin refs/heads/main refs/heads/automation/ghostpay-integration-lock refs/heads/nodata/wonderful-darwin-kd1h22` | 0 | Main and donor unchanged | `live-ref-check.json` |
| `npm ci --ignore-scripts` | 0 | 722 packages; isolated real node_modules; scripts disabled | `npm-ci.json` |
| `npm audit --omit=dev --json` | 0 | 0 vulnerabilities | `production-audit.json` |
| `npm ls --all --omit=dev` | 0 | Exit 0 | `production-dependency-tree.json` |
| `npm run ci:scan-secrets` | 0 | Exit 0 | `secret-scan.json` |
| `python -I packages/solana-stealth/scripts/crosscheck_vectors.py test-vectors/solana-stealth.json` | 0 | 6 cases, 12 invalid points, 3 transactions; OpenSSL=yes | `solana-python-vectors.json` |
| `git bundle verify /workspace/scratch/5ceb6203640a/chain-interop-recovery-evidence/chain-interop-08ac6814.bundle` | 0 | Bundle valid; main prerequisite required | `source-bundle-verification.json` |
| `python -I packages/tron-adapter/scripts/crosscheck_vectors.py packages/tron-adapter/test-vectors/tron.json` | 0 | tron vectors OK | `tron-python-vectors.json` |

### Coverage

| Package | Statements | Branches | Functions | Lines |
|---|---:|---:|---:|---:|
| chain-solana | 99.41% (339/341) | 98.99% (197/199) | 98.41% (62/63) | 99.64% (281/282) |
| chain-tron | 100% (166/166) | 100% (105/105) | 100% (38/38) | 100% (139/139) |
| CLI | 98.62% (2359/2392) | 97.34% (1800/1849) | 99.07% (323/326) | 99.49% (1963/1973) |

Original coverage thresholds and assertions were preserved. Package suites include shared/static vectors and ordinary cross-implementation properties, including 25 generated round trips per chain. Those iterations are already included in suite results. The existing Python scripts independently implement the reference calculations, but execution by this worker is not independent human or agent source review. No vulnerable-source execution or live-network payment occurred.

## Remaining qualification

- Fresh independent source review of the exact head remains pending.
- External cryptographic/protocol review has not occurred; ADR/proposed/testnet restrictions remain.
- Full `npm audit --json` failed with 17 low findings in the unchanged Hardhat/FHE development tooling graph, including cookie and elliptic roots. Production-only audit returned zero. Dependency-owner triage remains outside this lane; this worker changed no dependencies.
- Candidate GitHub Actions, Pages/browser/mobile/Tor and contract execution were not run in this lane. App, browser runtime packages, workflows and contract files were preserved; the integrator decides applicable broader candidate gates.
- Repository integration ownership must be reconciled before any shared-target update or merge. Branch protection, exact-head CI and external/independent approval requirements remain in force.
- No release, deployment, real-funds operation or automatic legacy-format migration was performed.

Historical commit messages and copied package READMEs contain earlier test reports. They are provenance only. This packet's raw logs are the evidence for executions in this recovery.

## Recoverability and next owner

`chain-interop-08ac6814.bundle` is an incremental bundle with prerequisite `eb59d93cffed7848c4aac37d0e9650b87239c6da` and candidate branch `08ac68148861ca00b68720572afd0f22fad5dd27`. Verification passed.

- Size: 59,247 bytes.
- SHA-256: `38b433e1a13d4405faecc1225db8d828ee161305a54ae71189fed6cf9c9f502f`.

The parent integration worker should persist this complete packet in the authoritative repository ledger, assign a fresh reviewer, resolve existing #211/#218 disposition and integration ownership, and run applicable exact-candidate remote qualification before considering a merge. Source is frozen; no new worker should update it without notifying the reviewer and invalidating affected evidence.

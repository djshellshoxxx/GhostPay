from pathlib import Path
import subprocess, json, time, datetime, sys, hashlib, os

root = Path('/workspace/scratch/5ceb6203640a/GhostPay-chain-interop')
evidence = root.parent / 'chain-interop-recovery-evidence'
name, relative, *command = sys.argv[1:]
cwd = root / relative
before = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip()
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
t = time.monotonic()
log = evidence / (name + '.log')
environment = dict(os.environ)
environment['NODE_OPTIONS'] = '--max-old-space-size=2048'
with log.open('w') as handle:
    result = subprocess.run(command, cwd=cwd, stdout=handle, stderr=subprocess.STDOUT, env=environment)
after = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
receipt = {
    'command': command, 'cwd': str(cwd), 'started_at': started,
    'elapsed_seconds': round(time.monotonic() - t, 3), 'exit_code': result.returncode,
    'source_before': before, 'source_after': after, 'tree_before': tree,
    'tree_after': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip(),
    'tracked_status_after': subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=root, text=True),
    'environment_override': {'NODE_OPTIONS': environment['NODE_OPTIONS']},
    'log': log.name, 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()
}
(evidence / (name + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
if before != after:
    raise SystemExit('Source moved during check.')
raise SystemExit(result.returncode)

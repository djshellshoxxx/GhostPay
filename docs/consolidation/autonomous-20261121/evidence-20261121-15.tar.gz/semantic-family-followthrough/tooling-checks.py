import subprocess
paths = [
    "packages/pool-circuits/scripts/install-circom.sh",
    "scripts/integration/run-in-runner.sh",
]
for path in paths:
    subprocess.run(["bash", "-n", path], check=True)
    print("bash -n " + path + ": PASS")
subprocess.run(["node", "/workspace/scratch/5ceb6203640a/semantic-family-followthrough-evidence/compare-ts.mjs"], check=True)

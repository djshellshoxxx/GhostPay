from pathlib import Path
import datetime
import hashlib
import json
import re
import subprocess
import time

REPO = Path('/workspace/scratch/5ceb6203640a/GhostPay-native-browsers')
OUT = Path(__file__).parent
BASE = '2eeae61efd83d28554003e6a4a618c39949b9d50'
HEAD = 'dab622cad070dfd6e5b2a48a1fe81ee6d6d13cc0'
TREE = 'b682a8eb262921d82f0d49d243005d8461a8a706'
SCRIPT = 'scripts/tor/browser-acceptance.mjs'
OLD = 'Scan privacy settings saved. They apply to the next scan.'
NEW = 'Network privacy settings saved. Pending network operations were cancelled; start a new action to use these settings.'

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def sha(data):
    return hashlib.sha256(data).hexdigest()

def entries(ref):
    result = {}
    for entry in git('ls-tree', '-r', '-z', ref).split(b'\0'):
        if entry:
            identity, path = entry.split(b'\t', 1)
            result[path.decode()] = identity.decode()
    return result

before = {'head': git('rev-parse', 'HEAD').decode().strip(),
          'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
          'status': git('status', '--short').decode()}
assert before['head'] == HEAD and before['tree'] == TREE
a, b = entries(BASE), entries(HEAD)
changed = sorted(p for p in a.keys() | b.keys() if a.get(p) != b.get(p))
assert changed == ['docs/ai/ACTIVE_WORK.md',
                   'docs/ai/claims/TOR_SAVE_MESSAGE_FIXTURE_20261121_5CEB.md', SCRIPT]
old_script = git('show', BASE + ':' + SCRIPT)
new_script = git('show', HEAD + ':' + SCRIPT)
assert old_script.count(OLD.encode()) == 1
assert old_script.replace(OLD.encode(), NEW.encode()) == new_script
assert new_script.count(OLD.encode()) == 0
catalog = json.loads(git('show', HEAD + ':apps/web/locales/en.json'))
assert catalog['messages']['settings.scanPrivacy.saved'] == NEW
settings = git('show', HEAD + ':apps/web/src/views/Settings.tsx').decode()
handler = settings[settings.index('function ScanPrivacySection()'):]
assert handler.index('services.network?.invalidate();') < handler.index("setMessage(saved ? { kind: 'ok', text: { key: 'settings.scanPrivacy.saved' }")
authority = git('show', HEAD + ':apps/web/src/lib/networkAuthorization.ts').decode()
assert 'for (const cancel of [...active]) cancel();' in authority
assert 'revision++;' in authority[authority.index('const invalidate = (): void => {'):]

commands = []
for name, command in [
    ('node-syntax', ['node', '--check', SCRIPT]),
    ('whitespace', ['git', 'diff', '--check', BASE, HEAD]),
]:
    start = time.monotonic()
    result = subprocess.run(command, cwd=REPO, capture_output=True)
    log = result.stdout + result.stderr
    (OUT / (name + '.log')).write_bytes(log)
    commands.append({'command': command, 'cwd': str(REPO), 'exit_code': result.returncode,
                     'elapsed_seconds': round(time.monotonic() - start, 6),
                     'log': name + '.log', 'log_sha256': sha(log)})
    assert result.returncode == 0

log_root = Path('/workspace/scratch/5ceb6203640a/GhostPay-ledger/docs/consolidation/autonomous-20261121/hosted-qualification')
hosted = []
for filename, pr, run, job in [('recovery-tor-failure.log', 372, 44879664025, 136771948240),
                               ('native-tor-failure.log', 373, 44880440168, 136774369027)]:
    data = (log_root / filename).read_bytes()
    text = data.decode()
    assert 'locator.waitFor: Timeout 30000ms exceeded.' in text
    assert "waiting for getByText('" + OLD + "', { exact: true })" in text
    assert 'scripts/tor/browser-acceptance.mjs:81:104' in text
    assert 'Process completed with exit code 1.' in text
    hosted.append({'pr': pr, 'run': run, 'job': job, 'log': str(log_root / filename),
                   'sha256': sha(data), 'observed_result': 'failure at obsolete exact saved-message assertion'})

after = {'head': git('rev-parse', 'HEAD').decode().strip(),
         'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
         'status': git('status', '--short').decode()}
assert before == after
preserved = {label: sum(p.startswith(prefix) for p in b)
             for label, prefix in [('application', 'apps/'), ('packages', 'packages/'),
                                   ('github_configuration', '.github/')]}
for p in b:
    if p.startswith(('apps/', 'packages/', '.github/')):
        assert a.get(p) == b[p]
result = {'reviewer': '/root/tor_fixture_review',
          'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'base': BASE, 'head': HEAD, 'tree': TREE, 'source_before': before, 'source_after': after,
          'changed_paths': changed, 'unchanged_tree_entries': len(b) - len(changed),
          'preserved_root_entry_counts': preserved,
          'fixture_before_blob': a[SCRIPT], 'fixture_after_blob': b[SCRIPT],
          'fixture_change_is_exact_single_message_replacement': True,
          'assert_call_count_before': len(re.findall(rb'\bassert(?:\.[A-Za-z]+)?\(', old_script)),
          'assert_call_count_after': len(re.findall(rb'\bassert(?:\.[A-Za-z]+)?\(', new_script)),
          'exact_current_catalog_message': NEW,
          'save_handler_calls_network_invalidation_before_saved_message': True,
          'network_invalidation_cancels_active_work_and_advances_revision': True,
          'commands': commands, 'hosted_failure_sources': hosted,
          'browser_tests_executed': 0, 'blocking_findings_in_scope': [],
          'qualification_limit': 'Static/source verification only. Corrected hosted browser execution remains required. No Tor Browser, onion routing, deployment, wallet or real-funds acceptance is established.'}
(OUT / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'head': HEAD, 'static_checks': len(commands), 'changed_paths': len(changed),
                  'preserved': preserved, 'unchanged_tree_entries': result['unchanged_tree_entries'],
                  'assert_calls': result['assert_call_count_after'], 'browser_tests_executed': 0}))

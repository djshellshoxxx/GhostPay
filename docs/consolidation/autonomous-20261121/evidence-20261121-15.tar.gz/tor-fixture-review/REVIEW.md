# Independent Tor static-hosting fixture review

## Decision

No blocking finding in the bounded source correction at `dab622cad070dfd6e5b2a48a1fe81ee6d6d13cc0`, tree `b682a8eb262921d82f0d49d243005d8461a8a706`, compared with `2eeae61efd83d28554003e6a4a618c39949b9d50`.

The two preserved hosted logs—#372 run `44879664025` / job `136771948240`, and #373 run `44880440168` / job `136774369027`—both show a 30-second timeout at line 81 waiting for the obsolete exact save message. The replacement exactly matches the current English `settings.scanPrivacy.saved` catalog entry. The current Settings handler calls `services.network?.invalidate()` before setting that saved message; the authority implementation advances its revision and invokes every active cancellation callback. This establishes the source rationale, not fresh browser execution.

## Verification

- `node --check scripts/tor/browser-acceptance.mjs`: exit 0.
- `git diff --check 2eeae61efd83d28554003e6a4a618c39949b9d50 dab622cad070dfd6e5b2a48a1fe81ee6d6d13cc0`: exit 0.
- The entire script is byte-identical to its predecessor after replacing the one old expected message with the new one. All 19 `assert` calls remain unchanged. Exact text matching remains enabled. No timeout, routing rule, egress restriction, integrity handling, saved-transport check or generation check changed.
- All 708 application entries, 2,226 package entries and 23 GitHub configuration entries are byte-identical to the prior reviewed source, including native browser configuration and workflow. Across the complete tree, 5,764 entries are unchanged. The only three changed paths are the one assertion and two ownership documents.
- HEAD, tree and working status remained identical before and after checks. The pre-existing untracked `node_modules` link was not modified.

The reproducible checker and exact commands, source identities, raw-log hashes and results are in `review_checks.py` and `verification.json`.

## Boundaries and handoff

Zero browser tests were executed by this reviewer. Corrected hosted static-browser acceptance remains required; this does not establish Tor Browser, live onion routing, physical-device, wallet or real-funds qualification. No source edit, dependency installation/build, remote mutation, integration lease change, merge, deployment or release was performed. This is an independent AI-worker review, not formal GitHub approval or an external audit. The generation-11 ownership hold remains unchanged.

Root may use this review for its isolated #373 correction; it does not authorize updating a shared parent or main. This bounded review is complete.

# Semantic family followthrough — bounded source review

This packet closes **10 inherited source-review obligations** and preserves **7 pending records**. It considers 17 exact branch records, completes bounded source review for 14 of them, and stages three broad donors for a fresh reviewer. Applied after the preceding 26-record packet, the inherited pending count becomes **110 → 100**. This is a review overlay, not a competing authoritative ledger and not a merge approval.

The baseline main is `eb59d93cffed7848c4aac37d0e9650b87239c6da`. Most successor comparisons and every independent unit test used recovery `783231a46840cd869e39bd704751d4ab4c349c45`, tree `65e5cc6fdb7ab3337951ba0b0b58e87b71df095b`. Every selected source pin matches the 445-branch census captured at 2026-11-21T08:09:54.353Z. All 17 records are disjoint from the preceding 26-record and six-record review packets. Later GitHub changes require root refresh before application or integration.

## Dispositions

| Original PR | Exact source | Family | Review disposition |
|---|---|---|---|
| #316 | `e0c583be2514b44af7f3b15619fb8160358f1470` | Receipt and invoice print isolation | Closed source obligation |
| No open PR | `d5fe06e7a7b383da1726c4d38165c824e996b9db` | Sleep-aware idle locking and sole-copy authority separation | Closed source obligation |
| #231 | `d9ff386807de724eb1a1c4d400c882df0fc20bb7` | Sweep explicit balance consent and asynchronous quote ownership | Closed source obligation |
| #217 | `9e5cc3789b7b8a3c550ed2680304ab6245ec6676` | Non-Pages flat-fee deployment acknowledgement | Closed source obligation |
| #219 | `9617e8572f9bc414410bd937b0e7718d0c5bd55c` | Bitcoin local spentness, retained history and optional disclosure | Pending selective BTC correction |
| #250 | `22af2074a086d9957a18e310ef8572b28d1facd0` | Historical deployment-date, RPC retry and TRON range safeguards | Closed source obligation |
| #256 | `e2ebb4902e53e2249c6585a1d72be6e1e416c36c` | Sleep-aware idle locking and sole-copy authority separation | Closed source obligation |
| #252 | `4085622463411d3ba27f4efb7b73a70575170535` | Sweep explicit balance consent and asynchronous quote ownership | Closed source obligation |
| #272 | `63ff40d57af879a3d82166450f63aadb7bf0d5ff` | Sweep explicit balance consent and asynchronous quote ownership | Closed source obligation |
| #244 | `981cc2f4395d2d76c499a5cd46387daaaa3a6b1f` | Bitcoin local spentness, retained history and optional disclosure | Pending selective BTC correction |
| No open PR | `7954f1e5a29988fb9239225d1f829c6c3dc71e08` | Bitcoin local spentness, retained history and optional disclosure | Pending selective BTC correction |
| #254 | `2b4b1e912350cb18c630a68b5c1990426e29dbc0` | Bitcoin local spentness, retained history and optional disclosure | Pending selective BTC correction |
| #229 | `18110015e99efbeb4f23d47cd88bd6f917010108` | Portable spending-key export and independent recovery broad donor | Pending deeper inherited review |
| #226 | `3a3b136a326e0d8c1f369d94d4517ad0711babc8` | Unicode fixture readability and pinned-download tooling | Closed source obligation |
| #213 | `ebf7c92c3be1c7aebd37fc58b5567e114fb932fc` | Portable spending-key export and independent recovery broad donor | Pending deeper inherited review |
| #224 | `1054daabc5cabe958466ec144582d76137b54910` | Unicode fixture readability and pinned-download tooling | Closed source obligation |
| #211 | `a92658b1ef6b95ff0145b2e1933d0047d51289d5` | Mixed chain interop, policy and backup/source isolation donor | Pending deeper inherited review |

All original branch classifications remain unchanged. A source obligation can close while the branch remains “Blocked by dependencies” or “Superseded”; those labels accurately distinguish candidate preservation from main adoption. No shared target was merged or modified by this worker.

## Bounded findings

### Print isolation

The complete #316 print delta is retained. Print targeting owns a single selected element, refuses detached targets and duplicate activation, and clears ownership after completion, replacement, unmount or synchronous failure. Current ReceiptPanel retains the original print integration while adding address omission and archive-write ownership. The print hook, invoice panel and receipt panel ran in the independent 219-case selection. The preserved Playwright fixture was inspected but not executed here.

### Idle/session authority

The two idle donors have the same runtime implementation; #256 adds test and payer-clock qualification. Their wall/monotonic lease, restoration checks, first-input check, generation guards, synchronous authority revocation and temporary-copy wiping remain in recovery. A retained sole copy has only the narrow encrypted-backup path, while ordinary signing/scanning/export authority remains suspended. Current beforeunload protection is stronger because all loaded keys without a verified external copy are protected.

All changed locale values are retained exactly. The four idle security messages and one Sweep security message remain in explicit SECURITY_KEY_GROUPS. The current idle clock/session/cursor suites passed in the 219-case selection, and TagArchive passed ten additional cases. These are synthetic lifecycle checks, not a claim of physical OS sleep or browser BFCache selection.

### Sweep consent and quote ownership

The #231 → #252 → #272 production progression is preserved in recovery: explicit balance reads in every privacy mode; context-bound balance ownership; session checks after asynchronous RPC construction; quote generation checks after asynchronous requests; and final review checks before signing/handoff. Current recovery adds abort controllers, network revision and network-operation authorization. All original direct case titles remain in the current test paths; the privacy and quote lifecycle suites passed in the 219-case selection. Broader native Sweep review and browser gates remain separate.

### Historical adapter safeguards

#250 preserves calendar-valid deployment dates, bounded finite RPC retries, stricter existing decimal handling and complete contiguous TRON ranges. The current EVM RPC successor also omits credentials/referrers and disables caching. The independent EVM selection passed 123 cases and the TRON scan selection passed 27. The first adapter command failed during option parsing before cases executed; the corrected direct Vitest command supplies the passing evidence.

### Contract deployment acknowledgement

#217 is preserved in broad #361 at `4ccb3db334de7d7cada305a11243c9e3efddc4f6`, tree `0b09c320d2b9fc1e5cf222da1a57ac5bad885d7e`. Deployment source and tests are exact, and the shell successor strengthens address and zero-fee validation. These non-Pages paths were deliberately excluded from recovery783 and are not adopted by current main. The source-preservation obligation closes under the existing Superseded classification; native Forge and deployment qualification remain unexecuted in this worker.

### Unicode/tooling cleanup

#224 and #226 change 28 TypeScript files through equivalent Unicode/format literal presentation and three tooling files. The complete changed source was inspected; normalized AST checks find all 28 files equivalent for each donor, and each changed source body maps to pinned main or recovery. The formatting tests passed 27 cases. HTTPS-only initial/redirect curl restrictions retain existing checksum checks; the integration runner refuses implicit npx installation. Both affected shell scripts pass syntax checks. No download, container build or release validation was executed.

## Bitcoin family remains unresolved

The newer #254 per-output `spentCheckedThrough` model improves the older #244 global coverage model and must be retained. Existing corrected-source checks passed **106 web cases plus 69 package cases**, covering local spend tracking, incomplete history, evidence anchors, worker-source permissions and header reconciliation. Their success does not cover the missing donor guards below.

The complete runtime comparison identified three recoverable defensive changes from #244 `981cc2f4395d2d76c499a5cd46387daaaa3a6b1f`. The qualification branch `7954f1e5a29988fb9239225d1f829c6c3dc71e08` has identical production source.

1. **Optional spent-check consent on wallet replacement and lock.** In `apps/web/src/features/btc/BtcView.tsx`, #244 clears `providerCheck` after successful `useSeed()` installation and in `lock()`. Recovery783 retains the endpoint-change reset but lacks these two wallet lifecycle resets. Root accepted a separate bounded correction and ordinary lifecycle coverage.
2. **Output-index API contract.** `apps/web/src/features/btc/esplora.ts` has donor safe uint32 validation for `isUnspent()`. Recovery783 retains a weaker integer/nonnegative check. Selective recovery needs current API compatibility review and retained defensive contract tests.
3. **Worker result binding.** `apps/web/src/features/btc/scanWorkerClient.ts` contains donor checks binding a result to its request/header context, unique output identities and recovery-window shape. Recovery783 has structural/provider-permission checks but lacks this additional binding. Review and restore compatible guards without replacing the newer coverage representation.

These are source findings, not exploit reproductions. No historical vulnerable implementation or new adversarial payload ran. At root request, all four family branch records remain pending until selective correction and independent qualification. Older separate light-mode checkbox design should not be imported wholesale: current explicit light-mode selection already describes its required per-output requests, and any change needs accepted requirement review.

## Broad donors remain pending

#213 and #229 portable recovery were pinned, fully patched and mapped to current candidates, but their nonidentical secret-export components, session/vault ownership, codec and standalone recovery script require a deeper fresh review. No test run in this packet is attributed to portable recovery.

#211 combines chain interop, policy, backup and scanner/UI behavior. Its 34 chain-related source bodies map to the managed chain candidate; that subfamily does not close the remaining policy, backup and UI changes. Existing other-worker test totals were not re-attributed here. The entire branch remains pending.

## Independent execution evidence

| Selection | Passed cases | Passed files | Exit | Raw receipt |
|---|---:|---:|---:|---|
| EVM adapter safeguards | 123 | 3 | 0 | adapter-safeguards-corrected.receipt.json |
| i18n formatting | 27 | 1 | 0 | i18n-format.receipt.json |
| Print, Sweep and idle ownership | 219 | 8 | 0 | print-sweep-idle-corrected.receipt.json |
| BTC web spentness/consent | 106 | 8 | 0 | btc-spentness-web.receipt.json |
| BTC package scanner/state/headers | 69 | 3 | 0 | btc-spentness-package.receipt.json |
| TRON range retention | 27 | 1 | 0 | tron-range-retention.receipt.json |
| Idle archive retention | 10 | 1 | 0 | idle-tag-archive.receipt.json |
| **Total** | **581** | **25** | | |

Every passing unit receipt records the full command, cwd, timestamps, exact source/tree, unchanged tracked status, raw-log size and SHA-256. There were no failed or skipped cases in those seven completed selections. Additional source checks are two `bash -n` checks and 56 normalized AST comparisons; they are not counted as unit tests.

Two nonpassing attempts are preserved separately: the initial adapter command failed before execution, and the accidental npm web command began its aggregate coverage stage before arguments could select the second stage. That aggregate was interrupted in its own session89786 with exit130, and no passing cases are attributed. Its output was buffered and not persisted before interruption. Subsequent application checks used direct Vitest with one worker. The early successful adapter/i18n selections used two workers before the resource restriction.

## Integration limits

This worker changed only this evidence directory. No source edits, dependency installations, Git refs, remote writes, integration-lock operations, deployment, release or real-funds transactions occurred. Browser engines, Tor, native contracts, release artifacts and whole-candidate security/CI gates remain root-owned. This packet grants no formal repository approval.

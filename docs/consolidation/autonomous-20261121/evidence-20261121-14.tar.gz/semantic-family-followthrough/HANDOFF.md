# Fresh-worker handoff

Owner: `/root/semantic_family_followthrough`. Status: completed bounded read-only assignment; no active test session remains.

## Root application

1. Verify MANIFEST.json and PIN_VERIFICATION.json. REVIEW.json carries 17 exact name/source overlay records; apply only against identical branch pins.
2. After the preceding 26-record packet, close ten inherited obligations and retain all seven pending records. Recommended inherited count: 110 → 100. The fresh 445-branch mechanical census and its newer source publications remain root-owned.
3. Preserve original classifications and branches. This source review does not authorize merging shared targets or release gates.

## Highest-priority next work

Root accepted the BTC optional-consent lifecycle correction. Source donor is #244 `981cc2f4395d2d76c499a5cd46387daaaa3a6b1f`, equivalent qualification head `7954f1e5a29988fb9239225d1f829c6c3dc71e08`; corrected-source base is `783231a46840cd869e39bd704751d4ab4c349c45`.

- `apps/web/src/features/btc/BtcView.tsx`: preserve the existing endpoint reset, add the donor reset after successful useSeed installation and in lock, and qualify ordinary wallet/lock lifecycle behavior in an isolated child of #372.
- Separately review compatible donor uint32 output-index validation in `apps/web/src/features/btc/esplora.ts` and request/header-bound result validation in `apps/web/src/features/btc/scanWorkerClient.ts`. Existing defensive donor tests can inform corrected-source compatibility coverage. Keep the newer per-output spentCheckedThrough model.
- Keep all four BTC records pending until the correction and independent qualification are complete; the current 175 passing BTC cases alone do not close these gaps.

Next semantic-review worker should take #213/#229 portable recovery as one bounded family, comparing complete original patches to current independent recovery, component authority and codec behavior. Broad #211 must keep its chain subfamily separate from unresolved policy/backup/scanner/UI history. Do not close either through ancestry or matching blobs.

## Artifacts and execution

REVIEW.json is the machine-readable overlay; REVIEW.md is the human explanation. Full original branch patches, successor diffs, exact path mappings, narrow locale/security mapping, direct test-title inventories and TypeScript source-equivalence inputs are included. Seven completed corrected-source test selections total 581 passed cases across 25 files. No completed selection has failures or skips. Raw logs and receipts carry source pins and digests. Additional syntax/AST checks are recorded separately.

The initial adapter option-parser failure and interrupted accidental aggregate are explicit nonpassing receipts with zero attributed passes. Session89786 was stopped via its exact owned session and returned130; no other worker process was touched. No active session remains.

No source, dependency, Git ref, remote, lock, deployment or funds action was performed by this worker. All source tests used recovery783 and left tracked source clean. Native fee-guard scope is preserved only in #361; Forge/deployment qualification remains open, and it was intentionally excluded from the Pages candidate.

import ts from '/workspace/scratch/5ceb6203640a/recovery-settings-fix/node_modules/typescript/lib/typescript.js';
import fs from 'node:fs';
const canonical = (text, filename) => {
  const file = ts.createSourceFile(filename, text, ts.ScriptTarget.Latest, true);
  const walk = node => {
    const children = [];
    ts.forEachChild(node, child => { children.push(walk(child)); });
    let value = ts.isIdentifier(node) || ts.isPrivateIdentifier(node) || ts.isLiteralExpression(node) || ts.isTemplateLiteralToken(node) || node.kind === ts.SyntaxKind.JsxText ? node.text : undefined;
    if (ts.isRegularExpressionLiteral(node)) value = value.replace(/\\u([0-9a-fA-F]{4})/g, (_, hex) => String.fromCharCode(Number.parseInt(hex,16)));
    return [node.kind, value ?? null, children];
  };
  return JSON.stringify(walk(file));
};
for(const id of ['224','226']) {
  const input=JSON.parse(fs.readFileSync(new URL(`./${id}-ts-inputs.json`,import.meta.url)));
  const result=input.map(x=>({path:x.path,canonical_ast_equal:canonical(x.before,x.path)===canonical(x.after,x.path)}));
  fs.writeFileSync(new URL(`./${id}-ast-comparison.json`,import.meta.url),JSON.stringify(result,null,2)+'\n');
  console.log(JSON.stringify({id,files:result.length,unequal:result.filter(x=>!x.canonical_ast_equal)}));
}

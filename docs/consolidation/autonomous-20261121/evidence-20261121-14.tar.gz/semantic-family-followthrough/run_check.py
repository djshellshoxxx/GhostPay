import datetime, hashlib, json, pathlib, subprocess, sys, time
OUT = pathlib.Path(__file__).resolve().parent
name, repo, *command = sys.argv[1:]
def source():
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()
    return {'sha':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'tracked_status':git('status','--porcelain','--untracked-files=no')}
before=source(); started=datetime.datetime.now(datetime.timezone.utc).isoformat(); start=time.monotonic()
p=subprocess.run(command,cwd=repo,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
after=source(); (OUT/(name+'.log')).write_bytes(p.stdout)
receipt={'name':name,'command':command,'cwd':repo,'started_at':started,'ended_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'wall_seconds':round(time.monotonic()-start,3),'exit_code':p.returncode,'source_before':before,'source_after':after,'log_bytes':len(p.stdout),'log_sha256':hashlib.sha256(p.stdout).hexdigest()}
(OUT/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt)); print(p.stdout.decode(errors='replace')[-2500:])
if before != after: raise SystemExit('source changed during verification')
raise SystemExit(p.returncode)

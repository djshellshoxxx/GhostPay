import datetime, hashlib, json, pathlib, subprocess
OUT = pathlib.Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT / 'GhostPay'
MAIN = 'eb59d93cffed7848c4aac37d0e9650b87239c6da'
RECOVERY = '783231a46840cd869e39bd704751d4ab4c349c45'
TREE = '65e5cc6fdb7ab3337951ba0b0b58e87b71df095b'
def read(path): return json.loads(path.read_text())
def git(*args): return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()
mappings = read(OUT / 'path-mappings.json')['records']
original = read(ROOT / 'GhostPay-ledger/docs/consolidation/autonomous-20261121/classified-branches-063338.json')
by_name = {r['name']: r for r in original['branches']}
live = read(ROOT / 'census-latest-evidence/live-branches.json')
live_by_name = {r['name']: r['sha'] for r in live['branches']}
previous = read(ROOT / 'remaining-semantic-review-evidence/REVIEW.json')
prior_names = {r['name'] for r in previous['records']}
prior_sources = {r['source'] for r in read(ROOT / 'GhostPay-ledger/docs/consolidation/autonomous-20261121/semantic-followthrough/REVIEW.json')['records']}
assert not prior_sources.intersection(r['source'] for r in mappings)
assert not prior_names.intersection(r['name'] for r in mappings)
assert all(live_by_name[r['name']] == r['source'] == by_name[r['name']]['sha'] for r in mappings)
assert all(git('rev-parse', r['source']+'^{tree}') == r['source_tree'] for r in mappings)

families = {
 'print': {
  'title':'Receipt and invoice print isolation', 'closed':True,
  'behavior':[
   'The complete narrow original print delta is retained: exactly the selected print target is visible; other bills/receipts remain hidden. PrintableBill and usePrintTarget runtime/test bodies plus CSS and browser fixture are byte-identical to the donor.',
   'Hook source review verified ownership cleanup on replaced/unmounted refs, detached-target refusal, duplicate-click refusal, synchronous afterprint, and print exceptions. Current ReceiptPanel retains the ref/print control while adding separately reviewed address omission and immutable archive write ownership.',
   'Original direct unit case titles remain present. All three print/receipt unit files passed as part of the independent 219-case batch.'
  ],
  'evidence':['316.patch','test-title-mappings.json','print-sweep-idle-corrected.receipt.json'],
  'remaining':['Current candidate dependency, independent whole-candidate review, hosted requirements and browser qualification remain root-owned. Browser print fixture was inspected and retained, not executed in this worker.']
 },
 'idle': {
  'title':'Sleep-aware idle locking and sole-copy authority separation', 'closed':True,
  'behavior':[
   'The complete original runtime delta was reviewed. A lease observes wall and monotonic clocks, treats invalid/negative/rollback clocks conservatively, persists across configuration rerenders, checks before first post-sleep input and at secret boundaries, and rejects retired timer/custody callbacks.',
   'Authority is revoked synchronously before asynchronous recoverability checks. A sole copy remains suspended for encrypted backup/save/verification only; normal secret borrowing and signing fail. Temporary asynchronous copies are wiped on revocation and stale completions are rejected.',
   'Current AppShell retains the complete idle lease body and strengthens beforeunload protection to all loaded wallets lacking verified external copies. Current session replacement prepares the replacement before clearing the prior holder; narrow backup guards remain distinct from normal authority.',
   'The two donor runtime implementations are identical; #256 adds typed test access, archive cleanup acceptance and a separate payer clock fixture. Changed locale values are retained exactly and all five distinct added security keys across idle/Sweep remain classified in SECURITY_KEY_GROUPS.',
   'Independent idle-clock/session/cursor cases passed in the 219-case batch; current TagArchive file passed ten cases, including retention of the exact sole copy while archive controls disappear.'
  ],
  'evidence':['d5fe06e7.patch','256.patch','idle-successor.patch','test-title-mappings.json','narrow-locale-security-mappings.json','print-sweep-idle-corrected.receipt.json','idle-tag-archive.receipt.json'],
  'remaining':['No native OS-sleep or BFCache claim is made. Existing browser cases model clocks/restoration and remain subject to root browser gates. These branches are superseded candidates, not current-main adoption.']
 },
 'sweep': {
  'title':'Sweep explicit balance consent and asynchronous quote ownership', 'closed':True,
  'behavior':[
   'All original production changes and original test preservation were reviewed across #231 -> #252 -> #272. Balance reads require a separate explicit click in every privacy transport mode and name the selected RPC; none occur on mount.',
   'The successor binds balance operations to selection, token, endpoint, RPC factory and session; checks after asynchronous RPC construction prevent stale private reads. Quote requests bind balance and quote generations to destination/mode/relayer/manifest/services; late responses cannot restore a replaced quote or its error.',
   'Current recovery preserves these guards and adds per-operation abort controllers and network revision/authorization. Direct and relayed paths recheck review authority before requests and handoff; the newer native review retains the same generation checks. Existing journal and unknown-outcome semantics were not weakened by this family.',
   'All original direct test titles from the three donors remain in their current paths. Sweep privacy and quote lifecycle tests passed in the independent 219-case batch. Changed locale values and added security classifications are retained.'
  ],
  'evidence':['231.patch','252.patch','272.patch','sweep-successor.patch','test-title-mappings.json','narrow-locale-security-mappings.json','print-sweep-idle-corrected.receipt.json'],
  'remaining':['Source-family review does not qualify the broader native-sweep implementation or its browser cases. Those remain in root-owned candidate review/gates; no funds or remote RPCs were used.']
 },
 'adapters': {
  'title':'Historical deployment-date, RPC retry and TRON range safeguards', 'closed':True,
  'behavior':[
   'Complete seven-path source/test delta reviewed. Date parsing includes a calendar roundtrip so normalized impossible dates fail; retries normalize nonfinite inputs to zero and clamp finite retries to the established bounded range.',
   'Current EVM RPC successor retains retry bounds and adds credential/referrer/cache privacy options. Deployment test differences are equivalent fixture construction. The older quote decimal widening is not reapplied because current quote validation is stricter; its regression tests are retained.',
   'TRON range acquisition retains exact requested-range/contiguous-block checks so a missing or partial range cannot silently advance the scan cursor. Runtime and scan tests are donor-identical.',
   'Independent execution: EVM deployment/RPC/quote selection 123 passed; TRON scan selection 27 passed, all on unchanged recovery source.'
  ],
  'evidence':['250.patch','adapter-safeguards-corrected.receipt.json','tron-range-retention.receipt.json'],
  'remaining':['The first adapter command failed during option parsing before test execution because npm already supplied coverage=true. The corrected direct Vitest run is the only attributed passing receipt.']
 },
 'fee': {
  'title':'Non-Pages flat-fee deployment acknowledgement', 'closed':True,
  'behavior':[
   'Original deployment source and tests require an exact checksum fee-token acknowledgement for nonzero FLAT_FEE before broadcasting/deploying; missing/different acknowledgement fails while zero-fee mode remains allowed.',
   'DeployPolicy source, both test files, contract README and gas snapshot are exact in broad #361. Its pre-deploy shell successor adds address validation and a correctly bounded zero-fee diagnostic. No contract runtime source is changed by this donor.',
   'This contract/tooling scope was deliberately excluded from the Pages recovery candidate and is not represented as adopted by current main. Preservation in #361 plus stronger shell behavior supports the historical Superseded disposition only.'
  ],
  'evidence':['217.patch','fee-guard-broad-candidate-mapping.json'],
  'remaining':['No native Forge execution, deployment gate or artifact qualification performed by this worker. Keep the original branch and broader contract candidate; deployment and separately authorized non-Pages integration remain outstanding.']
 },
 'tooling': {
  'title':'Unicode fixture readability and pinned-download tooling', 'closed':True,
  'behavior':[
   'Complete source delta consists of 28 TypeScript files containing literal Unicode/format cleanup and three tooling files. Normalized TypeScript AST checks and manual changed-source inspection found equivalent structure and literal values in all 28 files for each donor; every changed source body is retained in pinned main or recovery.',
   'Production i18n formatting still inserts the same isolation codepoints and removes the same controls. Independent i18n format selection passed 27 cases.',
   'The substantive tooling changes restrict circom/bitcoind curl initial and redirect protocols to HTTPS without removing existing checksum checks, and use npx --no -- vitest to prevent implicit test-tool installation. Both current shell scripts pass bash -n.',
   'AST normalization is a source-equivalence aid, not an execution proof. Docker builds and circom downloads were not performed.'
  ],
  'evidence':['224.patch','226.patch','224-ts-inputs.json','226-ts-inputs.json','224-ast-comparison.json','226-ast-comparison.json','i18n-format.receipt.json','tooling-readonly-checks.receipt.json'],
  'remaining':['Original historical documentation remains provenance, not fresh CI evidence. Current candidate release requirements stay root-owned.']
 },
 'btc': {
  'title':'Bitcoin local spentness, retained history and optional disclosure', 'closed':False,
  'behavior':[
   'Complete family runtime deltas were reviewed through #219, #244/qualification and #254, then against recovery783. Local spend derivation uses transaction inputs bound to downloaded block data, retains per-output continuous coverage, downgrades incomplete/legacy history to unknown, and prevents unknown results from becoming sweep authority.',
   'Current per-output spentCheckedThrough state supersedes the older global spendsFromHeight model; reorganization handling, duplicate-spend normalization, retained evidence anchors and worker-source permission checks are preserved. Current shorter-prefix header handling is stronger than #254. Network-authorized bounded transport supersedes the old Esplora reader.',
   'Original #244 and qualification production are identical. Their endpoint-consent reset is present in recovery783, but their successful wallet installation and lock consent resets are absent. Root accepted a separate bounded recovery of these guards; all four family records remain pending until correction and independent qualification.',
   'Two additional donor defensive contracts merit selective compatibility review: safe uint32 output index validation in EsploraClient.isUnspent and request/header-bound worker result validation. They must not justify replacing the newer spentness state model.',
   'Independent current-source execution passed 106 web cases and 69 scanner/state/header package cases. These passing existing cases do not demonstrate the missing donor guards and do not qualify their future correction.'
  ],
  'evidence':['219.patch','244.patch','7954f1e5.patch','254.patch','btc-219-to254.patch','btc-244-to254.patch','btc-244-toqualification.patch','btc-successor.patch','test-title-mappings.json','btc-spentness-web.receipt.json','btc-spentness-package.receipt.json'],
  'remaining':['Recover wallet/lock optional-consent reset in a separate candidate owned by root; add ordinary lifecycle coverage and independent review.', 'Evaluate existing donor outpoint-validation and worker-result contract guards for selective recovery; no historical vulnerable code or exploit payload was executed.', 'Explicit light-mode selection already discloses required per-output requests in current UI; do not blindly replace it with the older checkbox design without accepted requirement review.', 'Browser/native-worker gates remain open; synthetic current-source unit checks do not substitute for them.']
 },
 'portable': {
  'title':'Portable spending-key export and independent recovery broad donor', 'closed':False,
  'behavior':[
   'Exact source/merge-base/tree pinned, full uncapped branch patch retained, and every changed source/test path compared to current candidates.',
   'Older portable codecs, standalone recovery script, exported-key UI components, seller/vault authority and test vectors overlap current recovery; many production/test paths have later changes. This worker has not completed behavior-by-behavior attribution for those nonidentical paths and does not infer closure from ancestry or blobs.'
  ],
  'evidence':['213.patch','229.patch','path-mappings.json'],
  'remaining':['Fresh worker must inspect the older parent deltas for independent recovery, raw-key versus archive authority, portable canonicalization, ownership cancellation, and current retained regression coverage.', 'Use existing current-source tests and verified exact candidate receipts; preserve broader inherited review separately from an individual parent fix. No test receipt in this packet is attributed to portable recovery.']
 },
 'broad': {
  'title':'Mixed chain interop, policy and backup/source isolation donor', 'closed':False,
  'behavior':[
   'Exact source/tree/merge-base pinned and full uncapped patch retained. Seventy-five source/test/document paths have mappings; 34 chain-related bodies map exactly to the independently managed chain candidate.',
   'Policy, secret backup, scan isolation and chain-view UI changes have nonidentical successors. The chain mapping does not close the whole broad branch. Prior agent test totals have not been re-attributed in this packet.'
  ],
  'evidence':['211.patch','path-mappings.json'],
  'remaining':['Fresh worker must account for the remaining policy/backup/UI/scanner paths and their parent dependencies, including security-sensitive policy regression gates without historical exploit execution.', 'Do not close this broad donor based on the separately recovered chain subfamily or the existing 49 matching paths.']
 }
}

def family(r):
 p=r['pr']
 if p==316:return 'print'
 if p==256 or r['source'].startswith('d5fe06e7'):return 'idle'
 if p in [231,252,272]:return 'sweep'
 if p==250:return 'adapters'
 if p==217:return 'fee'
 if p in [224,226]:return 'tooling'
 if p in [219,244,254] or r['source'].startswith('7954f1e5'):return 'btc'
 if p in [213,229]:return 'portable'
 return 'broad'

records=[]
for r in mappings:
 f=family(r);d=families[f];old=by_name[r['name']];is_staged=f in ['portable','broad']
 candidate=RECOVERY if f!='fee' else '4ccb3db334de7d7cada305a11243c9e3efddc4f6'
 row={
  'name':r['name'],'source':r['source'],'source_tree':r['source_tree'],'open_pr':r['pr'],
  'family_review':d['title'],'merge_base':r['merge_base'],'all_best_merge_bases':old['all_best_merge_bases'],
  'comparison_main':MAIN,'candidate':candidate,'candidate_tree':git('rev-parse',candidate+'^{tree}'),
  'candidate_pr':361 if f=='fee' else 372,
  'classification':old['classification'],'semantic_review_pending':not d['closed'],
  'review_status':'staged-inherited-source-review-pending' if is_staged else 'source-reviewed-unique-recovery-pending' if f=='btc' else 'bounded-source-and-test-reviewed' if f!='fee' else 'bounded-source-preservation-reviewed-native-gates-pending',
  'scope':'Exact original merge-base-to-source family delta, separate from broader successor history and merge qualification.' if not is_staged else 'Pinning, full patch collection and successor path mapping only; no full semantic closure.',
  'reviewed_paths':[] if is_staged else [x['path'] for x in r['mappings']],
  'staged_paths':[x['path'] for x in r['mappings']] if is_staged else [],
  'path_mappings':r['mappings'],'behavior':d['behavior'],'evidence':d['evidence'],
  'remaining':d['remaining'],'formal_review_or_merge_approval':False,
  'classification_unchanged':True,
 }
 if f=='fee':row['additional_candidate_mapping']='fee-guard-broad-candidate-mapping.json'
 records.append(row)

unit_counts={'adapter-safeguards-corrected':(123,3),'i18n-format':(27,1),'print-sweep-idle-corrected':(219,8),'btc-spentness-web':(106,8),'btc-spentness-package':(69,3),'tron-range-retention':(27,1),'idle-tag-archive':(10,1)}
executions=[]
for name,(count,files) in unit_counts.items():
 receipt=read(OUT/(name+'.receipt.json'));log=OUT/(name+'.log')
 assert receipt['exit_code']==0 and receipt['source_before']==receipt['source_after']
 assert receipt['source_before']['sha']==RECOVERY and receipt['source_before']['tree']==TREE and receipt['source_before']['tracked_status']==''
 assert hashlib.sha256(log.read_bytes()).hexdigest()==receipt['log_sha256']
 assert f'Tests  {count} passed ({count})' in log.read_text()
 executions.append({**receipt,'tests_passed':count,'tests_failed':0,'tests_skipped':0,'files_passed':files,'receipt_file':name+'.receipt.json','log_file':name+'.log'})
closed=sum(not r['semantic_review_pending'] for r in records)
assert closed==10
review={
 'schema':'ghostpay-bounded-semantic-family-followthrough/1','reviewer':'/root/semantic_family_followthrough','recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'input_snapshot':{'legacy_ledger_branches':438,'live_pin_verification_branches':445,'live_capture':live['captured_at'],'main':MAIN,'input_pending_after_preceding_26_record_packet':110},
 'records_considered':len(records),'bounded_source_reviewed_records':14,'staged_only_broad_records':3,
 'closed_semantic_obligations':closed,'pending_records_in_this_packet':7,'recommended_remaining_inherited_semantic_obligations':110-closed,
 'records':records,'independent_executions':executions,
 'independent_test_totals':{'tests_passed':sum(x[0] for x in unit_counts.values()),'files_passed':sum(x[1] for x in unit_counts.values()),'tests_failed':0,'tests_skipped':0},
 'other_checks':[{'receipt':'tooling-readonly-checks.receipt.json','result':'passed','shell_syntax_files':2,'source_AST_comparisons':56,'test_count':0}],
 'nonpassing_attempts':[{'receipt':'adapter-safeguards.receipt.json','result':'failed-before-tests','attributed_passes':0},{'receipt':'print-sweep-idle.interrupted.receipt.json','result':'interrupted','exit_code':130,'attributed_passes':0}],
 'recoverable_unique_work':[{
  'id':'btc-wallet-scope-optional-consent','source':'981cc2f4395d2d76c499a5cd46387daaaa3a6b1f','equivalent_source':'7954f1e5a29988fb9239225d1f829c6c3dc71e08','current':RECOVERY,
  'path':'apps/web/src/features/btc/BtcView.tsx','scope':'Reset optional providerCheck after successful useSeed installation and lock; preserve existing endpoint-change reset.','owner':'/root','status':'root accepted bounded corrective recovery; independent qualification pending'},
 {'id':'btc-output-index-contract','source':'981cc2f4395d2d76c499a5cd46387daaaa3a6b1f','current':RECOVERY,'path':'apps/web/src/features/btc/esplora.ts','scope':'Preserve safe uint32 output-index validation in isUnspent; select donor guard and existing defensive API contract coverage after compatibility review.','status':'recoverable donor hardening, source-reviewed, unimplemented by this worker'},
 {'id':'btc-worker-result-request-binding','source':'981cc2f4395d2d76c499a5cd46387daaaa3a6b1f','current':RECOVERY,'path':'apps/web/src/features/btc/scanWorkerClient.ts','scope':'Preserve original request/header-bound result validation while retaining newer per-output spentCheckedThrough model and source permissions.','status':'recoverable donor hardening, source-reviewed, needs current contract compatibility review'}],
 'limits':[
  'No repository source edits, installations, ref updates, remote writes, lock acquisition, merge, deployment or real-funds operation by this worker.',
  'Source pins were checked against the 445-branch snapshot captured 08:09:54Z; root must refresh later live changes before applying or merging.',
  'Ten closed source obligations do not mean ten branches merged or application changes approved. Classifications are intentionally unchanged.',
  'The four BTC records remain pending at root request until newly identified selective correction and independent qualification; three broad records remain pending deeper source/test review.',
  'Only existing corrected-source unit suites ran. No historical vulnerable code, exploit reproduction, remote RPC or native deployment was executed.',
  'The accidental npm web command began its aggregate coverage stage and was interrupted using only its owned session89786, exit130. Its output was buffered and not persisted before interruption; no tests from it are counted.',
  'All subsequent application test selections used direct Vitest and maxWorkers1; initial successful adapters/i18n checks used maxWorkers2 before the shared-memory restriction.',
  'Browser, Tor, physical sleep, native contracts, release integrity and whole-candidate gates are outside this bounded worker evidence. Root owns qualification and integration.'
 ]
}
(OUT/'REVIEW.json').write_text(json.dumps(review,indent=2,ensure_ascii=False)+'\n')
pins={'main':MAIN,'source_records':[{'name':r['name'],'source':r['source'],'source_tree':r['source_tree'],'matches_live_snapshot':True} for r in mappings],
 'live_capture':live['captured_at'],'all_source_pins_match':True,'disjoint_from_previous_26_and_6':True,
 'candidate_status':{'recovery':subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],cwd=ROOT/'recovery-settings-fix',text=True).strip()},
 'all_test_receipt_digests_verified':True}
(OUT/'PIN_VERIFICATION.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'records':len(records),'closed':closed,'remaining':110-closed,'tests':review['independent_test_totals']}))

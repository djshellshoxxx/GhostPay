# Independent source review: individual payment-key export (#572)

## Decision and immutable pins

**Source approved: no blocking source or integration defect found in the reviewed scope.** This is an independent read-only source review, not a hosted or native acceptance result.

- Reviewed commit: `079a153aadd2c3f2ac8e87a9dab2daf8f0fc00de`
- Reviewed tree: `b7c3a7784d20f5e538caaf9e6bcb7bf0f445f565`
- Current followup base: `0b60dba235710f12847532dd9d0f74f12f7298c6`
- Original #572 donor: `28bba11cdaebc13edc4d100761ee00750c3f396f`
- Original-donor merge: `05d818e7fc85bfc9a2e5ccaf0cfa874ee0df2110`
- Read-only checkout: `/workspace/scratch/f80482f352bc/react-pages-diagnostics`
- Reviewer: `/root/ownership_review`

Both the current base and original donor are ancestors of the reviewed source. Review used immutable Git objects, so subsequent author documentation cannot change what this approval covers.

## Existing seller, session and scan behavior

`SellerKeys.tsx`, `SellerPairing.tsx`, `appLock.ts`, the existing portable keystore implementation and its memory regression, receipt/print components, all 973 preexisting test/spec files, all 73 workspace manifests, and the root manifest and lockfile remain byte-identical to the current base. Independent comparison receipts are in `individual-export-independent-preservation.json` beside this report.

The `keyVault.ts` delta adds 40 lines and removes none. The `session.ts` delta adds 16 lines and removes none. Existing seller backup authorization, vault custody, save/unlock behavior and backup-verification state transitions remain intact. In particular, `requireSecretExportAuthorization` does not reuse the existing seller-backup allowance that can succeed without a vault. Secret payment exports must supply a usable vault credential or a matching encrypted keystore plus passphrase. Exact-key verification includes the meta-address, spending/viewing public keys and invoice signer. Reauthentication records no backup, custody or vault state.

The scan addition stores a verified scan RPC alongside the existing chain/key/signer owner. Existing session-revision cancellation, scoped match filtering, receipt signer checks and tag handling remain. Stopping a scan leaves its already-discovered matches exportable through the verified client. Saved privacy-route selection and the applicable configured RPC URL are rechecked before the address query and before accepting the export. This adds no fallback endpoint or provider.

## Secret export and asynchronous authority

The browser exposes an individual scanned scheme-1 payment only. Public record generation verifies key/address ownership and erases the temporary scalar. Encrypted and raw exports additionally require credential verification and an `eth_getCode` check on the recorded chain. A missing/wrong-chain RPC, malformed response, nonempty bytecode or delegation refuses the secret export. The new-passphrase policy and the raw form's literal `true` confirmation are checked before authorization or disclosure.

Session and cancellation guards surround asynchronous credential work, RPC response handling and encryption. The panel operation also captures the session revision and its match/chain/RPC scope, rejects replaced or aborted operations, and cancels/reset on session changes, lock notification and unmount. Derived payment secrets are wiped in `finally`. The raw file is downloaded explicitly and not retained as component state; only an encrypted export is retained for retry and verification.

Saved-file verification requires the exact generated ciphertext and byte length, explicit retention confirmation, a successful decrypt and single-payment scope. It wipes every returned scalar and does not mark the seller's master backup as verified. The ordinary donor regression cases cover the relevant credential mismatch, change/cancel and stale-scope behavior; this review did not duplicate their execution.

## Portable codec and independent recovery

The package codec uses the existing crypto and schema dependencies. It bounds input before parsing/KDF work, rejects duplicate and unknown fields, validates record/key/address correspondence, scopes and chain consistency, and bounds KDF/cipher parameters and ciphertext length. Encrypted bodies authenticate the complete canonical public header with a format-specific domain. Decryption is atomic and clears temporary plaintext/keys on rejection; successful callers own the returned key arrays. The format excludes invoice-signing keys.

Archive and master formats are standalone codec/recovery capabilities. The recovered browser view calls only the individual payment export paths; no master-export UI, provider completion, hosted service or deadline subsystem is activated.

The independent Node decoder imports Node built-ins and already-declared Noble dependencies, makes no network call, reads export files with a byte cap, and checks format/KDF/cipher/header constraints before decryption. Public inspection is separated from authenticated decryption and cannot be combined with private-key revelation. Passphrases come from stdin or a non-echo terminal prompt, not command-line options or environment variables. Secret output is explicit; master secrets are never printed. The CLI erases owned byte buffers in its success/failure cleanup paths. This is a source review of the existing format contract; no new stress case or vulnerability reproduction was run.

## Deadline wording

Commit `1369dc173c700fa61c1e3502d29f9a3bf90369ea` changes two comment lines only. It removes the inaccurate synchronous session-deadline guarantee and accurately describes captured revision/current-input checks plus cancellation on lock notification. The runtime is unchanged. Existing `appLock.ts` is byte-identical, and no deadline/lock implementation file changes in this recovery. Approval does not imply an independent wall-clock deadline check.

## Native gate preservation

The complete `ci.yml` is exactly the current base plus this command after the unchanged Node command inside the existing `rest-0` branch:

```sh
REQUIRE_ANVIL=1 node --test scripts/recovery/*.test.mjs
```

The existing setup builds/restores the workspace libraries and installs the pinned Foundry toolchain. The command executes once in rest-0 under the existing strict shell and normal required TypeScript aggregation. All other shard commands, steps, settings and gates are preserved. The native fixture explicitly fails when required Anvil/cast prerequisites are absent; its successful path requires both the raw-vector spend and fresh encrypted-export/standalone-recovery spend on dedicated loopback synthetic chains. It cannot silently count those cases as skipped success under the added command.

## Evidence and remaining qualification

Author receipts pinned to the reviewed source were inspected, including log summaries:

- ux-vault coverage: 375 tests in 14 files passed; package build/typecheck/lint passed.
- Standalone recovery Node suite: 23 passed, zero skips.
- Existing workflow guard suite: 5 passed, zero skips.
- i18n validation: exit 0.
- Required local native attempt: exit 1, `REQUIRE_ANVIL=1 but anvil=false cast=false`; zero native passes. This remains a missing local prerequisite, not native acceptance.

The author is running the web qualification separately. Final combined tests/builds and exact-final-head hosted browser, native recovery and other required gates remain integration prerequisites. This reviewer changed no repository source, worktree state, refs or remote state and ran no runtime/native tests.

#!/usr/bin/env python3
"""Losslessly inventory/package GhostPay receipts and logs. Standard library only.

No repository/ref/remote changes. Final receipts require an explicit completion marker.
"""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import sys
import tarfile
import tempfile

ARCHIVE = "followup-evidence.tar.gz"
BLOCKED = {"node_modules", ".git", "dist", "coverage", "builds", "site"}
LOG_KEYS = {"log", "log_path", "stdout_path", "stderr_path"}
PIN = re.compile(r"^[0-9a-f]{40}$")
HASH = re.compile(r"^[0-9a-f]{64}$")


class EvidenceError(Exception):
    pass


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + "\n").encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def signature(path):
    st = path.stat()
    return (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def walk(value, pointer=""):
    if isinstance(value, dict):
        yield pointer, value
        for key, item in value.items():
            yield from walk(item, pointer + "/" + key.replace("~", "~0").replace("/", "~1"))
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from walk(item, pointer + "/" + str(index))


def pins(doc):
    return [{"pointer": pointer + "/" + key, "value": value}
            for pointer, obj in walk(doc) for key, value in obj.items()
            if isinstance(value, str) and PIN.fullmatch(value)
            and any(word in key for word in ("source", "tree", "head", "base", "donor", "merge", "commit", "claim"))]


class Collection:
    def __init__(self, root, budget):
        self.root, self.budget = root.resolve(), budget
        self.entries, self.contents, self.signatures = {}, {}, {}
        self.size = 0

    def resolve(self, value):
        path = Path(value)
        path = path if path.is_absolute() else self.root / path
        if path.is_symlink():
            raise EvidenceError(f"Expected original regular file, not symlink: {path}")
        try:
            path = path.resolve(strict=True)
            relative = path.relative_to(self.root)
        except (FileNotFoundError, ValueError) as error:
            raise EvidenceError(f"Missing evidence or path outside scratch root: {path}") from error
        if not path.is_file() or any(part in BLOCKED for part in relative.parts):
            raise EvidenceError(f"Not an allowed receipt/log file: {path}")
        if path.name.endswith((".tar", ".tar.gz", ".zip")):
            raise EvidenceError(f"Nested archives intentionally excluded: {path}")
        return path, relative.as_posix()

    def add(self, value, role, group=None, reference=None, expected=None):
        path, relative = self.resolve(value)
        key = str(path)
        if key not in self.entries:
            before = signature(path)
            if self.size + before[2] > self.budget:
                raise EvidenceError("Selected evidence exceeds the byte budget")
            raw = path.read_bytes()
            after = signature(path)
            if before != after or len(raw) != before[2]:
                raise EvidenceError(f"Evidence changed during read: {path}")
            self.size += len(raw)
            self.contents[key], self.signatures[key] = raw, after
            self.entries[key] = {"original_path": key, "archive_path": "raw/" + relative,
                                 "bytes": len(raw), "sha256": digest(raw),
                                 "roles": [], "groups": [], "references": []}
        entry = self.entries[key]
        if expected is not None and (not isinstance(expected, str) or not HASH.fullmatch(expected) or expected != entry["sha256"]):
            raise EvidenceError(f"Recorded log hash does not match original: {path}")
        for category, value in (("roles", role), ("groups", group), ("references", reference)):
            if value and value not in entry[category]:
                entry[category].append(value)
        return entry, self.contents[key]

    def unchanged(self):
        for path, previous in self.signatures.items():
            if signature(Path(path)) != previous:
                raise EvidenceError(f"Evidence changed after inventory: {path}")


def referenced_logs(collection, doc, receipt, group):
    records, unlogged, simulations = [], [], []
    for pointer, obj in walk(doc):
        items = [(key, value) for key, value in obj.items() if isinstance(value, str)
                 and (key in LOG_KEYS or (Path(value).is_absolute() and value.endswith(".log")))]
        for key, value in items:
            expected = obj.get("log_sha256", obj.get("sha256")) if key in {"log", "log_path"} else None
            entry, raw = collection.add(value, "original log", group, {"receipt": receipt, "pointer": pointer + "/" + key}, expected)
            lines = [line.strip() for line in raw.decode("utf-8", errors="replace").splitlines()
                     if re.match(r"^\s*(?:Test Files\b|Tests\s|ℹ (?:tests|pass|fail|skipped|cancelled)\b|# (?:tests|pass|fail|skipped|cancelled)\b)", line)]
            records.append({"group": group, "receipt": receipt, "pointer": pointer,
                            "log": entry["original_path"], "archive_path": entry["archive_path"],
                            "name": obj.get("name", obj.get("check", obj.get("gate"))),
                            "exit_code": obj.get("exit_code"), "expected_outcome": obj.get("expected_outcome"),
                            "outcome_verified": obj.get("outcome_verified"), "summary_lines": lines[-12:]})
        if "command" in obj and "exit_code" in obj and not items:
            unlogged.append({"group": group, "receipt": receipt, "pointer": pointer, "record": obj})
        if "expected_pass" in obj and "exit_code" in obj:
            simulations.append({"group": group, "receipt": receipt, "pointer": pointer, "record": obj,
                                "kind": "synthetic report-gate validation; not native/browser execution"})
    return records, unlogged, simulations


def completed_final(args, selection, collection):
    if not args.final_complete:
        return None
    entry, raw = collection.add(args.final_complete, "final completion declaration", "root-final-combined")
    marker = json.loads(raw)
    if (marker.get("format") != "ghostpay-final-qualification-completion/1" or marker.get("state") != "completed"
            or marker.get("source") != selection["source"] or marker.get("tree") != selection["tree"]):
        raise EvidenceError("Final marker must declare completed qualification at selected source/tree")
    receipts = marker.get("receipts")
    if not isinstance(receipts, list) or not receipts or any(not isinstance(x, str) for x in receipts) or len(set(receipts)) != len(receipts):
        raise EvidenceError("Completion marker needs a nonempty unique list of final receipt paths")
    final_dir = (collection.root / selection["pending_final_directory"]).resolve()
    resolved = set()
    for receipt in receipts:
        path, _ = collection.resolve(receipt)
        if path.parent != final_dir or path.suffix != ".json":
            raise EvidenceError(f"Final receipt must be a direct JSON file in {final_dir}: {path}")
        _, receipt_raw = collection.add(path, "receipt or review", "root-final-combined")
        doc = json.loads(receipt_raw)
        if doc.get("source", doc.get("source_commit")) != selection["source"] or doc.get("tree", doc.get("source_tree")) != selection["tree"]:
            raise EvidenceError(f"Final receipt has wrong source/tree: {path}")
        results = doc.get("results")
        if not isinstance(results, list) or not results or any(not isinstance(r, dict) or type(r.get("exit_code")) is not int for r in results):
            raise EvidenceError(f"Final receipt has unfinished/unspecified results: {path}")
        resolved.add(path)
    existing = {p.resolve() for p in final_dir.glob("*.json") if p.resolve() != Path(entry["original_path"])}
    if existing != resolved:
        raise EvidenceError(f"Marker must enumerate every final JSON receipt; missing={sorted(map(str, existing-resolved))}, extra={sorted(map(str, resolved-existing))}")
    return {"id": "root-final-combined", "label": "Root final combined qualification",
            "evidence_class": "new completed qualification on the selected combined source", "receipts": receipts,
            "notes": "Coordinator explicitly declared completion. Actual exit codes are retained; completion does not imply every gate passed."}


def inventory(args):
    selection_path = Path(args.selection).resolve()
    selection = json.loads(selection_path.read_bytes())
    for key in ("source", "tree"):
        if getattr(args, key):
            selection[key] = getattr(args, key)
        if not PIN.fullmatch(selection[key]):
            raise EvidenceError("Source and tree must be full Git IDs")
    root = Path(args.root or selection["scratch_root"])
    collection = Collection(root, args.max_bytes)
    collection.add(selection_path, "selection configuration")
    collection.add(Path(__file__).resolve(), "packaging program")
    groups = list(selection["groups"])
    final = completed_final(args, selection, collection)
    if final:
        groups.append(final)
    reviews = selection.get("final_reviews", []) + args.review
    if reviews:
        groups.append({"id": "root-final-review", "label": "Independent final combined source review",
                       "evidence_class": "read-only review of selected combined source", "receipts": reviews,
                       "notes": "Source review only; this does not replace test/native/hosted evidence."})
    reports, records, unlogged, simulations = [], [], [], []
    for group in groups:
        summaries, logs = [], set()
        for relative in group["receipts"]:
            entry, raw = collection.add(relative, "receipt or review", group["id"])
            if group["id"] == "root-final-review" and any(selection[key].encode() not in raw for key in ("source", "tree")):
                raise EvidenceError(f"Final review must state exact source/tree: {entry['original_path']}")
            source_pins = []
            if Path(relative).suffix == ".json":
                doc = json.loads(raw)
                source_pins = pins(doc)
                refs, absent, cases = referenced_logs(collection, doc, entry["original_path"], group["id"])
                records.extend(refs)
                unlogged.extend(absent)
                simulations.extend(cases)
                logs.update(record["log"] for record in refs)
            summaries.append({"receipt": entry["original_path"], "archive_path": entry["archive_path"], "recorded_source_pins": source_pins})
        reports.append({k: v for k, v in group.items() if k != "receipts"} | {"receipt_count": len(summaries), "unique_raw_logs": len(logs), "receipts": summaries})
    manifest = {"format": "ghostpay-followup-evidence/1", "selected_source": selection["source"], "selected_tree": selection["tree"],
                "final_qualification": "completed receipts included" if final else "pending; running final receipts/logs excluded",
                "pending_final_json_names": [] if final else sorted(p.name for p in (root / selection["pending_final_directory"]).glob("*.json")),
                "limits": selection["global_limits"], "groups": reports, "log_reference_records": records,
                "command_records_without_referenced_raw_log": unlogged, "synthetic_report_gate_records": simulations,
                "files": sorted(collection.entries.values(), key=lambda e: e["archive_path"]), "total_uncompressed_bytes": collection.size,
                "unique_original_log_count": sum("original log" in e["roles"] for e in collection.entries.values()),
                "test_count_aggregation": "none; overlapping test counts are intentionally not added together"}
    collection.unchanged()
    return manifest, collection


def summary(manifest):
    lines = ["# GhostPay followup evidence inventory", "", f"Selected source: `{manifest['selected_source']}`  ", f"Selected tree: `{manifest['selected_tree']}`", "",
             f"Final qualification: **{manifest['final_qualification']}**.", "",
             f"{len(manifest['files'])} original files, including {manifest['unique_original_log_count']} distinct raw logs; {manifest['total_uncompressed_bytes']:,} uncompressed bytes. Overlapping test totals are not summed.", "",
             "| Evidence family | Receipt/review files | Distinct raw logs | Interpretation |", "|---|---:|---:|---|"]
    for group in manifest["groups"]:
        lines.append(f"| {group['label']} | {group['receipt_count']} | {group['unique_raw_logs']} | {group['evidence_class']} |")
    lines += ["", "## Source and result boundaries", ""]
    lines.extend(f"- **{g['label']}:** {g['notes']}" for g in manifest["groups"])
    lines += ["", "## Nonzero log-backed commands retained", ""]
    seen = set()
    for record in manifest["log_reference_records"]:
        if record["exit_code"] not in (None, 0) and record["log"] not in seen:
            seen.add(record["log"])
            expected = f" Expected outcome: {record['expected_outcome']}." if record["expected_outcome"] else ""
            lines.append(f"- `{record['group']}` / `{record['name']}`: exit {record['exit_code']}; `{record['archive_path']}`.{expected}")
    lines += ["", "Synthetic report-gate checks are separate inventory entries; their expected refusals are not native/browser failures or passes.", "",
              "Commands with no original raw-log reference remain explicitly listed as receipt-only evidence. No missing log is reconstructed.", "", "## Packaging limits", ""]
    lines.extend("- " + limit for limit in manifest["limits"])
    if manifest["pending_final_json_names"]:
        lines += ["", "Final-directory JSON names observed but excluded pending completion: " + ", ".join(f"`{n}`" for n in manifest["pending_final_json_names"]) + "."]
    return ("\n".join(lines) + "\n").encode()


def verify_archive(path, manifest_raw, summary_raw, raw_sums):
    manifest = json.loads(manifest_raw)
    expected = {e["archive_path"]: (e["sha256"], e["bytes"]) for e in manifest["files"]}
    for name, raw in (("MANIFEST.json", manifest_raw), ("SUMMARY.md", summary_raw), ("RAW_SHA256SUMS", raw_sums)):
        expected[name] = (digest(raw), len(raw))
    seen = set()
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            if member.name in seen or member.name not in expected or not member.isfile():
                raise EvidenceError(f"Unexpected/duplicate/nonregular archive member: {member.name}")
            seen.add(member.name)
            stream = archive.extractfile(member)
            hasher, size = hashlib.sha256(), 0
            for chunk in iter(lambda: stream.read(1 << 20), b""):
                hasher.update(chunk)
                size += len(chunk)
            if (hasher.hexdigest(), size) != expected[member.name]:
                raise EvidenceError(f"Archive readback mismatch: {member.name}")
    if seen != set(expected):
        raise EvidenceError("Archive lacks expected members")
    return len(seen)


def package(args, manifest, collection):
    if not args.final_complete and not args.completed_only:
        raise EvidenceError("Use --final-complete MARKER, or --completed-only for an explicitly nonfinal snapshot")
    output = Path(args.output).absolute()
    if output.exists():
        raise EvidenceError(f"Refusing to overwrite existing output directory: {output}")
    output.parent.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(output.parent).free < collection.size + 16 * 1024 * 1024:
        raise EvidenceError("Insufficient archive headroom")
    manifest_raw, summary_raw = encoded(manifest), summary(manifest)
    raw_sums = "".join(f"{e['sha256']}  {e['archive_path']}\n" for e in manifest["files"]).encode()
    with tempfile.TemporaryDirectory(prefix=".followup-evidence-", dir=output.parent) as temporary:
        stage = Path(temporary)
        archive_path = stage / ARCHIVE
        with archive_path.open("wb") as target, gzip.GzipFile(filename="", mode="wb", fileobj=target, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode="w") as archive:
            payloads = [(e["archive_path"], collection.contents[e["original_path"]]) for e in manifest["files"]]
            payloads += [("MANIFEST.json", manifest_raw), ("SUMMARY.md", summary_raw), ("RAW_SHA256SUMS", raw_sums)]
            for name, raw in sorted(payloads):
                member = tarfile.TarInfo(name)
                member.size, member.mode, member.mtime = len(raw), 0o644, 0
                archive.addfile(member, io.BytesIO(raw))
        checked = verify_archive(archive_path, manifest_raw, summary_raw, raw_sums)
        collection.unchanged()
        verification = {"format": "ghostpay-evidence-readback/1", "archive": ARCHIVE,
                        "archive_sha256": digest(archive_path.read_bytes()), "archive_bytes": archive_path.stat().st_size,
                        "verified_members": checked, "verified_original_files": len(manifest["files"]), "verified_original_bytes": collection.size,
                        "source": manifest["selected_source"], "tree": manifest["selected_tree"], "final_qualification": manifest["final_qualification"],
                        "readback": "every original stream matched SHA-256 and size; no extra members"}
        for name, raw in (("MANIFEST.json", manifest_raw), ("SUMMARY.md", summary_raw), ("RAW_SHA256SUMS", raw_sums), ("VERIFICATION.json", encoded(verification))):
            (stage / name).write_bytes(raw)
        sums = "".join(f"{digest(p.read_bytes())}  {p.name}\n" for p in sorted(stage.iterdir()) if p.is_file())
        (stage / "SHA256SUMS").write_text(sums)
        os.rename(stage, output)
    return verification


def verify_package(directory):
    directory = Path(directory)
    required = {ARCHIVE, "MANIFEST.json", "SUMMARY.md", "RAW_SHA256SUMS", "VERIFICATION.json"}
    seen = set()
    for line in (directory / "SHA256SUMS").read_text().splitlines():
        expected, name = line.split("  ", 1)
        if name not in required or name in seen or not HASH.fullmatch(expected):
            raise EvidenceError("Malformed package checksum list")
        seen.add(name)
        if digest((directory / name).read_bytes()) != expected:
            raise EvidenceError(f"Package checksum mismatch: {name}")
    if seen != required:
        raise EvidenceError("Package checksum list is incomplete")
    verification = json.loads((directory / "VERIFICATION.json").read_bytes())
    path = directory / ARCHIVE
    if digest(path.read_bytes()) != verification["archive_sha256"]:
        raise EvidenceError("Archive checksum mismatch")
    count = verify_archive(path, (directory / "MANIFEST.json").read_bytes(), (directory / "SUMMARY.md").read_bytes(), (directory / "RAW_SHA256SUMS").read_bytes())
    if count != verification["verified_members"]:
        raise EvidenceError("Verified member count changed")
    return verification


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=["inventory", "package", "verify"])
    parser.add_argument("--selection", default=str(Path(__file__).with_name("followup-evidence-selection.json")))
    parser.add_argument("--root", help="Override scratch root")
    parser.add_argument("--source", help="Override selected full source SHA; receipts remain unchanged")
    parser.add_argument("--tree", help="Override selected full tree SHA; receipts remain unchanged")
    parser.add_argument("--final-complete", help="Coordinator completion marker listing every final receipt")
    parser.add_argument("--review", action="append", default=[], help="Additional final review stating exact source/tree")
    parser.add_argument("--max-bytes", type=int, default=64 * 1024 * 1024)
    parser.add_argument("--inventory", help="New inventory JSON path")
    parser.add_argument("--summary", help="New summary Markdown path")
    parser.add_argument("--output", help="New package directory, or existing package for verify")
    parser.add_argument("--completed-only", action="store_true", help="Explicit nonfinal snapshot excluding running final qualification")
    args = parser.parse_args()
    try:
        if args.mode == "verify":
            if not args.output:
                parser.error("verify requires --output")
            result = verify_package(args.output)
        else:
            manifest, collection = inventory(args)
            if args.mode == "inventory":
                if not args.inventory or not args.summary:
                    parser.error("inventory requires --inventory and --summary")
                for name in (args.inventory, args.summary):
                    if Path(name).exists():
                        raise EvidenceError(f"Refusing to overwrite existing artifact: {name}")
                Path(args.inventory).write_bytes(encoded(manifest))
                Path(args.summary).write_bytes(summary(manifest))
                result = {"files": len(manifest["files"]), "logs": manifest["unique_original_log_count"], "uncompressed_bytes": collection.size,
                          "final_qualification": manifest["final_qualification"], "inventory": args.inventory, "summary": args.summary}
            else:
                if not args.output:
                    parser.error("package requires --output")
                result = package(args, manifest, collection)
        print(json.dumps(result, indent=2))
        return 0
    except (EvidenceError, OSError, ValueError, tarfile.TarError, EOFError) as error:
        print(f"evidence error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

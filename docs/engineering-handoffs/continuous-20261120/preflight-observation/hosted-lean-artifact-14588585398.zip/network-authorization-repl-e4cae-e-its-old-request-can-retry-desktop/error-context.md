# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: network-authorization.spec.ts >> replacing an invoice aborts a renewed preflight grant before its old request can retry
- Location: e2e/network-authorization.spec.ts:133:1

# Error details

```
Error: expect(received).toHaveLength(expected)

Expected length: 9
Received length: 15
Received array:  [{"_guid": "request@ddabf8801ec1ea665734ed9e06d4970c", "_type": "Request"}, {"_guid": "request@7e7cbecb474261e46c33d710f88b6823", "_type": "Request"}, {"_guid": "request@c10e233d413a478f90932bc8e3d327ce", "_type": "Request"}, {"_guid": "request@e0729d38f8be13f5cfca9f1b0609a27d", "_type": "Request"}, {"_guid": "request@483a110ca55552bbc6bab0a295aae356", "_type": "Request"}, {"_guid": "request@621a52eb9a7410ab5f7c9b5d162969f2", "_type": "Request"}, {"_guid": "request@0c29ce610ec883038b93f525f969b482", "_type": "Request"}, {"_guid": "request@2bd4212cf7947824d2359dfd0c3b2d42", "_type": "Request"}, {"_guid": "request@2e71d65a662deb7e9778bb3d6f7f0d38", "_type": "Request"}, {"_guid": "request@b05b221a112fe75fda850aa0710c9d45", "_type": "Request"}, …]
```

# Page snapshot

```yaml
- generic [ref=f1e2]:
  - link "Skip to content" [ref=f1e3] [cursor=pointer]:
    - /url: "#main"
  - banner [ref=f1e4]:
    - heading "GhostPay" [level=1] [ref=f1e5]
    - paragraph [ref=f1e6]: Stealth-address payments. Everything runs in your browser. Unaudited software.
    - navigation "Main" [ref=f1e7]:
      - list [ref=f1e8]:
        - listitem [ref=f1e9]:
          - button "Home" [ref=f1e10] [cursor=pointer]
        - listitem [ref=f1e11]:
          - button "Seller keys" [ref=f1e12] [cursor=pointer]
        - listitem [ref=f1e13]:
          - button "Create invoice" [ref=f1e14] [cursor=pointer]
        - listitem [ref=f1e15]:
          - button "Pay" [ref=f1e16] [cursor=pointer]
        - listitem [ref=f1e17]:
          - button "Scan and receive" [ref=f1e18] [cursor=pointer]
        - listitem [ref=f1e19]:
          - button "Sweep" [ref=f1e20] [cursor=pointer]
        - listitem [ref=f1e21]:
          - button "Public registry" [ref=f1e22] [cursor=pointer]
        - listitem [ref=f1e23]:
          - button "Settings" [ref=f1e24] [cursor=pointer]
        - listitem [ref=f1e25]:
          - button "About and privacy" [ref=f1e26] [cursor=pointer]
  - main [active] [ref=f1e27]:
    - note [ref=f1e28]:
      - strong [ref=f1e29]:
        - generic [aria-hidden] [ref=f1e30]: ℹ
        - text: Note
        - generic [ref=f1e31]: ":"
      - generic [ref=f1e32]:
        - paragraph [ref=f1e33]: Each network action authorizes only its displayed endpoint and purpose. Changing settings, locking, or cancelling revokes pending access. Offline wallet and invoice tools remain available.
        - button "Cancel network activity" [ref=f1e34] [cursor=pointer]
    - note [ref=f1e35]:
      - strong [ref=f1e36]:
        - generic [aria-hidden] [ref=f1e37]: ⚠
        - text: These seller keys have no backup
        - generic [ref=f1e38]: ":"
      - generic [ref=f1e39]:
        - text: They exist only in this tab. If it closes, reloads or crashes before you back them up, every payment sent to their meta-address is lost. Until then the idle lock leaves them loaded.
        - button "Back up now" [ref=f1e40] [cursor=pointer]
    - region "Review payment" [ref=f1e41]:
      - heading "Review payment" [level=2] [ref=f1e42]
      - region "Invoice signer verification" [ref=f1e43]:
        - heading "Invoice signer verification" [level=3] [ref=f1e44]
        - status [ref=f1e45]:
          - note [ref=f1e46]:
            - strong [ref=f1e47]:
              - generic [aria-hidden] [ref=f1e48]: ℹ
              - text: Note
              - generic [ref=f1e49]: ":"
            - generic [ref=f1e50]: Valid signature — no matching signer pin is configured.
        - paragraph [ref=f1e51]: A signature proves control of the signing key and protects the signed invoice fields. A trusted pin is only as reliable as the channel you used to confirm that key. Neither proves a legal identity or that a payment occurred.
        - paragraph [ref=f1e52]:
          - text: "Invoice signing public key:"
          - code [ref=f1e53]: 0301ed0be3c0e51442f51d27d56d186fb3a8da91d28cbc5211fc7ebcdbb7df1241
        - generic [ref=f1e54]:
          - generic [ref=f1e55]: Expected seller (optional)
          - combobox "Expected seller (optional)" [ref=f1e56]:
            - option "No expected seller selected" [selected]
          - paragraph [ref=f1e57]: Choose the seller you intend to pay. Only that seller’s exact saved key can satisfy this selection, even if you have saved other sellers.
        - paragraph [ref=f1e58]: Names and public signer pins are saved in plain text in this browser only. Invoice contents and private keys are never saved here. Your selection lasts until you leave this view; select the intended seller again after a reload.
        - button "Add a signer pin" [ref=f1e60] [cursor=pointer]
      - note [ref=f1e61]:
        - strong [ref=f1e62]:
          - generic [aria-hidden] [ref=f1e63]: ⚠
          - text: Signature
          - generic [ref=f1e64]: ":"
        - generic [ref=f1e65]: Signature matches key 0301ed0be3c0e51442f51d27d56d186fb3a8da91d28cbc5211fc7ebcdbb7df1241 (not pinned). This only shows the link was not altered by someone without that key.
      - generic [ref=f1e66]:
        - term [ref=f1e67]: Chain
        - definition [ref=f1e68]: Base Sepolia
        - term [ref=f1e69]: Token
        - definition [ref=f1e70]: ETH (native coin)
        - term [ref=f1e71]: Invoice total
        - definition [ref=f1e72]:
          - strong [ref=f1e73]: 0.5 ETH
          - text: (fixed token amount)
        - term [ref=f1e74]: Seller-stated fiat total
        - definition [ref=f1e75]: USD 50.00 (not converted or checked by this app)
        - term [ref=f1e76]: Pricing
        - definition [ref=f1e77]: "Fixed: 0.5 ETH"
        - term [ref=f1e78]: Who pays the checkout fee
        - definition [ref=f1e79]: Seller (deducted from the amount)
        - term [ref=f1e80]: Invoice expires
        - definition [ref=f1e81]: 2026-11-21 00:17:03 UTC
        - term [ref=f1e82]: Seller meta-address
        - definition [ref=f1e83]:
          - code [ref=f1e84]: st:eth:0x0353b6cce…aea3396c
        - term [ref=f1e85]: Seller fingerprint
        - definition [ref=f1e86]:
          - code [ref=f1e87]: deff-6365-c93a-5c2c-8a2b
          - text: (compare with the seller by another channel)
        - term [ref=f1e88]: Private part
        - definition [ref=f1e89]: Private invoice fields decrypted here with a key from the link
      - region "Line items" [ref=f1e90]:
        - table "Line items" [ref=f1e91]:
          - caption [ref=f1e92]: Line items
          - rowgroup [ref=f1e93]:
            - row [ref=f1e94]:
              - columnheader "Description" [ref=f1e95]
              - columnheader "Qty" [ref=f1e96]
              - columnheader "Unit" [ref=f1e97]
          - rowgroup [ref=f1e98]:
            - row [ref=f1e99]:
              - cell "Replacement network invoice" [ref=f1e100]
              - cell "1" [ref=f1e101]
              - cell "USD 50.00" [ref=f1e102]
        - paragraph [ref=f1e103]: "Tax (0 %): USD 0.00"
      - button "Print bill" [ref=f1e104] [cursor=pointer]
      - generic [ref=f1e105]:
        - term [ref=f1e106]: You pay (gross)
        - definition [ref=f1e107]: 0.5 ETH
        - term [ref=f1e108]: Checkout fee (0.25 %)
        - definition [ref=f1e109]: 0.00125 ETH
        - term [ref=f1e110]: Seller receives (net)
        - definition [ref=f1e111]: 0.49875 ETH
        - term [ref=f1e112]: Contract (router)
        - definition [ref=f1e113]:
          - code [ref=f1e114]: "0x1111111111111111111111111111111111111111"
        - term [ref=f1e115]: Fee recipient
        - definition [ref=f1e116]:
          - code [ref=f1e117]: "0x4444444444444444444444444444444444444444"
        - term [ref=f1e118]: Destination
        - definition [ref=f1e119]: A fresh one-time (stealth) address is derived when the payment is prepared and shown before you send.
      - region "Import a seller receipt" [ref=f1e120]:
        - heading "Import a seller receipt" [level=3] [ref=f1e121]
        - paragraph [ref=f1e122]: This checks the receipt signature against the current signed invoice, chain, asset and exact seller amount. If this page has a transaction hash or prepared one-time address, those are checked too. A seller signature proves control of a key and does not independently prove an on-chain payment or seller identity.
        - paragraph [ref=f1e123]: A receipt may reveal a private amount, transaction and invoice association on this screen.
        - generic [ref=f1e124]:
          - checkbox "I consent to opening private receipt details on this screen." [ref=f1e125]
          - text: I consent to opening private receipt details on this screen.
        - generic [ref=f1e126]:
          - generic [ref=f1e127]:
            - generic [ref=f1e128]: Signed seller receipt JSON
            - button "Signed seller receipt JSON" [ref=f1e129]
            - button "About Signed seller receipt JSON" [ref=f1e131] [cursor=pointer]: "?"
          - generic [ref=f1e132]:
            - generic [ref=f1e133]: Explicitly trusted signer key (optional)
            - textbox "Explicitly trusted signer key (optional)" [ref=f1e134]:
              - /placeholder: 02… or 03…
            - paragraph [ref=f1e135]: Use only a compressed public key you verified with the seller through another channel. Leave blank to require the receipt key to match the valid invoice-signing key.
          - button "Check receipt against this invoice" [ref=f1e136] [cursor=pointer]
        - region "Scan or paste a seller receipt" [ref=f1e137]:
          - heading "Scan or paste a seller receipt" [level=3] [ref=f1e138]
          - paragraph [ref=f1e139]: Camera access starts only when you choose it. Scanned text is checked on this device.
          - generic [ref=f1e140]:
            - button "Scan with camera" [disabled] [ref=f1e141]
            - generic [ref=f1e142]:
              - text: Or paste QR text
              - textbox "Or paste QR text" [ref=f1e143]
            - button "Use pasted text" [disabled] [ref=f1e144]
            - generic [ref=f1e145]:
              - text: Read a QR from an image
              - button "Read a QR from an image" [disabled] [ref=f1e146]
            - status
      - paragraph [ref=f1e147]:
        - text: GhostPay charges 0.25 % on payments made through its checkout contract. The fee goes to
        - code [ref=f1e149]: "0x4444444444444444444444444444444444444444"
        - text: (shown from the deployment manifest, whose signature was verified by a release key built into this app). Paying the stealth address directly costs no GhostPay fee.
      - note [ref=f1e150]:
        - strong [ref=f1e151]:
          - generic [aria-hidden] [ref=f1e152]: ℹ
          - text: What becomes public
          - generic [ref=f1e153]: ":"
        - generic [ref=f1e154]: Your address, the token, the amounts, the fee and the time are public on-chain. The seller’s identity is not revealed by the one-time address.
      - group "Options" [ref=f1e155]:
        - generic [ref=f1e157]:
          - checkbox "Wait a random time first (2 to 15 minutes)" [ref=f1e158]
          - generic [ref=f1e159]: Wait a random time first (2 to 15 minutes)
        - paragraph [ref=f1e160]: Timing friction only, not anonymity. While waiting nothing is signed or sent, and the page must stay open. You can cancel or send now.
      - generic [ref=f1e161]:
        - button "Continue" [ref=f1e162] [cursor=pointer]
        - button "Forget this invoice" [ref=f1e163] [cursor=pointer]
  - status [ref=f1e164]: Network activity cancelled. Start a new action to authorize another request.
  - contentinfo [ref=f1e165]:
    - paragraph [ref=f1e166]: No analytics, no third-party scripts, no remote fonts. Fee and contract addresses come only from the deployment manifest.
    - list [ref=f1e167]:
      - listitem [ref=f1e168]:
        - link "Help and getting started (opens in a new tab)" [ref=f1e169] [cursor=pointer]:
          - /url: ./help.html
          - text: Help and getting started
          - generic [ref=f1e170]: (opens in a new tab)
      - listitem [ref=f1e171]:
        - link "Privacy and verification limits (opens in a new tab)" [ref=f1e172] [cursor=pointer]:
          - /url: ./privacy.html
          - text: Privacy and verification limits
          - generic [ref=f1e173]: (opens in a new tab)
      - listitem [ref=f1e174]:
        - link "Source and attribution (opens in a new tab)" [ref=f1e175] [cursor=pointer]:
          - /url: ./help.html#technology
          - text: Source and attribution
          - generic [ref=f1e176]: (opens in a new tab)
```

# Test source

```ts
  72  | 
  73  | test('saved endpoints authorize no background request and local key/invoice operations work offline', async ({ context, page }) => {
  74  |   const foreign = observeForeignRequests(context);
  75  |   await context.route('**/*', (route) => new URL(route.request().url()).origin === ORIGIN ? route.continue() : route.abort());
  76  |   await configureOnce(page, { [SETTINGS_KEY]: { rpcUrls: { '84532': SWEEP_RPC }, relayerUrl: 'https://relayer.unapproved.e2e.test' } });
  77  |   await page.waitForLoadState('networkidle');
  78  |   expect(foreign).toEqual([]);
  79  | 
  80  |   await context.setOffline(true);
  81  |   await generateKeys(page);
  82  |   const link = await createInvoice(page, { encrypt: true, memo: 'Offline synthetic invoice' });
  83  |   expect(link).toContain('#gpi=v1.');
  84  |   expect(foreign).toEqual([]);
  85  | });
  86  | 
  87  | for (const policy of [
  88  |   { name: 'required private path with direct transport', key: SCAN_KEY, value: { transport: 'direct', requireProxy: true } },
  89  |   { name: 'acknowledged own-node mode', key: PROFILE_KEY, value: { rpcProfile: 'direct', relayerProfile: 'direct', rpcMode: 'own-node', noticeAcknowledged: true } },
  90  |   { name: 'corrupt required-private-path preference', key: SCAN_KEY, value: { transport: 'direct', requireProxy: null } },
  91  |   { name: 'corrupt own-node mode', key: PROFILE_KEY, value: { rpcProfile: 'direct', relayerProfile: 'direct', rpcMode: null, noticeAcknowledged: true } },
  92  | ] as const) {
  93  |   test(`${policy.name} blocks a configured public RPC before dispatch, including after reload`, async ({ context, page }) => {
  94  |     const foreign = observeForeignRequests(context);
  95  |     await context.route('**/*', (route) => new URL(route.request().url()).origin === ORIGIN ? route.continue() : route.abort());
  96  |     await configureOnce(page, { [policy.key]: policy.value });
  97  |     for (let visit = 0; visit < 2; visit++) {
  98  |       if (visit !== 0) await page.reload();
  99  |       await nav(page).getByRole('button', { name: 'Settings', exact: true }).click();
  100 |       await page.getByRole('button', { name: 'Test Base Sepolia', exact: true }).click();
  101 |       await expect(page.getByText(REFUSED).first()).toBeVisible();
  102 |       await page.waitForLoadState('networkidle');
  103 |       expect(foreign).toEqual([]);
  104 |     }
  105 |     expect(await page.evaluate((key) => JSON.parse(localStorage.getItem(key) ?? 'null') as unknown, policy.key)).toEqual(policy.value);
  106 |   });
  107 | }
  108 | 
  109 | test('cancelling a loaded payment does not silently restart payment preflight', async ({ context, page }) => {
  110 |   const foreign = observeForeignRequests(context);
  111 |   const network = await installSweepNetwork(context, page, 'success');
  112 |   await configureOnce(page);
  113 |   await generateKeys(page);
  114 |   const link = await createInvoice(page, { encrypt: true });
  115 |   await page.goto(link);
  116 |   await expect(page.getByRole('heading', { name: 'Review payment', exact: true })).toBeVisible();
  117 |   await page.waitForLoadState('networkidle');
  118 |   expect(network.state.methods).toContain('eth_chainId');
  119 |   const before = foreign.length;
  120 | 
  121 |   await page.getByRole('button', { name: 'Cancel network activity', exact: true }).click();
  122 |   await expect(page.getByText('Network activity cancelled. Start a new action to authorize another request.', { exact: true })).toHaveCount(1);
  123 |   await page.waitForLoadState('networkidle');
  124 |   expect(foreign).toHaveLength(before);
  125 |   await page.getByRole('button', { name: 'Review network access for this invoice', exact: true }).click();
  126 |   await page.waitForLoadState('networkidle');
  127 |   expect(foreign.length).toBeGreaterThan(before);
  128 |   expect(foreign.slice(before).every((request) => new URL(request.url()).origin === SWEEP_RPC)).toBe(true);
  129 |   expect(network.state.raws).toEqual([]);
  130 |   expect(network.state.unexpected).toEqual([]);
  131 | });
  132 | 
  133 | test('replacing an invoice aborts a renewed preflight grant before its old request can retry', async ({ context, page }) => {
  134 |   const foreign = observeForeignRequests(context);
  135 |   const network = await installSweepNetwork(context, page, 'success');
  136 |   await configureOnce(page);
  137 |   await generateKeys(page);
  138 |   const original = await createInvoice(page, { encrypt: true, description: 'Initial network invoice' });
  139 |   const replacement = await createInvoice(page, { encrypt: true, description: 'Replacement network invoice' });
  140 |   await page.goto(original);
  141 |   await expect(page.getByRole('heading', { name: 'Review payment', exact: true })).toBeVisible();
  142 |   await page.waitForLoadState('networkidle');
  143 |   await page.getByRole('button', { name: 'Cancel network activity', exact: true }).click();
  144 | 
  145 |   let heldRequest: Request | undefined;
  146 |   let release: (() => void) | undefined;
  147 |   let released = false;
  148 |   await context.route(`${SWEEP_RPC}/**`, async (route) => {
  149 |     const request = route.request();
  150 |     if (heldRequest !== undefined || rpcRequest(request)?.method !== 'eth_chainId') return route.fallback();
  151 |     heldRequest = request;
  152 |     await new Promise<void>((resolve) => { release = resolve; });
  153 |     await route.abort('failed');
  154 |     released = true;
  155 |   });
  156 |   await page.getByRole('button', { name: 'Review network access for this invoice', exact: true }).click();
  157 |   await expect.poll(() => heldRequest !== undefined).toBe(true);
  158 |   // This is a same-document invoice replacement, so the Pay component's own cleanup must revoke the renewed grant.
  159 |   await page.goto(replacement);
  160 |   await expect(page.getByText('Replacement network invoice', { exact: true })).toBeVisible();
  161 |   await expect.poll(() => {
  162 |     const failure = heldRequest?.failure();
  163 |     return failure !== undefined && failure !== null;
  164 |   }).toBe(true);
  165 |   await page.waitForLoadState('networkidle');
  166 |   expect(network.state.methods.filter((method) => method === 'eth_chainId')).toHaveLength(2);
  167 |   const before = foreign.length;
  168 |   if (release === undefined) throw new Error('Expected the renewed preflight request to be held');
  169 |   release();
  170 |   await expect.poll(() => released).toBe(true);
  171 |   await page.waitForLoadState('networkidle');
> 172 |   expect(foreign).toHaveLength(before);
      |                   ^ Error: expect(received).toHaveLength(expected)
  173 |   expect(network.state.raws).toEqual([]);
  174 |   expect(network.state.unexpected).toEqual([]);
  175 | });
  176 | 
  177 | test('replacing Settings in a second tab does not authorize a loaded payment to contact the new provider', async ({ context, page }) => {
  178 |   const foreign = observeForeignRequests(context);
  179 |   const network = await installSweepNetwork(context, page, 'success');
  180 |   await configureOnce(page);
  181 |   await generateKeys(page);
  182 |   const link = await createInvoice(page, { encrypt: true });
  183 |   await page.goto(link);
  184 |   await expect(page.getByRole('heading', { name: 'Review payment', exact: true })).toBeVisible();
  185 |   await page.waitForLoadState('networkidle');
  186 |   expect(network.state.methods).toContain('eth_chainId');
  187 |   const before = foreign.length;
  188 | 
  189 |   const other = await context.newPage();
  190 |   await other.goto('/');
  191 |   await nav(other).getByRole('button', { name: 'Settings', exact: true }).click();
  192 |   await other.getByLabel('Base Sepolia RPC URL', { exact: true }).fill(NEXT_RPC);
  193 |   const replaced = page.evaluate((key) => new Promise<void>((resolve) => {
  194 |     const onStorage = (event: StorageEvent): void => {
  195 |       if (event.key !== key) return;
  196 |       window.removeEventListener('storage', onStorage);
  197 |       resolve();
  198 |     };
  199 |     window.addEventListener('storage', onStorage);
  200 |   }), SETTINGS_KEY);
  201 |   await other.getByRole('button', { name: 'Save settings', exact: true }).click();
  202 |   await expect(other.getByText('Settings saved.', { exact: true })).toBeVisible();
  203 |   await replaced;
  204 |   await page.waitForLoadState('networkidle');
  205 |   expect(foreign).toHaveLength(before);
  206 |   expect(foreign.filter((request) => new URL(request.url()).origin === NEXT_RPC)).toEqual([]);
  207 |   expect(network.state.raws).toEqual([]);
  208 |   expect(network.state.unexpected).toEqual([]);
  209 | });
  210 | 
  211 | test('an open Settings form adopts another tab’s endpoint without silently overwriting or contacting it', async ({ context, page }) => {
  212 |   const foreign = observeForeignRequests(context);
  213 |   await context.route('**/*', (route) => new URL(route.request().url()).origin === ORIGIN ? route.continue() : route.abort());
  214 |   await configureOnce(page);
  215 |   await nav(page).getByRole('button', { name: 'Settings', exact: true }).click();
  216 |   const firstEndpoint = page.getByLabel('Base Sepolia RPC URL', { exact: true });
  217 |   await expect(firstEndpoint).toHaveValue(new URL(SWEEP_RPC).href);
  218 |   const other = await context.newPage();
  219 |   await other.goto('/');
  220 |   await nav(other).getByRole('button', { name: 'Settings', exact: true }).click();
  221 |   await other.getByLabel('Base Sepolia RPC URL', { exact: true }).fill(NEXT_RPC);
  222 |   await other.getByRole('button', { name: 'Save settings', exact: true }).click();
  223 |   await expect(other.getByText('Settings saved.', { exact: true })).toBeVisible();
  224 |   await expect(firstEndpoint).toHaveValue(new URL(NEXT_RPC).href);
  225 | 
  226 |   await page.getByRole('button', { name: 'Save settings', exact: true }).click();
  227 |   await expect(page.getByText('Settings saved.', { exact: true })).toBeVisible();
  228 |   const saved = await page.evaluate((key) => JSON.parse(localStorage.getItem(key) ?? 'null') as { rpcUrls: Record<string, string> }, SETTINGS_KEY);
  229 |   expect(saved.rpcUrls['84532']).toBe(new URL(NEXT_RPC).href);
  230 |   await page.waitForLoadState('networkidle');
  231 |   expect(foreign).toEqual([]);
  232 | });
  233 | 
  234 | test('Sweep entry and reentry send no balance request until a new explicit action', async ({ context, page }) => {
  235 |   const foreign = observeForeignRequests(context);
  236 |   const network = await installSweepNetwork(context, page, 'success');
  237 |   await configureOnce(page);
  238 |   const meta = await generateKeys(page);
  239 |   const payment = network.setPayment(meta);
  240 |   await scanPayment(page);
  241 |   const count = (): number => foreign.filter((request) => isBalanceRead(request, payment.stealthAddress)).length;
  242 |   const before = count();
  243 |   await openSweep(page);
  244 |   await page.waitForLoadState('networkidle');
  245 |   expect(count()).toBe(before);
  246 |   await expect(sweep(page).getByText('5 USDC', { exact: true })).toHaveCount(0);
  247 | 
  248 |   await readBalance(page).click();
  249 |   await expect(sweep(page).getByText('5 USDC', { exact: true })).toBeVisible();
  250 |   expect(count()).toBe(before + 1);
  251 |   await nav(page).getByRole('button', { name: 'Home', exact: true }).click();
  252 |   await nav(page).getByRole('button', { name: 'Sweep', exact: true }).click();
  253 |   await expect(readBalance(page)).toBeVisible();
  254 |   await page.waitForLoadState('networkidle');
  255 |   expect(count()).toBe(before + 1);
  256 |   await expect(sweep(page).getByText('5 USDC', { exact: true })).toHaveCount(0);
  257 |   await readBalance(page).click();
  258 |   await expect(sweep(page).getByText('5 USDC', { exact: true })).toBeVisible();
  259 |   expect(count()).toBe(before + 2);
  260 |   expect(network.state.raws).toEqual([]);
  261 |   expect(network.state.unexpected).toEqual([]);
  262 | });
  263 | 
  264 | test('a real second-tab endpoint replacement cancels stale balance delivery and requires another click', async ({ context, page }) => {
  265 |   const foreign = observeForeignRequests(context);
  266 |   const network = await installSweepNetwork(context, page, 'success');
  267 |   await configureOnce(page);
  268 |   const meta = await generateKeys(page);
  269 |   const payment = network.setPayment(meta);
  270 |   await scanPayment(page);
  271 |   await openSweep(page);
  272 | 
```
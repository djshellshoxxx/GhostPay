import datetime, hashlib, json, os, pathlib, subprocess, time
root=pathlib.Path('/workspace/scratch/f80482f352bc/native-idb-ci')
out=pathlib.Path('/workspace/scratch/f80482f352bc/deployment-diagnostic-qualification')
source='e65214c2f13bd7724aec42032e6cfcb40e87aba5'
tree='088fa581964a891a793bdeaef879a42bf1c20725'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()==source
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip()==tree
env=os.environ.copy()
env['NODE_OPTIONS']='--max-old-space-size=2048'
env['npm_config_cache']=str(out/'npm-cache')
env['CI']='1'
gates=[
 ('focused-web',root/'apps/web',['../../node_modules/.bin/vitest','run','src/lib/deployment.test.ts','src/lib/hardening.test.ts','src/lib/manifest.test.ts','src/lib/defaultServices.test.ts','--maxWorkers=1']),
 ('web-typecheck',root,['npm','run','typecheck','-w','@ghostpay/web']),
 ('web-lint',root,['npm','run','lint','-w','@ghostpay/web'])
]
results=[]
for name,cwd,command in gates:
 started=datetime.datetime.now(datetime.timezone.utc).isoformat()
 t=time.monotonic()
 log=out/(name+'.log')
 print('START',name,started,flush=True)
 with log.open('wb') as f:
  result=subprocess.run(command,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
 entry={'name':name,'command':command,'cwd':str(cwd),'source':source,'tree':tree,'started_utc':started,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_seconds':round(time.monotonic()-t,3),'exit_code':result.returncode,'environment_overrides':{k:env[k] for k in ['NODE_OPTIONS','npm_config_cache','CI']},'log':log.name,'log_bytes':log.stat().st_size,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 results.append(entry)
 (out/'gate-results.json').write_text(json.dumps({'source':source,'tree':tree,'results':results},indent=2)+'\n')
 print('DONE',name,'exit',result.returncode,'seconds',entry['elapsed_seconds'],flush=True)
 print(log.read_text(errors='replace')[-6500:],flush=True)
 if result.returncode:
  raise SystemExit(result.returncode)
print('ALL THREE GATES PASSED',flush=True)

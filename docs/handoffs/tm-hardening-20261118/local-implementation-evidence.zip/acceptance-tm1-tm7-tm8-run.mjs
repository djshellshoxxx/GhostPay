import { createHash } from 'node:crypto';
import { closeSync, existsSync, openSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';

const repo = '/workspace/scratch/88088facfb13/GhostPay';
const evidence = '/workspace/scratch/88088facfb13/tm-evidence';
const basename = 'acceptance-tm1-tm7-tm8';
const base = 'f0c15de9b381ac8a13ed3c76781d7fad8b236391';
const testFiles = [
  'src/views/Sweep.privacy.test.tsx',
  'src/views/Sweep.test.tsx',
  'src/lib/sweep.destinations.privacy.test.ts',
  'src/lib/scanCursorSlot.test.ts',
  'src/lib/scanCheckpointPrivacy.test.ts',
  'src/lib/scanClient.test.ts',
];
const pattern = 'Sweep balance read and scan privacy|TM1/TM7:|TM7: a sweep completed|TM7 session-only destination history|SEC-22 scan cursor slot names|checkpoint format reconciliation|localCheckpointStore.*(round-trips a cursor|ignores corrupt data)|WEB-APP-04 / CHAIN-ADAPTERS-03: checkpoints|two-provider replay-tail checkpoint anchor.*cannot persist an old scan';
const trackedFiles = [
  ...testFiles.map((path) => `apps/web/${path}`),
  'apps/web/src/views/Sweep.tsx', 'apps/web/src/lib/sweep.ts',
  'apps/web/src/lib/scanCursorSlot.ts', 'apps/web/src/lib/scanClient.ts',
  'apps/web/src/lib/session.ts', 'apps/web/src/lib/appLock.ts',
  'apps/web/vite.config.ts', 'apps/web/package.json', 'package.json', 'package-lock.json',
  'packages/hygiene/src/ledger.ts', 'packages/hygiene/src/index.ts',
];
const builtFiles = ['packages/hygiene/dist/ledger.js', 'packages/hygiene/dist/index.js'];
const sourceFiles = [...trackedFiles, ...builtFiles];
const hashes = () => Object.fromEntries(sourceFiles.map((path) => [path, existsSync(join(repo, path)) ? createHash('sha256').update(readFileSync(join(repo, path))).digest('hex') : null]));
const git = (...args) => spawnSync('git', args, { cwd: repo, encoding: 'utf8' });
const head = git('rev-parse', 'HEAD').stdout.trim();
const selectedDiff = git('diff', '--quiet', base, '--', ...trackedFiles);
if (selectedDiff.status !== 0) throw new Error('Selected runtime/test/config source differs from requested f0 snapshot');
const before = hashes();
if (Object.values(before).some((hash) => hash === null)) throw new Error('Selected source or built dependency is missing');
const cwd = join(repo, 'apps/web');
const runner = join(repo, 'node_modules/vitest/vitest.mjs');
const args = ['--signal=INT', '--kill-after=10s', '120s', process.execPath, runner,
  'run', ...testFiles, '--maxWorkers=1', '--reporter=verbose', '--testNamePattern', pattern];
const quote = (value) => `'${value.replaceAll("'", "'\\''")}'`;
const record = {
  head, requestedRuntimeBase: base, selectedTrackedSourcesMatchBase: true,
  cwd, command: `NODE_OPTIONS=--max-old-space-size=512 timeout ${args.map(quote).join(' ')}`,
  executable: 'timeout', arguments: args, nodeVersion: process.version,
  nodeOptions: '--max-old-space-size=512', workerLimit: 1, timeoutSeconds: 120, killAfterSeconds: 10,
  testFiles, testNamePattern: pattern, sourceHashesBefore: before,
  startedAt: new Date().toISOString(),
};
writeFileSync(join(evidence, `${basename}.json`), JSON.stringify(record, null, 2) + '\n');
writeFileSync(join(evidence, `${basename}.sha256`), Object.entries(before).map(([path, hash]) => `${hash}  ${path}`).join('\n') + '\n');
console.log(JSON.stringify({ startedAt: record.startedAt, head, command: record.command }));
const log = openSync(join(evidence, `${basename}.log`), 'w');
const started = Date.now();
const child = spawn('timeout', args, { cwd, env: { ...process.env, NODE_OPTIONS: '--max-old-space-size=512' }, stdio: ['ignore', log, log] });
const result = await new Promise((resolve) => {
  child.once('error', (error) => resolve({ exitCode: null, signal: null, error: error.message }));
  child.once('close', (code, signal) => resolve({ exitCode: code, signal }));
});
closeSync(log);
const after = hashes();
const finalRecord = { ...record, ...result, finishedAt: new Date().toISOString(), elapsedMs: Date.now() - started,
  timedOut: result.exitCode === 124 || result.exitCode === 137, sourceHashesAfter: after,
  selectedSourceUnchangedDuringRun: JSON.stringify(before) === JSON.stringify(after) };
writeFileSync(join(evidence, `${basename}.json`), JSON.stringify(finalRecord, null, 2) + '\n');
console.log(JSON.stringify({ ...result, elapsedMs: finalRecord.elapsedMs, timedOut: finalRecord.timedOut, selectedSourceUnchangedDuringRun: finalRecord.selectedSourceUnchangedDuringRun }));
process.exitCode = result.exitCode ?? 1;

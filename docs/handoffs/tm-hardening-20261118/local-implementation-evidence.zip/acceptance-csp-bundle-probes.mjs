import { createHash } from 'node:crypto';
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { scanBundle } from '../GhostPay/apps/web/scripts/scan-bundle.mjs';
import { readMetaPolicies } from '../GhostPay/apps/web/scripts/apply-csp.mjs';

const repo = '/workspace/scratch/88088facfb13/GhostPay';
const evidence = '/workspace/scratch/88088facfb13/tm-evidence';
const origins = ['https://rpc.example.invalid', 'wss://rpc.example.invalid'];
const connect = `connect-src 'self' ${origins.join(' ')}`;
const policy = `default-src 'self'; script-src 'self'; style-src 'self'; ${connect}; object-src 'none'; frame-ancestors 'none'`;
const meta = `<meta http-equiv="Content-Security-Policy" content="${policy}">`;
const html = `<!doctype html><html><head><meta name="referrer" content="no-referrer">${meta}<script type="module" src="./assets/app.js"></script></head><body></body></html>`;
const headers = `/*\n  Content-Security-Policy: ${policy}\n  Referrer-Policy: no-referrer\n  X-Content-Type-Options: nosniff\n  Permissions-Policy: camera=()\n`;
const options = { ownOrigin: '', connectOrigins: origins, requireTight: true };
const cases = [];
const add = (name, mutate, accept = false, diagnostic) => cases.push({ name, mutate, accept, diagnostic });
const htmlCase = (name, transform, accept = false, diagnostic) => add(name, (dir) => writeFileSync(join(dir, 'index.html'), transform(html)), accept, diagnostic);
const replaceMeta = (replacement) => (source) => source.replace(meta, replacement);

add('canonical literal enforcing CSP', () => {}, true);
htmlCase('UTF-16 source offset after astral prefix', (s) => s.replace('<head>', '<head><!-- 🛡️ -->'), true);
htmlCase('ASCII tab separators in source list', (s) => s.replace(origins.join(' '), origins.join('\t')), true);
htmlCase('literal extra configured origin in body', (s) => s.replace('</body>', `${origins[0]}</body>`), false, /unexpected origin/);
htmlCase('configured origin in another CSP directive', (s) => s.replace("object-src 'none'", `img-src ${origins[0]}; object-src 'none'`), false, /unexpected origin/);
htmlCase('configured origin in reporting directive', (s) => s.replace("object-src 'none'", `report-uri ${origins[0]}; object-src 'none'`), false, /unexpected origin/);
htmlCase('configured origin in another meta attribute', (s) => s.replace('http-equiv=', `data-extra="${origins[0]}" http-equiv=`), false, /unexpected origin/);
htmlCase('configured origin in unrelated attribute', (s) => s.replace('</body>', `<div data-extra="${origins[0]}"></div></body>`), false, /unexpected origin/);
htmlCase('configured origin in comment', (s) => s.replace('</body>', `<!-- ${origins[0]} --></body>`), false, /unexpected origin/);
htmlCase('configured origin as remote script', (s) => s.replace('./assets/app.js', `${origins[0]}/app.js`), false, /remote script/);
htmlCase('configured origin as remote stylesheet', (s) => s.replace('</head>', `<link rel="stylesheet" href="${origins[0]}/app.css"></head>`), false, /remote <link>/);
htmlCase('configured origin as remote image', (s) => s.replace('</body>', `<img src="${origins[0]}/x"></body>`), false, /unexpected origin/);

for (const [name, replacement] of [
  ['CSP only in comment', `<!-- ${meta} -->`],
  ['CSP only in template', `<template>${meta}</template>`],
  ['CSP only in noscript', `<noscript>${meta}</noscript>`],
  ['CSP only in text script', `<script type="text/plain">${meta}</script>`],
  ['CSP only in other attribute', `<div data-fake='${meta}'></div>`],
  ['CSP only in body', `</head><body>${meta}`],
  ['CSP after early script', `<script src="./early.js"></script>${meta}`],
  ['CSP after early stylesheet', `<link rel="stylesheet" href="./early.css">${meta}`],
  ['CSP after non-meta title', `<title>GhostPay</title>${meta}`],
  ['CSP after head-closing invalid element', `<div></div>${meta}`],
  ['two early CSP policies', `${meta}${meta}`],
  ['late duplicate CSP policy', `${meta}<script src="./early.js"></script>${meta}`],
  ['duplicate content after real content', meta.replace('>', ' content="connect-src *">')],
  ['duplicate content before real content', meta.replace(' content=', ' content="connect-src *" content=')],
  ['duplicate uppercase content', meta.replace('>', ` CONTENT="${policy}">`)],
  ['duplicate winning http-equiv', meta.replace('>', ' http-equiv="x">')],
  ['duplicate nonwinning http-equiv', meta.replace(' http-equiv=', ' http-equiv="x" http-equiv=')],
  ['unparsed solidus attribute separator', meta.replace(' content=', '/content=')],
  ['entity-encoded matching policy', meta.replaceAll('://', '&#58;//')],
  ['entity-encoded differing policy', meta.replace(origins[0], 'https&#58;//evil.example.invalid')],
  ['duplicate connect-src directive', meta.replace(connect, `${connect}; ${connect}`)],
  ['unconfigured extra origin', meta.replace(connect, `${connect} https://extra.example.invalid`)],
  ['broad connect-src', meta.replace(connect, "connect-src 'self' https: wss:")],
]) htmlCase(name, replaceMeta(replacement));

for (const [name, separator] of [
  ['NBSP', '\u00a0'], ['vertical tab', '\u000b'], ['Unicode line separator', '\u2028'],
  ['zero-width no-break space', '\ufeff'], ['em space', '\u2003'],
]) htmlCase(`${name} must not separate configured origins`, (s) => s.replace(origins.join(' '), origins.join(separator)), false, /ambiguous source|unexpected origin/);

htmlCase('inline script still forbidden', (s) => s.replace('</body>', '<script>alert(1)</script></body>'), false, /inline <script>/);
htmlCase('inline style still forbidden', (s) => s.replace('</body>', '<style>body{color:red}</style></body>'), false, /inline <style>/);
htmlCase('inline handler still forbidden', (s) => s.replace('</body>', '<div onload="alert(1)"></div></body>'), false, /inline event handler/);
htmlCase('unsafe script CSP still forbidden', (s) => s.replace("script-src 'self'", "script-src 'self' 'unsafe-inline'"), false, /unsafe-inline/);

for (const [name, path, body, diagnostic] of [
  ['configured literal remains forbidden in JavaScript', 'assets/app.js', `const endpoint="${origins[0]}";`, /unexpected origin/],
  ['configured literal remains forbidden in CSS', 'assets/app.css', `body{background:url(${origins[0]}/x)}`, /unexpected origin/],
  ['worker network checks remain active', 'assets/scanner.worker.js', `fetch("${origins[0]}");`, /scanner worker contains network API/],
  ['dynamic code checks remain active', 'assets/app.js', 'new Function("return 1")();', /new Function/],
  ['non-index body does not acquire origin exception', 'help.html', html.replace(meta, meta.replace(connect, "connect-src 'none'")).replace('</body>', `${origins[0]}</body>`), /unexpected origin/],
]) add(name, (dir) => writeFileSync(join(dir, path), body), false, diagnostic);

add('matching meta cannot compensate stale header', (dir) => writeFileSync(join(dir, '_headers'), headers.replace(connect, "connect-src 'self' https: wss:")), false, /_headers:.*broad connect-src/);
add('no explicit configuration must not infer allowlist', () => ({ connectOrigins: [], requireTight: false }), false, /unexpected origin/);
add('invalid direct origin configuration remains sanitized', () => ({ connectOrigins: ['https://user:tm5_fixture_secret@rpc.example.invalid'] }), false, /^GHOSTPAY_CONNECT_ORIGINS:(?![\s\S]*tm5_fixture_secret)/);
add('null direct origin configuration fails closed', () => ({ connectOrigins: null }), false, /GHOSTPAY_CONNECT_ORIGINS/);
add('nonboolean tight setting fails closed', () => ({ requireTight: 'false' }), false, /requireTight must be a boolean/);

const sourceFiles = [
  'apps/web/scripts/scan-bundle.mjs', 'apps/web/scripts/scan-bundle.d.mts',
  'apps/web/scripts/apply-csp.mjs', 'apps/web/scripts/apply-csp.d.mts',
  'scripts/tests/privacy-csp-bundle.test.mjs',
];
console.log(JSON.stringify({ sourceHashes: Object.fromEntries(sourceFiles.map((path) => [path, createHash('sha256').update(readFileSync(join(repo, path))).digest('hex')])) }));
let passed = 0;
let failed = 0;
for (const { name, mutate, accept, diagnostic } of cases) {
  const dir = mkdtempSync(join(tmpdir(), 'ghostpay-independent-csp-'));
  try {
    mkdirSync(join(dir, 'assets'));
    writeFileSync(join(dir, 'index.html'), html);
    writeFileSync(join(dir, '_headers'), headers);
    writeFileSync(join(dir, 'assets/app.js'), 'console.log(1);');
    const overrides = mutate(dir) ?? {};
    const problems = scanBundle(dir, undefined, undefined, { ...options, ...overrides });
    const ok = (problems.length === 0) === accept && (diagnostic === undefined || diagnostic.test(problems.join('\n')));
    if (ok) passed++; else failed++;
    console.log(JSON.stringify({ name, ok, expected: accept ? 'accept' : 'reject', problems }));
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
}
for (const profile of ['full', 'lean']) {
  const dir = join(evidence, `isolated-${profile}-tight`);
  const problems = scanBundle(dir, join(repo, 'apps/web/src'), join(repo, 'apps/web/vite.config.ts'), options);
  const extracted = readMetaPolicies(readFileSync(join(dir, 'index.html'), 'utf8'));
  const ok = problems.length === 0 && extracted.length === 1 && extracted[0].beforeResources && extracted[0].content !== undefined;
  if (ok) passed++; else failed++;
  console.log(JSON.stringify({ name: `actual ${profile} Vite tight artifact`, ok, expected: 'accept', problems, extractedPolicyCount: extracted.length }));
}
console.log(JSON.stringify({ passed, failed, syntheticCases: cases.length, actualArtifactScans: 2 }));
if (failed !== 0) process.exitCode = 1;

import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { validateSnapshot } from '../portable-keystore-cleanup/scripts/coordination/reconcile-claims.mjs';
import { EXPECTED_TARGETS } from '../portable-keystore-cleanup/scripts/audit/mythril-evidence.mjs';
const snapshots = ['branch-refresh-698.json', 'branch-ref-snapshot-final.json'];
for (const name of snapshots) {
  const raw = readFileSync(new URL('../' + name, import.meta.url));
  const value = JSON.parse(raw);
  assert.throws(() => validateSnapshot(value), /Invalid repository/);
  console.log(JSON.stringify({ input: name, sha256: createHash('sha256').update(raw).digest('hex'), result: 'incompatible schema explicitly rejected before Git comparison' }));
}
const runner = readFileSync(new URL('../portable-keystore-cleanup/packages/contracts/scripts/run-mythril.sh', import.meta.url), 'utf8');
const match = /^for f in (.+); do$/m.exec(runner);
assert.ok(match !== null);
assert.deepEqual(match[1].split(' '), EXPECTED_TARGETS);
console.log(JSON.stringify({ runner: 'packages/contracts/scripts/run-mythril.sh', expected_order: EXPECTED_TARGETS, order_matches: true, analyzer_executed: false }));
